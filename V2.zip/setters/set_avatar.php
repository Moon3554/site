<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Non connecté']);
    exit;
}

require_once __DIR__ . '/../db.php';

$data   = json_decode(file_get_contents('php://input'), true);
$type   = $data['type']  ?? '';
$img_id = (int)($data['id'] ?? 0);

if (!in_array($type, ['avatar', 'banner', 'manga']) || $img_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Données invalides']);
    exit;
}

if ($type === 'manga') {
    try {
        $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS fav_manga_id INT DEFAULT NULL");
        $stmt = $db->prepare("SELECT image_url FROM mangas WHERE id = ?");
        $stmt->execute([$img_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) { echo json_encode(['success' => false, 'error' => 'Manga introuvable']); exit; }
        $db->prepare("UPDATE users SET fav_manga_id = ? WHERE id = ?")->execute([$img_id, $_SESSION['user_id']]);
        echo json_encode(['success' => true, 'url' => $row['image_url']]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

$table = $type === 'avatar' ? 'profile_avatars' : 'profile_banners';
$stmt  = $db->prepare("SELECT image_url FROM $table WHERE id = ?");
$stmt->execute([$img_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    echo json_encode(['success' => false, 'error' => 'Image introuvable']);
    exit;
}

$url  = $row['image_url'];
$col  = $type === 'avatar' ? 'avatar' : 'banner';

try {
    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar VARCHAR(500) DEFAULT NULL");
    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS banner VARCHAR(500) DEFAULT NULL");
} catch (PDOException $e) {}

$stmt = $db->prepare("UPDATE users SET $col = ? WHERE id = ?");
$stmt->execute([$url, $_SESSION['user_id']]);

echo json_encode(['success' => true, 'url' => $url]);