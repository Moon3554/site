<?php
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accès refusé: vous devez être admin']);
    exit;
}

$rawData = file_get_contents('php://input');
if (empty($rawData)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Aucune donnée envoyée']);
    exit;
}

$input = json_decode($rawData, true);
if ($input === null) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Données JSON invalides']);
    exit;
}

if (!isset($input['content']) || $input['content'] === null) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Le champ "content" est requis']);
    exit;
}

$file    = __DIR__ . '/../announces.txt';
$content = trim((string)$input['content']);

if (file_put_contents($file, $content) !== false) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Impossible d\'écrire le fichier announces.txt']);
}