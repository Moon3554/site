<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json');

$data       = json_decode(file_get_contents('php://input'), true);
$chapter_id = isset($data['chapter_id']) ? (int)$data['chapter_id'] : 0;

if ($chapter_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID invalide']);
    exit;
}

$view_key = 'viewed_chapter_' . $chapter_id;

if (!isset($_SESSION[$view_key])) {
    try {
        $stmt = $db->prepare("UPDATE chapters SET views = views + 1 WHERE id = ?");
        $stmt->execute([$chapter_id]);

        $_SESSION[$view_key] = true;

        echo json_encode(['success' => true, 'message' => 'Vue enregistrée']);
    } catch (PDOException $e) {
        error_log("Erreur track_view : " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erreur serveur']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Déjà vu dans cette session']);
}
?>
