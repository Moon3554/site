<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'check_captcha.php';
require_once 'db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

function fetch_imgur_album($album_url) {
    $album_url = trim($album_url);
    if ($album_url === '') return [];

    if (preg_match('#https?://i\.imgur\.com/[^\s"\']+#i', $album_url)) {
        return [$album_url];
    }

    $album_id = null;
    if (preg_match('#imgur\.com/(?:a|gallery)/([A-Za-z0-9]+)#i', $album_url, $m)) {
        $album_id = $m[1];
    }
    if (!$album_id) return [];

    $api_url = 'https://api.imgur.com/3/album/' . $album_id . '/images';
    $opts = [
        'http' => [
            'method' => 'GET',
            'header' => "Authorization: Client-ID 546c25a59c58ad7\r\nUser-Agent: YureiScan/1.0\r\n"
        ]
    ];
    $context = stream_context_create($opts);
    $json = @file_get_contents($api_url, false, $context);
    if (!$json) return [];

    $data = json_decode($json, true);
    if (empty($data['success']) || empty($data['data'])) return [];

    $urls = [];
    foreach ($data['data'] as $img) {
        if (!empty($img['link'])) {
            $urls[] = $img['link'];
        }
    }
    return $urls;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {

    $action = $_POST['action'] ?? '';

    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('Action non autorisée (CSRF).');
    }

    if ($action === 'delete_chapter') {
        $chapter_id = (int)($_POST['chapter_id'] ?? 0);
        try {
            $db->beginTransaction();
            $stmt = $db->prepare("DELETE FROM chapter_pages WHERE chapter_id = ?");
            $stmt->execute([$chapter_id]);
            $stmt = $db->prepare("DELETE FROM chapters WHERE id = ? AND manga_id = ?");
            $stmt->execute([$chapter_id, $id]);
            $db->commit();
            header("Location: manga.php?id=" . $id . "&status=deleted");
            exit();
        } catch (PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            error_log("Erreur suppression chapitre : " . $e->getMessage());
            header("Location: manga.php?id=" . $id . "&error=delete_failed");
            exit();
        }
    }

    if ($action === 'update_chapter_date') {
        $chapter_id = (int)($_POST['chapter_id'] ?? 0);
        $new_date   = trim($_POST['chapter_date'] ?? '');
        $stmt = $db->prepare("UPDATE chapters SET created_at = ? WHERE id = ? AND manga_id = ?");
        $stmt->execute([$new_date, $chapter_id, $id]);
        header("Location: manga.php?id=" . $id);
        exit();
    }

    if ($action === 'edit_manga') {
        $status                 = trim($_POST['status'] ?? '');
        $type                   = trim($_POST['type'] ?? '');
        $author                 = trim($_POST['author'] ?? '');
        $artist                 = trim($_POST['artist'] ?? '');
        $posted                 = $_POST['posted'] ?? '';
        $summary                = trim($_POST['summary'] ?? '');
        $genres                 = isset($_POST['genres']) ? json_encode($_POST['genres']) : '[]';
        $has_illustration_bonus = isset($_POST['has_illustration_bonus']) ? 1 : 0;
        $is_abandoned           = isset($_POST['is_abandoned']) ? 1 : 0;
        $vertical_only          = isset($_POST['vertical_only']) ? 1 : 0;

        $stmt = $db->prepare("UPDATE mangas SET status=?, type=?, author=?, artist=?, created_at=?, summary=?, genres=?, has_illustration_bonus=?, is_abandoned=?, vertical_only=? WHERE id=?");
        $stmt->execute([$status, $type, $author, $artist, $posted, $summary, $genres, $has_illustration_bonus, $is_abandoned, $vertical_only, $id]);
        header("Location: manga.php?id=" . $id);
        exit();
    }

    if ($action === 'add_chapter') {
        $chapter_number = trim($_POST['chapter_number'] ?? '');
        $chapter_title  = trim($_POST['chapter_title']  ?? '');
        $page_urls      = array_values(array_filter(array_map('trim', (array)($_POST['page_urls'] ?? []))));
        $imgur_album    = trim($_POST['imgur_album_url'] ?? '');

        if ($imgur_album !== '') {
            $fetched = fetch_imgur_album($imgur_album);
            if (!empty($fetched)) {
                $page_urls = $fetched;
            }
        }

        error_log("DEBUG add_chapter: chapter_number=" . $chapter_number . ", page_urls count=" . count($page_urls));
        foreach ($page_urls as $idx => $url) {
            error_log("  Page $idx: " . $url);
        }

        if ($chapter_number !== '') {
            try {
                $db->beginTransaction();
                try {
                    $stmt = $db->prepare("INSERT INTO chapters (manga_id, chapter_number, title, created_at) VALUES (?, ?, ?, NOW())");
                    $stmt->execute([$id, $chapter_number, $chapter_title]);
                } catch (PDOException $e) {
                    $db->rollBack();
                    $db->beginTransaction();
                    $stmt = $db->prepare("INSERT INTO chapters (manga_id, chapter_number, created_at) VALUES (?, ?, NOW())");
                    $stmt->execute([$id, $chapter_number]);
                }
                $new_id = (int)$db->lastInsertId();
                error_log("DEBUG: Created chapter ID=" . $new_id);
                
                foreach ($page_urls as $i => $url) {
                    if (!empty($url)) {
                        $stmt = $db->prepare("INSERT INTO chapter_pages (chapter_id, page_url, page_order) VALUES (?, ?, ?)");
                        $stmt->execute([$new_id, $url, $i + 1]);
                        error_log("DEBUG: Inserted page $i for chapter $new_id: $url");
                    }
                }
                $db->commit();
                error_log("DEBUG: add_chapter transaction committed successfully");
            } catch (PDOException $e) {
                if ($db->inTransaction()) $db->rollBack();
                error_log("add_chapter : " . $e->getMessage());
            }
        }
        header("Location: manga.php?id=" . $id);
        exit();
    }

    if ($action === 'add_pages_to_chapter') {
        $chapter_id = (int)($_POST['chapter_id'] ?? 0);
        $page_urls  = array_values(array_filter(array_map('trim', (array)($_POST['page_urls'] ?? []))));
        $imgur_album = trim($_POST['imgur_album_url'] ?? '');

        if ($imgur_album !== '') {
            $fetched = fetch_imgur_album($imgur_album);
            if (!empty($fetched)) {
                $page_urls = $fetched;
            }
        }

        if ($chapter_id > 0 && !empty($page_urls)) {
            try {
                $db->beginTransaction();
                $stmt = $db->prepare("SELECT COALESCE(MAX(page_order), 0) FROM chapter_pages WHERE chapter_id = ?");
                $stmt->execute([$chapter_id]);
                $start = (int)$stmt->fetchColumn() + 1;
                foreach ($page_urls as $i => $url) {
                    $stmt = $db->prepare("INSERT INTO chapter_pages (chapter_id, page_url, page_order) VALUES (?, ?, ?)");
                    $stmt->execute([$chapter_id, $url, $start + $i]);
                }
                $db->commit();
            } catch (PDOException $e) {
                if ($db->inTransaction()) $db->rollBack();
                error_log("add_pages_to_chapter : " . $e->getMessage());
            }
        }
        header("Location: manga.php?id=" . $id);
        exit();
    }

    if ($action === 'add_illustration') {
        $image_url = trim($_POST['image_url'] ?? '');
        $link_url  = trim($_POST['link_url']  ?? '');
        $caption   = trim($_POST['caption']   ?? '');

        if (!empty($image_url)) {
            try {
                $stmt = $db->prepare("INSERT INTO illustrations (manga_id, image_url, link_url, caption, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$id, $image_url, $link_url, $caption]);
                error_log("DEBUG: Added illustration for manga $id");
            } catch (PDOException $e) {
                error_log("add_illustration : " . $e->getMessage());
            }
        }
        header("Location: manga.php?id=" . $id);
        exit();
    }
}

try {
    $stmt = $db->prepare("
        SELECT m.*,
               COALESCE(SUM(c.views), 0) as total_views
        FROM mangas m
        LEFT JOIN chapters c ON m.id = c.manga_id
        WHERE m.id = ?
        GROUP BY m.id
    ");
    $stmt->execute([$id]);
    $manga = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$manga) {
        die("Manga non trouvé.");
    }

    $age_just_confirmed = isset($_GET['confirmed']) && $_GET['confirmed'] == '1';
    $has_adult_access   = !empty($_SESSION['show_adult']) || (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1);
    $show_popup = false;

    $stmt = $db->prepare("SELECT * FROM chapters WHERE manga_id = ? ORDER BY (chapter_number + 0) DESC");
    $stmt->execute([$id]);
    $chapters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $first_chapter = $chapters ? end($chapters) : null;
    $last_chapter  = $chapters ? reset($chapters) : null;

    $stmt = $db->prepare("SELECT * FROM illustrations WHERE manga_id = ? ORDER BY created_at ASC");
    $stmt->execute([$id]);
    $illustrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    try {
        $db->exec("ALTER TABLE mangas ADD COLUMN IF NOT EXISTS is_abandoned TINYINT(1) DEFAULT 0");
    } catch (PDOException $e) {}

    try {
        $db->exec("ALTER TABLE mangas ADD COLUMN IF NOT EXISTS vertical_only TINYINT(1) DEFAULT 0");
    } catch (PDOException $e) {}

    $rating_avg   = 0;
    $rating_count = 0;
    $user_rating  = 0;
    try {
        $stmt = $db->prepare("SELECT ROUND(AVG(rating),1) as avg_r, COUNT(*) as cnt FROM manga_ratings WHERE manga_id = ?");
        $stmt->execute([$id]);
        $rdata = $stmt->fetch(PDO::FETCH_ASSOC);
        $rating_avg   = (float)($rdata['avg_r'] ?? 0);
        $rating_count = (int)($rdata['cnt'] ?? 0);

        if (!empty($_SESSION['user_id'])) {
            $stmt = $db->prepare("SELECT rating FROM manga_ratings WHERE manga_id = ? AND user_id = ?");
            $stmt->execute([$id, $_SESSION['user_id']]);
            $ur = $stmt->fetch(PDO::FETCH_ASSOC);
            $user_rating = $ur ? (int)$ur['rating'] : 0;
        }
    } catch (PDOException $e) {
    }

    $og_title       = htmlspecialchars($manga['title']) . " - Yurei Scan";
    $og_description = htmlspecialchars($manga['summary'] ?? 'Lisez ' . $manga['title'] . ' sur Yurei Scan');
    if (strlen($og_description) > 200) $og_description = substr($og_description, 0, 197) . '...';
    
    $og_image = htmlspecialchars($manga['image_url'] ?? '');
    $og_url   = "https://yurei-scan.fr/manga.php?id=" . $id;

} catch (PDOException $e) {
    error_log("Erreur manga.php : " . $e->getMessage());
    die("Erreur lors du chargement du manga.");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($manga['title']); ?> - Yurei Scan</title>
    <meta name="description" content="<?php echo htmlspecialchars(substr($manga['summary'] ?? 'Lisez ' . $manga['title'], 0, 160)); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $og_url; ?>">
    <meta property="og:title" content="<?php echo $og_title; ?>">
    <meta property="og:description" content="<?php echo $og_description; ?>">
    <meta property="og:site_name" content="Yurei Scan">
    <meta property="og:locale" content="fr_FR">
    <?php if ($og_image): ?>
    <meta property="og:image" content="<?php echo $og_image; ?>">
    <meta property="og:image:width" content="460">
    <meta property="og:image:height" content="690">
    <meta property="og:image:alt" content="Couverture de <?php echo htmlspecialchars($manga['title']); ?>">
    <?php endif; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@YureiScan">
    <meta name="twitter:title" content="<?php echo $og_title; ?>">
    <meta name="twitter:description" content="<?php echo $og_description; ?>">
    <?php if ($og_image): ?>
    <meta name="twitter:image" content="<?php echo $og_image; ?>">
    <meta name="twitter:image:alt" content="Couverture de <?php echo htmlspecialchars($manga['title']); ?>">
    <?php endif; ?>
    <meta name="theme-color" content="#bc6a6a">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .content { max-width: 1400px; margin: 0 auto; padding: 40px 20px; }
        .manga-container { display: grid; grid-template-columns: 320px 1fr; gap: 40px; margin-bottom: 50px; }
        .left-column { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 25px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 32px rgba(0,0,0,0.4); position: sticky; top: 20px; height: fit-content; }
        .manga-cover { width: 100%; height: 400px; object-fit: cover; object-position: top center; border-radius: 15px; margin-bottom: 20px; box-shadow: 0 6px 25px rgba(0,0,0,0.35); transform: scale(1.03); }
        .manga-info-list { list-style: none; }
        .manga-info-list li { padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.1); font-size: 14px; }
        .manga-info-list li:last-child { border-bottom: none; }
        .manga-info-list strong { color: #bc6a6a; margin-right: 6px; font-weight: 600; }
        .admin-buttons { margin-top: 20px; }
        .edit-btn, .delete-manga-btn { width: 100%; padding: 12px; margin-top: 10px; border: none; border-radius: 12px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .edit-btn { background: #bc6a6a; color: white; }
        .edit-btn:hover { transform: translateY(-2px); }
        .delete-manga-btn { background: linear-gradient(135deg, #e74c3c, #c0392b); color: white; }
        .delete-manga-btn:hover { transform: translateY(-2px); }
        .editable { display: none; margin-top: 15px; }
        .editable.active { display: block; }
        .edit-input, .edit-date, .edit-textarea { width: 100%; padding: 10px; margin-bottom: 12px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.2); color: #fff; border-radius: 10px; font-family: inherit; font-size: 14px; }
        .edit-textarea { min-height: 100px; resize: vertical; }
        .save-btn, .cancel-btn { padding: 10px 20px; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; }
        .save-btn { background: linear-gradient(135deg, #28a745, #20c997); color: white; margin-right: 10px; }
        .cancel-btn { background: #dc3545; color: white; }
        .right-column { min-width: 0; }
        .title-container { display: flex; align-items: center; gap: 15px; margin-bottom: 15px; flex-wrap: wrap; }
        .manga-title { font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin: 0; }
        .views-badge { display: inline-flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.1); border: 2px solid rgba(255,255,255,0.3); padding: 6px 12px; border-radius: 20px; font-size: 14px; font-weight: 600; }
        .genres-section, .synopsis-section { background: rgba(255,255,255,0.03); padding: 25px; border-radius: 15px; margin-bottom: 30px; border: 1px solid rgba(255,255,255,0.08); }
        .genres-section h3, .synopsis-section h3 { color: #bc6a6a; font-size: 20px; margin-bottom: 15px; font-weight: 600; }
        .genres-list { display: flex; flex-wrap: wrap; gap: 10px; }
        .genre-tag { background: rgba(255,255,255,0.1); color: white; border: 2px solid rgba(255,255,255,0.3); padding: 8px 15px; border-radius: 20px; font-size: 14px; }
        .synopsis-section p { color: #ccc; line-height: 1.8; font-size: 15px; }
        .navigation-buttons { display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap; }
        .nav-btn { flex: 1; min-width: 180px; padding: 15px 25px; background: #bc6a6a; color: white; text-decoration: none; border-radius: 15px; font-size: 16px; font-weight: 600; text-align: center; transition: all 0.3s ease; }
        .nav-btn:hover { transform: translateY(-3px); }
        .chapters-section { background: rgba(255,255,255,0.03); padding: 30px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.08); margin-bottom: 30px; }
        .chapters-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 25px; flex-wrap: wrap; gap: 10px; }
        .chapters-title { font-size: 24px; color: #bc6a6a; font-weight: 600; margin: 0; }
        .chapters-header-right { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
        .btn-add-chapter-main { background: linear-gradient(135deg, #bc6a6a, #a85c5c); color: white; border: none; padding: 10px 20px; border-radius: 12px; font-size: 14px; font-weight: 700; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; gap: 7px; }
        .btn-add-chapter-main:hover { transform: translateY(-2px); }
        .view-toggle { position: relative; }
        .toggle-button { background: #bc6a6a; border: none; color: #fff; padding: 6px 12px; border-radius: 20px; cursor: pointer; font-size: 12px; font-weight: 600; }
        .toggle-menu { position: absolute; top: calc(100% + 8px); right: 0; background: rgba(10,10,10,0.95); border: 2px solid rgba(188,106,106,0.4); border-radius: 12px; padding: 8px; min-width: 180px; display: none; z-index: 100; }
        .toggle-menu.open { display: block; }
        .toggle-option { padding: 10px 12px; cursor: pointer; border-radius: 8px; color: #fff; font-size: 13px; }
        .toggle-option:hover { background: rgba(188,106,106,0.3); }
        .toggle-option.selected { background: #bc6a6a; }
        .chapter-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; }
        .chapter-wrapper { position: relative; }
        .chapter-card { display: block; background: rgba(255,255,255,0.05); padding: 20px; border-radius: 12px; text-decoration: none; color: #fff; border: 1px solid rgba(255,255,255,0.1); transition: all 0.3s; text-align: center; }
        .chapter-card:hover { transform: translateY(-5px); background: rgba(188,106,106,0.2); border-color: rgba(188,106,106,0.5); }
        .chapter-number { font-size: 16px; font-weight: 600; margin-bottom: 8px; }
        .chapter-date { font-size: 12px; color: #999; }
        .illustration-grid { display: none; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 15px; }
        .illustration-grid.active { display: grid; }
        .illustration-card { aspect-ratio: 3/4; border-radius: 16px; overflow: hidden; cursor: pointer; }
        .illustration-image { width: 100%; height: 100%; object-fit: cover; display: block; object-position: top center; }
        .delete-chapter-btn { position: absolute; top: 8px; right: 8px; background: #e74c3c; color: white; border: none; padding: 5px 10px; border-radius: 8px; font-size: 11px; cursor: pointer; z-index: 10; }
        .delete-chapter-btn:hover { background: #c0392b; }
        .edit-date-btn { position: absolute; top: 8px; left: 8px; background: #667eea; color: white; border: none; padding: 5px 10px; border-radius: 8px; font-size: 11px; cursor: pointer; z-index: 10; }
        .add-pages-btn { position: absolute; bottom: 8px; left: 8px; background: linear-gradient(135deg, #27ae60, #2ecc71); color: white; border: none; width: 26px; height: 26px; border-radius: 50%; font-size: 17px; font-weight: 700; cursor: pointer; z-index: 10; display: flex; align-items: center; justify-content: center; line-height: 1; transition: transform 0.2s; }
        .add-pages-btn:hover { transform: scale(1.2); }
        .edit-date-form { display: none; position: absolute; top: 100%; left: 0; right: 0; background: rgba(0,0,0,0.92); padding: 10px; border-radius: 8px; z-index: 20; }
        .edit-date-form.active { display: block; }
        .edit-date-input { width: 100%; padding: 8px; margin-bottom: 8px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff; border-radius: 8px; }
        .edit-date-buttons { display: flex; gap: 8px; }
        .save-date-btn, .cancel-date-btn { flex: 1; padding: 8px; border: none; border-radius: 8px; font-size: 12px; cursor: pointer; }
        .save-date-btn { background: #28a745; color: white; }
        .cancel-date-btn { background: #dc3545; color: white; }
        .empty-message { text-align: center; padding: 60px 20px; color: #999; font-size: 16px; }
        .empty-message::before { content: '📖'; display: block; font-size: 48px; margin-bottom: 15px; }
        .age-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; z-index: 9999; backdrop-filter: blur(15px); }
        .age-modal-content { background: rgba(20,20,20,0.85); border: 2px solid rgba(255,255,255,0.3); padding: 50px 40px; max-width: 600px; text-align: center; }
        .age-modal-title { font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 30px; text-transform: uppercase; letter-spacing: 2px; line-height: 1.4; }
        .age-modal-buttons { display: flex; gap: 20px; justify-content: center; }
        .age-btn { padding: 15px 40px; border: 2px solid #fff; font-size: 16px; font-weight: 700; cursor: pointer; text-transform: uppercase; background: transparent; color: #fff; text-decoration: none; display: inline-block; transition: all 0.2s; }
        .age-btn:hover { background: rgba(255,255,255,0.1); }
        .content-blurred { filter: blur(20px); pointer-events: none; user-select: none; }

        .yurei-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); backdrop-filter: blur(14px); z-index: 3000; align-items: center; justify-content: center; }
        .yurei-overlay.active { display: flex; }
        .yurei-modal { background: rgba(12,12,12,0.98); border: 2px solid rgba(188,106,106,0.35); border-radius: 22px; padding: 38px 34px 34px; max-width: 540px; width: 92%; max-height: 90vh; overflow-y: auto; position: relative; scrollbar-width: thin; }
        .yurei-close { position: absolute; top: 14px; right: 14px; background: rgba(255,255,255,0.07); border: none; color: #aaa; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
        .yurei-close:hover { background: rgba(231,76,60,0.3); color: #fff; }
        .yurei-modal h2 { font-size: 26px; font-weight: 700; color: #fff; text-align: center; margin-bottom: 26px; }
        .yurei-modal h3 { font-size: 20px; font-weight: 700; color: #fff; text-align: center; margin: 24px 0 18px; }
        .yurei-group { display: flex; flex-direction: column; gap: 7px; margin-bottom: 16px; }
        .yurei-group label { font-size: 11px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 1.2px; }
        .yurei-input { padding: 15px 17px; background: rgba(255,255,255,0.05); border: 2px solid rgba(255,255,255,0.12); color: #fff; border-radius: 13px; font-size: 15px; font-family: inherit; transition: all 0.25s; width: 100%; }
        .yurei-input::placeholder { color: rgba(255,255,255,0.3); }
        .yurei-input:focus { outline: none; border-color: rgba(188,106,106,0.7); background: rgba(255,255,255,0.08); box-shadow: 0 0 0 3px rgba(188,106,106,0.15); }
        .yurei-pages { display: flex; flex-direction: column; gap: 10px; }
        .yurei-page-row { display: flex; gap: 8px; align-items: center; }
        .yurei-page-row .yurei-input { flex: 1; }
        .yurei-rm { background: linear-gradient(135deg, #e74c3c, #c0392b); color: white; border: none; width: 44px; height: 44px; border-radius: 11px; cursor: pointer; font-size: 18px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: transform 0.2s; }
        .yurei-rm:hover { transform: scale(1.08); }
        .yurei-add-page { background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; width: 100%; padding: 14px; border-radius: 13px; font-size: 15px; font-weight: 700; cursor: pointer; margin-top: 6px; transition: transform 0.2s; }
        .yurei-add-page:hover { transform: translateY(-2px); }
        .yurei-msg { display: none; margin-top: 12px; padding: 11px 15px; border-radius: 10px; background: rgba(0,0,0,0.35); font-weight: 600; font-size: 14px; text-align: center; }
        .yurei-submit { background: linear-gradient(135deg, #bc6a6a, #9e5252); color: white; border: none; width: 100%; padding: 17px; border-radius: 15px; font-size: 15px; font-weight: 800; cursor: pointer; box-shadow: 0 5px 20px rgba(188,106,106,0.4); text-transform: uppercase; letter-spacing: 1.8px; margin-top: 20px; transition: all 0.3s; }
        .yurei-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(188,106,106,0.6); }
        .yurei-submit:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        @media (max-width: 768px) { .manga-container { grid-template-columns: 1fr; } .left-column { position: static; } .manga-title { font-size: 32px; } .navigation-buttons { flex-direction: column; } .chapters-section { padding: 20px; } }
        @media (max-width: 480px) { .manga-title { font-size: 26px; } .chapter-grid { grid-template-columns: repeat(auto-fill, minmax(140px,1fr)); gap: 10px; } .yurei-modal { padding: 28px 20px 24px; } }

        .rating-section { background: rgba(255,255,255,0.03); padding: 22px 25px; border-radius: 15px; margin-bottom: 30px; border: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
        .rating-avg-block { display: flex; flex-direction: column; align-items: center; min-width: 70px; }
        .rating-avg-number { font-size: 36px; font-weight: 800; color: #f4c430; line-height: 1; }
        .rating-avg-stars { font-size: 14px; color: #f4c430; letter-spacing: 2px; margin-top: 4px; }
        .rating-avg-count { font-size: 11px; color: #888; margin-top: 4px; }
        .rating-divider { width: 1px; height: 50px; background: rgba(255,255,255,0.12); }
        .rating-user-block { flex: 1; }
        .rating-user-label { font-size: 13px; color: #aaa; margin-bottom: 10px; }
        .rating-user-label strong { color: #fff; }
        .stars-input { display: flex; gap: 6px; }
        .star-btn { font-size: 28px; background: none; border: none; cursor: pointer; color: #555; transition: color 0.15s, transform 0.15s; padding: 0 2px; line-height: 1; }
        .star-btn:hover, .star-btn.hovered, .star-btn.selected { color: #f4c430; transform: scale(1.2); }
        .rating-login-msg { font-size: 13px; color: #888; }
        .rating-login-msg a { color: #bc6a6a; font-weight: 700; text-decoration: none; }
        .rating-feedback { font-size: 13px; color: #51cf66; margin-top: 8px; display: none; }
        .half-star { display: inline-block; width: 0.5em; overflow: hidden; vertical-align: middle; position: relative;top: -2px; }
    </style>
</head>
<?php include 'header.php'; ?>
<body>

<?php if ($show_popup): ?>
<div class="age-modal">
    <div class="age-modal-content">
        <h2 class="age-modal-title">Contenu pour public averti.<br>Voulez vous continuez ?</h2>
        <div class="age-modal-buttons">
            <a href="manga.php?id=<?php echo $id; ?>&confirmed=1" class="age-btn">Continuer</a>
            <button onclick="window.history.back();" class="age-btn">Retour</button>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="content <?php echo $show_popup ? 'content-blurred' : ''; ?>">
    <div class="manga-container">

        <div class="left-column">
            <img src="<?php echo htmlspecialchars($manga['image_url'] ?? 'default_cover.jpg'); ?>"
                 alt="<?php echo htmlspecialchars($manga['title']); ?>"
                 class="manga-cover">

            <ul class="manga-info-list">
                <li><strong>Statut :</strong> <?php
                    $st  = $manga['status'] ?? 'En cours';
                    $map = ['ongoing'=>'En cours','completed'=>'Terminé','hiatus'=>'En pause','cancelled'=>'Annulé','abandoned'=>'Abandonné'];
                    echo htmlspecialchars($map[strtolower($st)] ?? $st);
                ?></li>
                <li><strong>Type :</strong>    <?php echo htmlspecialchars($manga['type']   ?? 'Manga'); ?></li>
                <li><strong>Auteur :</strong>  <?php echo htmlspecialchars($manga['author'] ?? 'Inconnu'); ?></li>
                <li><strong>Artiste :</strong> <?php echo htmlspecialchars($manga['artist'] ?? 'Inconnu'); ?></li>
                <li><strong>Commencé le :</strong> <?php echo date('d/m/Y', strtotime($manga['created_at'] ?? 'now')); ?></li>
            </ul>

            <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
            <div class="editable">
                <form action="manga.php?id=<?php echo $id; ?>" method="post">
                    <input type="hidden" name="action"     value="edit_manga">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <input type="text" name="status"  class="edit-input" value="<?php echo htmlspecialchars($manga['status']  ?? ''); ?>" placeholder="Status">
                    <input type="text" name="type"    class="edit-input" value="<?php echo htmlspecialchars($manga['type']    ?? ''); ?>" placeholder="Type">
                    <input type="text" name="author"  class="edit-input" value="<?php echo htmlspecialchars($manga['author']  ?? ''); ?>" placeholder="Auteur">
                    <input type="text" name="artist"  class="edit-input" value="<?php echo htmlspecialchars($manga['artist']  ?? ''); ?>" placeholder="Artiste">
                    <input type="date" name="posted"  class="edit-date"  value="<?php echo date('Y-m-d', strtotime($manga['created_at'])); ?>">
                    <label style="display:block;margin:10px 0;">
                        <input type="checkbox" name="has_illustration_bonus" value="1" <?php echo !empty($manga['has_illustration_bonus']) ? 'checked' : ''; ?>>
                        Illustration bonus
                    </label>
                    <label style="display:block;margin:10px 0;">
                        <input type="checkbox" name="vertical_only" value="1" <?php echo !empty($manga['vertical_only']) ? 'checked' : ''; ?>>
                        Lecture verticale uniquement
                    </label>
                    <textarea name="summary" class="edit-textarea" placeholder="Résumé"><?php echo htmlspecialchars($manga['summary'] ?? ''); ?></textarea>
                    <label>Genres :</label>
                    <select name="genres[]" multiple class="edit-input" style="height:150px;">
                        <?php
                        $ag = ['Action','Adulte','Aventure',"Boy's Love",'Comédie','Drame','Ecchi','Fantaisie',"Girl's Love",'Gore','Harem','Horreur','Isekai','Post-apocalyptique','Romance','School Life','Slice of Life','Sport','Surnaturel','Thriller','Historique'];
                        sort($ag);
                        $cg = json_decode($manga['genres'] ?? '[]', true);
                        foreach ($ag as $g) {
                            $sel = in_array($g, $cg) ? 'selected' : '';
                            echo '<option value="' . htmlspecialchars($g) . '" ' . $sel . '>' . htmlspecialchars($g) . '</option>';
                        }
                        ?>
                    </select>
                    <button type="submit" class="save-btn">Sauvegarder</button>
                    <button type="button" class="cancel-btn" onclick="toggleEdit()">Annuler</button>
                </form>
            </div>
            <div class="admin-buttons">
                <button type="button" class="edit-btn" onclick="toggleEdit()">Modifier les infos</button>
                <form action="delete_manga.php" method="post">
                    <input type="hidden" name="manga_id" value="<?php echo $id; ?>">
                    <button type="submit" class="delete-manga-btn" onclick="return confirm('Supprimer ce manga ?');">Supprimer le manga</button>
                </form>
            </div>
            <?php endif; ?>
        </div>

        <div class="right-column">
            <div class="title-container">
                <h1 class="manga-title"><?php echo htmlspecialchars($manga['title']); ?></h1>
                <span class="views-badge">👀 <?php echo number_format($manga['total_views']); ?></span>
            </div>

            <div class="genres-section">
                <h3>Genres :</h3>
                <div class="genres-list">
                    <?php
                    $genres = json_decode($manga['genres'] ?? '[]', true);
                    sort($genres);
                    if (!empty($genres)) {
                        foreach ($genres as $g) echo '<span class="genre-tag">' . htmlspecialchars($g) . '</span>';
                    } else { echo '<p>Aucun genre spécifié.</p>'; }
                    ?>
                </div>
            </div>

            <div class="synopsis-section">
                <h3>Synopsis :</h3>
                <p><?php echo nl2br(htmlspecialchars($manga['summary'] ?? 'Aucune description disponible.')); ?></p>
            </div>

            <?php
                $avg_full  = (int)floor($rating_avg);
                $avg_half  = ($rating_avg - $avg_full) >= 0.5 ? 1 : 0;
                $avg_empty = 5 - $avg_full - $avg_half;
                $avg_stars = str_repeat('★', $avg_full) . ($avg_half ? '<span class="half-star">★</span>' : '') . str_repeat('☆', $avg_empty);
            ?>
            <div class="rating-section" id="ratingSection">
                <div class="rating-avg-block">
                    <span class="rating-avg-number"><?php echo $rating_avg > 0 ? $rating_avg : '—'; ?></span>
                    <span class="rating-avg-stars"><?php echo $rating_avg > 0 ? $avg_stars : '☆☆☆☆☆'; ?></span>
                    <span class="rating-avg-count"><?php echo $rating_count; ?> vote<?php echo $rating_count !== 1 ? 's' : ''; ?></span>
                </div>
                <div class="rating-divider"></div>
                <div class="rating-user-block">
                    <?php if (!empty($_SESSION['user_id'])): ?>
                        <p class="rating-user-label">
                            <?php echo $user_rating > 0 ? '<strong>Votre note :</strong> ' . $user_rating . '/5 — Modifier :' : '<strong>Donnez une note à cette série :</strong>'; ?>
                        </p>
                        <div class="stars-input" id="starsInput">
                            <?php for ($s = 1; $s <= 5; $s++): ?>
                            <button type="button" class="star-btn <?php echo $s <= $user_rating ? 'selected' : ''; ?>" data-value="<?php echo $s; ?>">★</button>
                            <?php endfor; ?>
                        </div>
                        <div class="rating-feedback" id="ratingFeedback">Note enregistrée !</div>
                    <?php else: ?>
                        <p class="rating-login-msg"><a href="login.php">Connectez-vous</a> pour noter cette série.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="navigation-buttons">
                <a href="<?php echo $first_chapter ? 'chapter.php?id='.$id.'&chapter_id='.$first_chapter['id'] : '#'; ?>" class="nav-btn">Premier chapitre</a>
                <a href="<?php echo $last_chapter  ? 'chapter.php?id='.$id.'&chapter_id='.$last_chapter['id']  : '#'; ?>" class="nav-btn">Dernier chapitre</a>
            </div>

            <div class="chapters-section">
                <div class="chapters-header">
                    <h2 class="chapters-title">Liste des chapitres</h2>
                    <div class="chapters-header-right">
                        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                        <button class="btn-add-chapter-main" onclick="openAddChapterModal()" type="button">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            Ajouter un chapitre
                        </button>
                        <?php endif; ?>
                        <?php if (!empty($manga['has_illustration_bonus'])): ?>
                        <div class="view-toggle">
                            <button class="toggle-button" onclick="toggleViewMenu()">Plus ▼</button>
                            <div class="toggle-menu" id="viewMenu">
                                <div class="toggle-option selected" onclick="switchView('chapters',this)">Liste des chapitres</div>
                                <div class="toggle-option" onclick="switchView('illustrations',this)">Illustrations LN</div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!empty($chapters)): ?>
                <div class="chapter-grid" id="chapterGrid">
                    <?php foreach ($chapters as $ch): ?>
                    <?php
                        $cn = $ch['chapter_number'];
                        if (is_numeric($cn)) {
                            $cnf = (float)$cn;
                            if (floor($cnf) == $cnf) {
                                $cnDisplay = (string)(int)$cnf;
                            } else {
                                $cnDisplay = rtrim(number_format($cnf, 10, '.', ''), '0');
                            }
                        } else {
                            $cnDisplay = $cn;
                        }
                    ?>
                    <div class="chapter-wrapper">
                        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Supprimer ce chapitre ?');">
                            <input type="hidden" name="action"     value="delete_chapter">
                            <input type="hidden" name="chapter_id" value="<?php echo (int)$ch['id']; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <button type="submit" class="delete-chapter-btn">X</button>
                        </form>
                        <button class="edit-date-btn" onclick="toggleDateEdit(<?php echo (int)$ch['id']; ?>)">✎</button>
                        <button class="add-pages-btn" title="Ajouter des pages"
                            onclick="openAddPagesModal(<?php echo (int)$ch['id']; ?>,'<?php echo htmlspecialchars($cnDisplay, ENT_QUOTES); ?>')">+</button>
                        <form id="date-form-<?php echo (int)$ch['id']; ?>" class="edit-date-form" action="manga.php?id=<?php echo $id; ?>" method="post">
                            <input type="hidden" name="action"     value="update_chapter_date">
                            <input type="hidden" name="chapter_id" value="<?php echo (int)$ch['id']; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                            <input type="date" name="chapter_date" class="edit-date-input" value="<?php echo date('Y-m-d', strtotime($ch['created_at'])); ?>" required>
                            <div class="edit-date-buttons">
                                <button type="submit" class="save-date-btn">✓</button>
                                <button type="button" class="cancel-date-btn" onclick="toggleDateEdit(<?php echo (int)$ch['id']; ?>)">✗</button>
                            </div>
                        </form>
                        <?php endif; ?>
                        <a href="chapter.php?id=<?php echo $id; ?>&chapter_id=<?php echo (int)$ch['id']; ?>" class="chapter-card">
                            <div class="chapter-number">Chapitre <?php echo htmlspecialchars($cnDisplay); ?></div>
                            <div class="chapter-date"><?php echo date('d/m/Y', strtotime($ch['created_at'])); ?></div>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php if (!empty($manga['has_illustration_bonus'])): ?>
                <div class="illustration-grid" id="illustrationGrid">
                    <?php if (!empty($illustrations)): ?>
                        <?php foreach ($illustrations as $ill): ?>
                        <div class="illustration-card" style="position:relative;">
                            <?php $img = htmlspecialchars($ill['image_url']); ?>
                            <img src="<?php echo $img; ?>" alt="" class="illustration-image" loading="lazy"
                                 onclick='openLightbox(<?php echo json_encode($img); ?>,<?php echo json_encode($ill["caption"] ?? ""); ?>,<?php echo json_encode($ill["link_url"] ?? ""); ?>)'>
                            <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                            <form action="delete_illustration.php" method="post" style="position:absolute;top:8px;right:8px;">
                                <input type="hidden" name="illustration_id" value="<?php echo (int)$ill['id']; ?>">
                                <input type="hidden" name="manga_id"        value="<?php echo $id; ?>">
                                <button type="submit" class="delete-chapter-btn" onclick="return confirm('Supprimer ?');">⊖</button>
                            </form>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-message"><p>Aucune illustration.</p></div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <?php else: ?>
                <div class="empty-message"><p>Aucun chapitre disponible pour le moment.</p></div>
                <?php endif; ?>
            </div>

            <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                <div style="text-align:center; margin-top:30px;">
                    <button type="button" class="btn-add-chapter-main" onclick="openAddIllustrationModal()">Ajouter une illustration</button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="lightbox" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.95);z-index:2000;align-items:center;justify-content:center;">
    <div style="position:relative;max-width:98%;max-height:98%;padding:20px;margin:auto;">
        <button onclick="closeLightbox()" style="position:absolute;top:10px;right:10px;background:rgba(255,255,255,0.9);border-radius:50%;border:none;width:38px;height:38px;cursor:pointer;z-index:10;font-size:16px;">✕</button>
        <button id="lb-prev" onclick="navigateLightbox(-1)" style="position:fixed;left:10px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.6);border:2px solid rgba(255,255,255,0.4);color:#fff;border-radius:50%;width:44px;height:44px;cursor:pointer;font-size:22px;z-index:10;">‹</button>
        <button id="lb-next" onclick="navigateLightbox(1)"  style="position:fixed;right:10px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.6);border:2px solid rgba(255,255,255,0.4);color:#fff;border-radius:50%;width:44px;height:44px;cursor:pointer;font-size:22px;z-index:10;">›</button>
        <img id="lb-img" src="" style="max-width:100%;max-height:95vh;display:block;margin:0 auto;object-fit:contain;cursor:zoom-out;" onclick="closeLightbox()">
        <div id="lb-cap"  style="color:#ddd;margin-top:10px;text-align:center;"></div>
        <div id="lb-link" style="text-align:center;margin-top:6px;"></div>
    </div>
</div>

<div id="modalAddChapter" class="yurei-overlay" onclick="if(event.target===this)closeAddChapterModal()">
    <div class="yurei-modal">
        <button type="button" class="yurei-close" onclick="closeAddChapterModal()">✕</button>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=<?php echo $id; ?>">
            <input type="hidden" name="action" value="add_chapter">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <h2>Infos chapitre</h2>
            <div class="yurei-group">
                <label>Titre</label>
                <input type="text" name="chapter_title" placeholder="Titre du chapitre (optionnel)" class="yurei-input">
            </div>
            <div class="yurei-group">
                <label>Numéro</label>
                <input type="text" name="chapter_number" placeholder="Ex : 1, 2.5, 10…" class="yurei-input" required>
            </div>
            <h3>Pages chapitre</h3>
            <div class="yurei-group">
                <label style="color:#f39c12;">Importer depuis MangaDex</label>
                <div style="display:flex;gap:8px;align-items:center;">
                    <input type="url" id="acMangaDexUrl" placeholder="https://mangadex.org/chapter/UUID" class="yurei-input" style="flex:1;">
                    <button type="button" onclick="loadMangaDexChapter('ac')" style="background:#f39c12;color:#000;border:none;border-radius:8px;padding:9px 14px;cursor:pointer;white-space:nowrap;font-size:13px;font-weight:700;">Charger</button>
                </div>
                <div id="acMangaDexStatus" style="font-size:12px;margin-top:5px;color:#aaa;"></div>
                <div id="acMangaDexInfo"   style="font-size:12px;margin-top:3px;color:#2ecc71;display:none;"></div>
            </div>
            <div id="acPages" class="yurei-pages">
                <div class="yurei-page-row">
                    <input type="url" name="page_urls[]" placeholder="Lien page 1" class="yurei-input">
                    <button type="button" class="yurei-rm" onclick="this.parentElement.remove()">✕</button>
                </div>
            </div>
            <button type="button" class="yurei-add-page" onclick="acAddPage()">Ajouter une page</button>
            <button type="submit" class="yurei-submit">PUBLIER CHAPITRE</button>
        </form>
    </div>
</div>

<div id="modalAddPages" class="yurei-overlay" onclick="if(event.target===this)closeAddPagesModal()">
    <div class="yurei-modal">
        <button type="button" class="yurei-close" onclick="closeAddPagesModal()">✕</button>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=<?php echo $id; ?>">
            <input type="hidden" name="action" value="add_pages_to_chapter">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <input type="hidden" name="chapter_id" id="apChapterId" value="">
            <h2>Chapitre <span id="apNum"></span></h2>
            <h3>Ajouter des pages</h3>
            <div class="yurei-group">
                <label style="color:#f39c12;">Importer depuis MangaDex</label>
                <div style="display:flex;gap:8px;align-items:center;">
                    <input type="url" id="apMangaDexUrl" placeholder="https://mangadex.org/chapter/UUID" class="yurei-input" style="flex:1;">
                    <button type="button" onclick="loadMangaDexChapter('ap')" style="background:#f39c12;color:#000;border:none;border-radius:8px;padding:9px 14px;cursor:pointer;white-space:nowrap;font-size:13px;font-weight:700;">Charger</button>
                </div>
                <div id="apMangaDexStatus" style="font-size:12px;margin-top:5px;color:#aaa;"></div>
                <div id="apMangaDexInfo"   style="font-size:12px;margin-top:3px;color:#2ecc71;display:none;"></div>
            </div>
            <div id="apPages" class="yurei-pages">
                <div class="yurei-page-row">
                    <input type="url" name="page_urls[]" placeholder="Lien page 1" class="yurei-input">
                    <button type="button" class="yurei-rm" onclick="this.parentElement.remove()">✕</button>
                </div>
            </div>
            <button type="button" class="yurei-add-page" onclick="apAddPage()">Ajouter une page</button>
            <button type="submit" class="yurei-submit">PUBLIER LES PAGES</button>
        </form>
    </div>
</div>

<div id="modalAddIllustration" class="yurei-overlay" onclick="if(event.target===this)closeAddIllustrationModal()">
    <div class="yurei-modal">
        <button type="button" class="yurei-close" onclick="closeAddIllustrationModal()">✕</button>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=<?php echo $id; ?>">
            <input type="hidden" name="action" value="add_illustration">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            <h2>Ajouter une illustration</h2>
            <div class="yurei-group">
                <label>URL de l'image</label>
                <input type="url" name="image_url" placeholder="https://exemple.com/image.jpg" class="yurei-input" required>
            </div>
            <div class="yurei-group">
                <label>Lien (optionnel)</label>
                <input type="url" name="link_url" placeholder="https://exemple.com" class="yurei-input">
            </div>
            <div class="yurei-group">
                <label>Description</label>
                <textarea name="caption" placeholder="Description de l'illustration" class="yurei-input" style="resize:vertical; min-height:80px;"></textarea>
            </div>
            <button type="submit" class="yurei-submit">AJOUTER L'ILLUSTRATION</button>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>

(function() {
    const stars    = document.querySelectorAll('#starsInput .star-btn');
    const feedback = document.getElementById('ratingFeedback');
    if (!stars.length) return;

    stars.forEach(btn => {
        btn.addEventListener('mouseenter', () => {
            const v = +btn.dataset.value;
            stars.forEach(s => s.classList.toggle('hovered', +s.dataset.value <= v));
        });
        btn.addEventListener('mouseleave', () => {
            stars.forEach(s => s.classList.remove('hovered'));
        });
        btn.addEventListener('click', async () => {
            const rating = +btn.dataset.value;
            stars.forEach(s => s.classList.toggle('selected', +s.dataset.value <= rating));
            try {
                const res = await fetch('rate_manga.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ manga_id: <?php echo $id; ?>, rating })
                });
                const data = await res.json();
                if (data.success) {
                    document.querySelector('.rating-avg-number').textContent = data.avg_rating;
                    document.querySelector('.rating-avg-count').textContent  = data.vote_count + ' vote' + (data.vote_count !== 1 ? 's' : '');
                    document.querySelector('.rating-user-label').innerHTML   = '<strong>Votre note :</strong> ' + rating + '/5 — Modifier :';
                    feedback.style.display = 'block';
                    setTimeout(() => feedback.style.display = 'none', 2500);
                }
            } catch(e) {}
        });
    });
})();

function toggleEdit() {
    document.querySelector('.editable').classList.toggle('active');
    const li = document.querySelector('.manga-info-list');
    li.style.display = document.querySelector('.editable').classList.contains('active') ? 'none' : 'block';
}
function toggleDateEdit(id) {
    document.getElementById('date-form-' + id).classList.toggle('active');
}

function toggleViewMenu() {
    document.getElementById('viewMenu').classList.toggle('open');
}
function switchView(type, el) {
    document.querySelectorAll('.toggle-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    const grid  = document.getElementById('chapterGrid');
    const ills  = document.getElementById('illustrationGrid');
    const title = document.querySelector('.chapters-title');
    if (type === 'illustrations') {
        if (grid)  grid.style.display = 'none';
        if (ills)  ills.classList.add('active');
        if (title) title.textContent = 'Illustrations du light novel';
    } else {
        if (grid)  grid.style.display = 'grid';
        if (ills)  ills.classList.remove('active');
        if (title) title.textContent = 'Liste des chapitres';
    }
    document.getElementById('viewMenu').classList.remove('open');
}
document.addEventListener('click', e => {
    const vt = document.querySelector('.view-toggle');
    if (vt && !vt.contains(e.target)) document.getElementById('viewMenu')?.classList.remove('open');
});

let lbIdx = -1, lbAll = [];
function initLb() {
    lbAll = [...document.querySelectorAll('.illustration-card img')].map(i => i.src);
}
function openLightbox(src, cap, link) {
    if (!lbAll.length) initLb();
    lbIdx = lbAll.indexOf(src);
    document.getElementById('lb-img').src   = src;
    document.getElementById('lb-cap').textContent  = cap  || '';
    document.getElementById('lb-link').innerHTML   = link ? '<a href="'+link+'" target="_blank" style="color:#9fd3ff">Voir le lien</a>' : '';
    document.getElementById('lightbox').style.display = 'flex';
    document.body.style.overflow = 'hidden';
    const show = lbAll.length > 1;
    document.getElementById('lb-prev').style.display = show ? '' : 'none';
    document.getElementById('lb-next').style.display = show ? '' : 'none';
    document.addEventListener('keydown', lbKey);
}
function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
    document.body.style.overflow = '';
    document.removeEventListener('keydown', lbKey);
}
function navigateLightbox(d) {
    lbIdx = (lbIdx + d + lbAll.length) % lbAll.length;
    document.getElementById('lb-img').src = lbAll[lbIdx];
}
function lbKey(e) {
    if (e.key==='Escape') closeLightbox();
    else if (e.key==='ArrowLeft')  navigateLightbox(-1);
    else if (e.key==='ArrowRight') navigateLightbox(1);
}
document.addEventListener('DOMContentLoaded', function() { if (typeof initLb === 'function') initLb(); });

function makeRow(ph) {
    const d = document.createElement('div');
    d.className = 'yurei-page-row';
    d.innerHTML = '<input type="url" name="page_urls[]" class="yurei-input" placeholder="'+ph+'">'
                + '<button type="button" class="yurei-rm" onclick="this.parentElement.remove()">✕</button>';
    return d;
}

function openAddChapterModal() {
    document.getElementById('modalAddChapter').querySelector('form').reset();
    const c = document.getElementById('acPages');
    c.innerHTML = '';
    c.appendChild(makeRow('Lien page 1'));
    document.getElementById('modalAddChapter').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeAddChapterModal() {
    document.getElementById('modalAddChapter').classList.remove('active');
    document.body.style.overflow = '';
}
function acAddPage() {
    const c = document.getElementById('acPages');
    c.appendChild(makeRow('Lien page ' + (c.children.length + 1)));
}

function openAddPagesModal(chapterId, num) {
    document.getElementById('apChapterId').value = chapterId;
    document.getElementById('apNum').textContent = num;
    const c = document.getElementById('apPages');
    c.innerHTML = '';
    c.appendChild(makeRow('Lien page 1'));
    document.getElementById('modalAddPages').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeAddPagesModal() {
    document.getElementById('modalAddPages').classList.remove('active');
    document.body.style.overflow = '';
}
function apAddPage() {
    const c = document.getElementById('apPages');
    c.appendChild(makeRow('Lien page ' + (c.children.length + 1)));
}

async function loadMangaDexChapter(prefix) {
    const urlInput = document.getElementById(prefix + 'MangaDexUrl');
    const statusEl = document.getElementById(prefix + 'MangaDexStatus');
    const infoEl   = document.getElementById(prefix + 'MangaDexInfo');
    const container= document.getElementById(prefix + 'Pages');

    const chapterUrl = urlInput.value.trim();
    statusEl.style.color = '#aaa';
    infoEl.style.display = 'none';

    if (!chapterUrl) {
        statusEl.textContent = 'Colle un lien MangaDex (ex : https://mangadex.org/chapter/UUID).';
        statusEl.style.color = '#e74c3c';
        return;
    }

    const uuidRe = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
    if (!uuidRe.test(chapterUrl)) {
        statusEl.textContent = 'Lien invalide. Format attendu : https://mangadex.org/chapter/UUID-du-chapitre';
        statusEl.style.color = '#e74c3c';
        return;
    }

    statusEl.textContent = 'Chargement en cours…';

    try {
        const res  = await fetch('mangadex_proxy.php?chapter_url=' + encodeURIComponent(chapterUrl));
        const data = await res.json();

        if (!data.success) {
            statusEl.textContent = 'Erreur : ' + (data.error || 'Réponse inattendue.');
            statusEl.style.color = '#e74c3c';
            return;
        }

        const pages = data.pages;
        const info  = data.chapter_info;

        if (prefix === 'ac') {
            const numField   = document.querySelector('#modalAddChapter input[name="chapter_number"]');
            const titleField = document.querySelector('#modalAddChapter input[name="chapter_title"]');
            if (numField   && info.number && numField.value   === '') numField.value   = info.number;
            if (titleField && info.title  && titleField.value === '') titleField.value = info.title;
        }

        container.innerHTML = '';
        pages.forEach((url, i) => {
            const d = document.createElement('div');
            d.className = 'yurei-page-row';
            d.innerHTML = '<input type="url" name="page_urls[]" class="yurei-input" value="' + url.replace(/"/g, '%22') + '">'
                        + '<button type="button" class="yurei-rm" onclick="this.parentElement.remove()">✕</button>';
            container.appendChild(d);
        });

        statusEl.textContent = pages.length + ' page(s) chargée(s) avec succès.';
        statusEl.style.color = '#2ecc71';

        const parts = [];
        if (info.manga)  parts.push('📖 ' + info.manga);
        if (info.number) parts.push('Chapitre ' + info.number);
        if (info.title)  parts.push('"' + info.title + '"');
        if (info.lang)   parts.push('[' + info.lang.toUpperCase() + ']');
        if (parts.length) { infoEl.textContent = parts.join(' · '); infoEl.style.display = 'block'; }

    } catch (e) {
        statusEl.textContent = 'Erreur réseau. Vérifie que mangadex_proxy.php est accessible.';
        statusEl.style.color = '#e74c3c';
        console.error('[MangaDex loader]', e);
    }
}

function openAddIllustrationModal() {
    document.getElementById('modalAddIllustration').querySelector('form').reset();
    document.getElementById('modalAddIllustration').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeAddIllustrationModal() {
    document.getElementById('modalAddIllustration').classList.remove('active');
    document.body.style.overflow = '';
}

</script>
</body>
</html>