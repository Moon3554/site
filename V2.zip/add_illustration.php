<?php
require_once 'check_captcha.php';
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || 
    !isset($_SESSION['is_admin']) || 
    $_SESSION['is_admin'] != 1) {
        
    header('Location: index.php');
    exit();
}

$manga_id = isset($_POST['manga_id']) ? (int)$_POST['manga_id'] : 0;
$image_url = trim($_POST['image_url'] ?? '');
$link_url = trim($_POST['link_url'] ?? '');
$caption = trim($_POST['caption'] ?? '');

if (empty($image_url) || empty($manga_id)) {
    header('Location: manga.php?id=' . $manga_id);
    exit();
}

$stmt = $db->prepare("INSERT INTO illustrations (manga_id, image_url, link_url, caption, created_at) VALUES (?, ?, ?, ?, NOW())");
$stmt->execute([$manga_id, $image_url, $link_url, $caption]);

header('Location: manga.php?id=' . $manga_id);
exit();