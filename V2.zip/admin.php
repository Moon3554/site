<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'check_captcha.php';
require_once 'db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: index.php');
    exit();
}

try {
    $db->exec("CREATE TABLE IF NOT EXISTS profile_avatars (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image_url VARCHAR(500) NOT NULL,
        label VARCHAR(100) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    $db->exec("CREATE TABLE IF NOT EXISTS profile_banners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image_url VARCHAR(500) NOT NULL,
        label VARCHAR(100) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {}

try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS carousel_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            image_url VARCHAR(500) NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            link_url VARCHAR(500) DEFAULT NULL,
            display_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active TINYINT(1) DEFAULT 1
        )
    ");
    $db->exec("ALTER TABLE carousel_images ADD COLUMN IF NOT EXISTS display_order INT DEFAULT 0");
    $db->exec("ALTER TABLE carousel_images ADD COLUMN IF NOT EXISTS link_url VARCHAR(500) DEFAULT NULL");
} catch (PDOException $e) {
}

$publish_success = '';
$publish_error   = '';
$carousel_success = '';
$carousel_error   = '';

if (isset($_POST['action']) && $_POST['action'] === 'update_order') {
    $order_data = json_decode($_POST['order_data'], true);
    if (is_array($order_data)) {
        try {
            $db->beginTransaction();
            $stmt = $db->prepare("UPDATE carousel_images SET display_order = ? WHERE id = ?");
            foreach ($order_data as $item) {
                $stmt->execute([(int)$item['order'], (int)$item['id']]);
            }
            $db->commit();
            $carousel_success = "Ordre mis à jour avec succès !";
        } catch (PDOException $e) {
            $db->rollBack();
            $carousel_error = "Erreur lors de la mise à jour : " . htmlspecialchars($e->getMessage());
        }
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'add_carousel') {
    $image_url   = trim($_POST['image_url'] ?? '');
    $title       = trim($_POST['carousel_title'] ?? '');
    $description = trim($_POST['carousel_description'] ?? '');
    $link_url    = trim($_POST['link_url'] ?? '');

    if ($image_url === '' || $title === '') {
        $carousel_error = "L'URL de l'image et le titre sont obligatoires.";
    } elseif (!filter_var($image_url, FILTER_VALIDATE_URL)) {
        $carousel_error = "L'URL de l'image est invalide.";
    } else {
        try {
            $stmt   = $db->query("SELECT MAX(display_order) as max_order FROM carousel_images");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $next_order = ($result['max_order'] ?? 0) + 1;
            $stmt = $db->prepare("
                INSERT INTO carousel_images (image_url, title, description, link_url, display_order, is_active)
                VALUES (?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([
                $image_url,
                $title,
                $description,
                $link_url !== '' ? $link_url : null,
                $next_order
            ]);
            $carousel_success = "Image ajoutée au carousel avec succès !";
        } catch (PDOException $e) {
            $carousel_error = "Erreur lors de l'ajout : " . htmlspecialchars($e->getMessage());
        }
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'delete_carousel') {
    $image_id = isset($_POST['image_id']) ? (int)$_POST['image_id'] : 0;
    if ($image_id > 0) {
        try {
            $stmt = $db->prepare("DELETE FROM carousel_images WHERE id = ?");
            $stmt->execute([$image_id]);
            $carousel_success = "Image supprimée du carousel !";
        } catch (PDOException $e) {
            $carousel_error = "Erreur lors de la suppression : " . htmlspecialchars($e->getMessage());
        }
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'edit_carousel') {
    $image_id    = isset($_POST['image_id']) ? (int)$_POST['image_id'] : 0;
    $image_url   = trim($_POST['image_url'] ?? '');
    $title       = trim($_POST['carousel_title'] ?? '');
    $description = trim($_POST['carousel_description'] ?? '');
    $link_url    = trim($_POST['link_url'] ?? '');

    if ($image_id > 0 && $image_url !== '' && $title !== '') {
        if (!filter_var($image_url, FILTER_VALIDATE_URL)) {
            $carousel_error = "L'URL de l'image est invalide.";
        } else {
            try {
                $stmt = $db->prepare("
                    UPDATE carousel_images
                    SET image_url = ?, title = ?, description = ?, link_url = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $image_url,
                    $title,
                    $description,
                    $link_url !== '' ? $link_url : null,
                    $image_id
                ]);
                $carousel_success = "Image modifiée avec succès !";
            } catch (PDOException $e) {
                $carousel_error = "Erreur lors de la modification : " . htmlspecialchars($e->getMessage());
            }
        }
    } else {
        $carousel_error = "Données invalides pour la modification.";
    }
}

$stats = ['series' => 0, 'chapitres' => 0, 'membres' => 0, 'staff' => 0];

try {
    $stats['series'] = (int) $db->query("SELECT COUNT(*) FROM mangas")->fetchColumn();
} catch (PDOException $e) {}

try {
    $stats['chapitres'] = (int) $db->query("SELECT COUNT(*) FROM chapters")->fetchColumn();
} catch (PDOException $e) {}

try {
    $stats['membres'] = (int) $db->query(
        "SELECT COUNT(*) FROM users"
    )->fetchColumn();
} catch (PDOException $e) {}

$staff_file = 'staff_data.json';
if (file_exists($staff_file)) {
    $staff_json = json_decode(file_get_contents($staff_file), true);
    $stats['staff'] = is_array($staff_json) ? count($staff_json) : 0;
} else {
    $stats['staff'] = 10;
}

$avatar_msg = ''; $avatar_error = '';

if (isset($_POST['action']) && in_array($_POST['action'], ['add_avatar','delete_avatar','add_banner','delete_banner'])) {
    if ($_POST['action'] === 'add_avatar') {
        $url   = trim($_POST['av_image_url'] ?? '');
        $label = trim($_POST['av_label'] ?? '');
        if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
            $db->prepare("INSERT INTO profile_avatars (image_url, label) VALUES (?,?)")->execute([$url, $label]);
            $avatar_msg = "Avatar ajouté !";
        } else { $avatar_error = "URL d'avatar invalide."; }
    }
    if ($_POST['action'] === 'delete_avatar') {
        $db->prepare("DELETE FROM profile_avatars WHERE id=?")->execute([(int)($_POST['av_id'] ?? 0)]);
        $avatar_msg = "Avatar supprimé.";
    }
    if ($_POST['action'] === 'add_banner') {
        $url   = trim($_POST['bn_image_url'] ?? '');
        $label = trim($_POST['bn_label'] ?? '');
        if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
            $db->prepare("INSERT INTO profile_banners (image_url, label) VALUES (?,?)")->execute([$url, $label]);
            $avatar_msg = "Bannière ajoutée !";
        } else { $avatar_error = "URL de bannière invalide."; }
    }
    if ($_POST['action'] === 'delete_banner') {
        $db->prepare("DELETE FROM profile_banners WHERE id=?")->execute([(int)($_POST['bn_id'] ?? 0)]);
        $avatar_msg = "Bannière supprimée.";
    }
}

$all_avatars = $db->query("SELECT * FROM profile_avatars ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$all_banners = $db->query("SELECT * FROM profile_banners ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

$account_msg   = '';
$account_error = '';

if (isset($_POST['action']) && $_POST['action'] === 'toggle_admin') {
    $target_id  = isset($_POST['target_id']) ? (int)$_POST['target_id'] : 0;
    $new_role   = trim($_POST['new_role'] ?? 'membre');
    if ($target_id > 0 && $target_id !== (int)($_SESSION['user_id'] ?? 0)) {
        try {
            try { $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS is_staff TINYINT(1) DEFAULT 0"); } catch (PDOException $e) {}
            if ($new_role === 'admin') {
                $db->prepare("UPDATE users SET is_admin = 1, is_staff = 0 WHERE id = ?")->execute([$target_id]);
            } elseif ($new_role === 'staff') {
                $db->prepare("UPDATE users SET is_admin = 0, is_staff = 1 WHERE id = ?")->execute([$target_id]);
            } else {
                $db->prepare("UPDATE users SET is_admin = 0, is_staff = 0 WHERE id = ?")->execute([$target_id]);
            }
            $account_msg = "Rôle mis à jour avec succès.";
        } catch (PDOException $e) {
            $account_error = "Erreur : " . htmlspecialchars($e->getMessage());
        }
    } else {
        $account_error = "Action non autorisée.";
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    $target_id = isset($_POST['target_id']) ? (int)$_POST['target_id'] : 0;
    if ($target_id > 0 && $target_id !== (int)($_SESSION['user_id'] ?? 0)) {
        try {
            $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$target_id]);
            $account_msg = "Compte supprimé.";
        } catch (PDOException $e) {
            $account_error = "Erreur : " . htmlspecialchars($e->getMessage());
        }
    } else {
        $account_error = "Action non autorisée.";
    }
}

if (!empty($_POST['search_query']) && !empty($_POST['do_search'])) {
    $_POST['action'] = 'search_users';
}

$search_results   = [];
$search_query     = '';
$search_error     = '';
$search_performed = false;

if (isset($_POST['action']) && $_POST['action'] === 'search_users') {
    $search_query    = trim($_POST['search_query'] ?? '');
    $search_performed = true;
    if ($search_query === '') {
        $search_error = "Veuillez entrer un terme de recherche.";
    } else {
        try {
            $stmt = $db->prepare(
                "SELECT id, username, is_admin, is_staff, created_at
                 FROM users
                 WHERE username LIKE ?
                 ORDER BY created_at DESC
                 LIMIT 50"
            );
            $like = '%' . $search_query . '%';
            $stmt->execute([$like]);
            $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $search_error = "Erreur lors de la recherche : " . htmlspecialchars($e->getMessage());
        }
    }
}

$edit_image = null;
if (isset($_GET['edit_carousel'])) {
    $edit_id = (int)$_GET['edit_carousel'];
    try {
        $stmt = $db->prepare("SELECT * FROM carousel_images WHERE id = ?");
        $stmt->execute([$edit_id]);
        $edit_image = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $carousel_error = "Erreur lors de la récupération de l'image.";
    }
}

try {
    $stmt = $db->query("SELECT * FROM carousel_images WHERE is_active = 1 ORDER BY display_order ASC, id ASC");
    $carousel_images = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $carousel_images = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - Yurei Scan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .content { max-width: 1200px; margin: 0 auto; padding: 50px 20px; }
        .page-title::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 120px; height: 4px; background: #bc6a6a; border-radius: 2px; }
        .alert { padding: 15px 20px; border-radius: 12px; margin-bottom: 25px; font-size: 15px; animation: slideDown 0.3s ease; text-align: center; }
        .alert-success { background: rgba(40,167,69,0.15); border: 1px solid rgba(40,167,69,0.4); color: #51cf66; }
        .alert-error { background: rgba(231,76,60,0.15); border: 1px solid rgba(231,76,60,0.4); color: #ff6b6b; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .admin-section { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 35px; margin-bottom: 40px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 32px rgba(0,0,0,0.4); transition: all 0.3s ease; }
        .admin-section:hover { border-color: rgba(188,106,106,0.3); box-shadow: 0 12px 40px rgba(188,106,106,0.2); }
        .section-title { font-size: 26px; margin-bottom: 25px; color: #bc6a6a; font-weight: 600; position: relative; padding-bottom: 12px; }
        .section-title::after { content: ''; position: absolute; bottom: 0; left: 0; width: 60px; height: 3px; background: #bc6a6a; border-radius: 2px; }
        .section-subtitle { font-size: 18px; margin-bottom: 20px; color: #fff; font-weight: 600; }
        .admin-form { display: flex; flex-direction: column; gap: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; }
        .form-label { font-size: 14px; font-weight: 600; color: #e0e0e0; }
        .form-input, .form-textarea { padding: 12px 16px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.15); background: rgba(0,0,0,0.3); color: #fff; font-size: 14px; font-family: inherit; transition: all 0.3s ease; }
        .select.form-input { background: #000000; color: #fff; appearance: none; -webkit-appearance: none; }
        .form-input:focus, .form-textarea:focus { outline: none; border-color: #bc6a6a; background: rgba(0,0,0,0.4); box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.1); }
        .form-textarea { min-height: 120px; resize: vertical; }
        .btn { padding: 12px 24px; border-radius: 12px; font-size: 15px; font-weight: 600; border: none; cursor: pointer; transition: all 0.3s ease; text-decoration: none; display: inline-block; text-align: center; }
        .btn-primary { background: #bc6a6a; color: white; box-shadow: 0 4px 15px rgba(188,106,106,0.4); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(188,106,106,0.6); }
        .btn-success { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; box-shadow: 0 4px 15px rgba(40,167,69,0.4); }
        .btn-success:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(40,167,69,0.6); }
        .btn-danger { background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); color: white; box-shadow: 0 4px 15px rgba(231,76,60,0.4); padding: 8px 16px; font-size: 13px; }
        .btn-danger:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(231,76,60,0.6); }
        .btn-warning { background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%); color: white; box-shadow: 0 4px 15px rgba(243,156,18,0.4); padding: 8px 16px; font-size: 13px; margin-right: 10px; }
        .btn-warning:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(243,156,18,0.6); }
        .btn-secondary { background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%); color: white; box-shadow: 0 4px 15px rgba(108,117,125,0.4); }
        .btn-secondary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(108,117,125,0.6); }
        .sub-section { background: rgba(0,0,0,0.3); padding: 25px; border-radius: 15px; margin-bottom: 25px; border: 1px solid rgba(255,255,255,0.08); }
        .carousel-list { display: flex; flex-direction: column; gap: 15px; margin-top: 20px; }
        .carousel-item { background: rgba(0,0,0,0.3); padding: 20px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; gap: 20px; transition: all 0.3s ease; cursor: move; position: relative; }
        .carousel-item:hover { background: rgba(0,0,0,0.4); border-color: rgba(188,106,106,0.3); }
        .carousel-item.dragging { opacity: 0.5; transform: scale(0.98); }
        .drag-handle { font-size: 24px; color: #bc6a6a; cursor: grab; user-select: none; padding: 0 10px; }
        .drag-handle:active { cursor: grabbing; }
        .carousel-thumbnail { width: 120px; height: 70px; object-fit: cover; border-radius: 8px; border: 2px solid rgba(255,255,255,0.1); }
        .carousel-info { flex: 1; color: #fff; }
        .carousel-info strong { font-size: 16px; color: #bc6a6a; display: block; margin-bottom: 5px; }
        .carousel-info small { color: #999; font-size: 13px; display: block; }
        .carousel-info .date { margin-top: 5px; font-size: 12px; }
        .carousel-info .link-display { margin-top: 8px; padding: 6px 12px; background: rgba(188,106,106,0.1); border-radius: 6px; border: 1px solid rgba(188,106,106,0.3); display: inline-block; }
        .carousel-info .link-display a { color: #bc6a6a; text-decoration: none; font-size: 13px; }
        .carousel-info .link-display a:hover { text-decoration: underline; }
        .carousel-info .no-link { margin-top: 8px; color: #666; font-style: italic; font-size: 12px; }
        .carousel-actions { display: flex; gap: 10px; }
        .empty-message { text-align: center; padding: 40px 20px; color: #999; font-size: 15px; }
        .quick-actions { display: flex; gap: 15px; justify-content: center; flex-wrap: wrap; margin-top: 30px; }

        .image-preview-wrap { margin-bottom: 24px; }
        .preview-label { font-size: 12px; color: #aaa; font-weight: 700; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
        .preview-pc { background: rgba(0,0,0,0.45); border: 2px solid rgba(188,106,106,0.35); border-radius: 12px; padding: 10px; display: flex; align-items: center; justify-content: center; min-height: 160px; margin-bottom: 20px; }
        .preview-pc img { max-width: 100%; max-height: 380px; width: auto; height: auto; object-fit: contain; border-radius: 6px; display: block; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 40px; }
        .stat-card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.09); border-radius: 18px; padding: 28px 20px 22px; text-align: center; position: relative; overflow: hidden; transition: transform 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease; }
        .stat-card::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 50% -20%, var(--card-glow) 0%, transparent 70%); opacity: 0; transition: opacity 0.3s; }
        .stat-card:hover { transform: translateY(-4px); border-color: var(--card-accent); box-shadow: 0 12px 36px var(--card-shadow); }
        .stat-card:hover::before { opacity: 1; }
        .stat-card--series   { --card-accent: #bc6a6a; --card-glow: rgba(188,106,106,0.35); --card-shadow: rgba(188,106,106,0.25); }
        .stat-card--chapters { --card-accent: #6a9ebc; --card-glow: rgba(106,158,188,0.35); --card-shadow: rgba(106,158,188,0.25); }
        .stat-card--members  { --card-accent: #6abc8a; --card-glow: rgba(106,188,138,0.35); --card-shadow: rgba(106,188,138,0.25); }
        .stat-card--staff    { --card-accent: #bc9a6a; --card-glow: rgba(188,154,106,0.35); --card-shadow: rgba(188,154,106,0.25); }
        .stat-icon { width: 44px; height: 44px; margin: 0 auto 14px; display: block; filter: drop-shadow(0 0 8px var(--card-accent)); }
        .stat-number { font-size: 44px; font-weight: 800; color: var(--card-accent); line-height: 1; letter-spacing: -1px; display: block; font-variant-numeric: tabular-nums; animation: countUp 0.6s ease forwards; }
        @keyframes countUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        .stat-label { display: block; font-size: 13px; color: #aaa; margin-top: 6px; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }

        .search-bar { display: flex; gap: 12px; margin-bottom: 25px; }
        .search-bar .form-input { flex: 1; }
        .user-table-wrap { overflow-x: auto; overflow-y: visible; border-radius: 12px; }
        .user-table { overflow: visible; }
        .user-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .user-table th { background: rgba(188,106,106,0.15); color: #bc6a6a; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; font-size: 12px; padding: 12px 16px; text-align: left; white-space: nowrap; }
        .user-table td { padding: 12px 16px; border-bottom: 1px solid rgba(255,255,255,0.06); color: #e0e0e0; vertical-align: middle; }
        .user-table tr:last-child td { border-bottom: none; }
        .user-table tr:hover td { background: rgba(255,255,255,0.03); }
        .user-table-wrap { scrollbar-width: none; }
        .user-table-wrap::-webkit-scrollbar { display: none; }
        .badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .badge-admin  { background: rgba(188,106,106,0.25); color: #bc6a6a; border: 1px solid rgba(188,106,106,0.4); }
        .badge-staff  { background: rgba(188,154,106,0.25); color: #bc9a6a; border: 1px solid rgba(188,154,106,0.4); }
        .badge-member { background: rgba(106,188,138,0.15); color: #6abc8a; border: 1px solid rgba(106,188,138,0.3); }
        .no-results { text-align: center; padding: 30px; color: #777; font-size: 14px; }
        .search-placeholder { text-align: center; padding: 30px; color: #555; font-size: 14px; font-style: italic; }
        .inline-form { display: inline; }
        .action-cell { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .btn-xs { padding: 5px 12px; font-size: 12px; border-radius: 8px; font-weight: 600; border: none; cursor: pointer; transition: all 0.2s ease; text-decoration: none; display: inline-block; }
        .btn-xs-promote { background: rgba(188,154,106,0.2); color: #bc9a6a; border: 1px solid rgba(188,154,106,0.4); }
        .btn-xs-promote:hover { background: rgba(188,154,106,0.4); }
        .btn-xs-demote  { background: rgba(106,158,188,0.2); color: #6a9ebc; border: 1px solid rgba(106,158,188,0.4); }
        .btn-xs-demote:hover  { background: rgba(106,158,188,0.4); }
        .btn-xs-delete  { background: rgba(231,76,60,0.15); color: #ff6b6b; border: 1px solid rgba(231,76,60,0.35); }
        .btn-xs-delete:hover  { background: rgba(231,76,60,0.35); }

        .announces-wrapper { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; align-items: start; }
        .announces-form, .announces-preview { display: flex; flex-direction: column; gap: 15px; }
        .announce-input-group { display: flex; flex-direction: column; gap: 8px; }
        .announce-input-label { font-size: 13px; font-weight: 700; color: #e0e0e0; text-transform: uppercase; letter-spacing: 0.8px; }
        .announce-date-input { padding: 10px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15); background: rgba(0,0,0,0.3); color: #fff; font-size: 14px; }
        .announce-date-input:focus { outline: none; border-color: #bc6a6a; }
        .announce-text-input { padding: 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15); background: rgba(0,0,0,0.3); color: #fff; font-size: 14px; font-family: inherit; min-height: 80px; resize: vertical; }
        .announce-text-input:focus { outline: none; border-color: #bc6a6a; }
        .announce-add-btn { padding: 12px 24px; background: #bc6a6a; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; transition: all 0.3s ease; }
        .announce-add-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(188,106,106,0.4); }
        .announces-list { display: flex; flex-direction: column; gap: 12px; max-height: 400px; overflow-y: auto; }
        .announce-item-admin { background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: space-between; align-items: start; gap: 12px; }
        .announce-item-admin strong { color: #bc6a6a; display: block; font-size: 13px; margin-bottom: 5px; }
        .announce-item-admin small { color: #999; font-size: 12px; }
        .announce-item-admin p { color: #e0e0e0; margin: 8px 0 0 0; font-size: 14px; }
        .announce-delete-btn { padding: 5px 10px; background: rgba(231,76,60,0.15); color: #ff6b6b; border: 1px solid rgba(231,76,60,0.35); border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 600; white-space: nowrap; transition: all 0.2s ease; }
        .announce-delete-btn:hover { background: rgba(231,76,60,0.35); }
        .announces-empty { text-align: center; padding: 30px; color: #666; font-size: 14px; font-style: italic; }
        .announce-item-edit{background:rgba(255,255,255,.05);border:1px solid rgba(188,106,106,.2);border-radius:12px;padding:16px;margin-bottom:12px;transition:border-color .3s ease}
        .announce-item-edit:hover{border-color:rgba(188,106,106,.4)}
        .announce-item-edit-field{margin-bottom:12px}
        .announce-item-edit-field:last-child{margin-bottom:0}
        .announce-item-edit-label{display:block;color:#bc6a6a;font-size:12px;font-weight:600;margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px}
        .announce-item-edit-input,.announce-item-edit-textarea{width:100%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:8px;color:#fff;font-size:14px;padding:10px;font-family:inherit;outline:none;transition:border-color .3s ease}
        .announce-item-edit-input:focus,.announce-item-edit-textarea:focus{border-color:#bc6a6a;background:rgba(255,255,255,.12)}
        .announce-item-edit-textarea{min-height:80px;resize:vertical}
        .announce-item-edit-actions{display:flex;gap:8px;margin-top:12px;justify-content:flex-end}
        .announce-item-delete-btn{padding:6px 12px;border-radius:6px;background:rgba(231,76,60,.2);border:1px solid rgba(231,76,60,.4);color:#e74c3c;font-size:12px;cursor:pointer;font-weight:600;transition:all .3s ease}
        .announce-item-delete-btn:hover{background:rgba(231,76,60,.3);border-color:#e74c3c}
        .announce-no-items{text-align:center;color:#666;padding:20px;font-size:14px}

        .btn-outline { background: transparent; color: #bc6a6a; border: 1px solid rgba(188,106,106,0.5); padding: 10px 18px; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s ease; white-space: nowrap; }
        .btn-outline:hover { background: rgba(188,106,106,0.15); border-color: #bc6a6a; }

        .btn-dots { background: rgba(255,255,255,0.07); color: #ccc; border: 1px solid rgba(255,255,255,0.15); padding: 5px 11px; border-radius: 8px; font-size: 16px; font-weight: 700; cursor: pointer; transition: all 0.2s ease; line-height: 1; letter-spacing: 2px; }
        .btn-dots:hover { background: rgba(188,106,106,0.2); color: #bc6a6a; border-color: rgba(188,106,106,0.4); }

        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.75); z-index: 9000; align-items: center; justify-content: center; padding: 20px; }
        .modal-overlay.active { display: flex; }
        .modal-box { background: #111; border: 1px solid rgba(188,106,106,0.3); border-radius: 18px; padding: 30px; max-width: 560px; width: 100%; max-height: 80vh; display: flex; flex-direction: column; box-shadow: 0 20px 60px rgba(0,0,0,0.7); animation: modalIn 0.25s ease; }
        @keyframes modalIn { from { opacity:0; transform:scale(0.94) translateY(12px); } to { opacity:1; transform:scale(1) translateY(0); } }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .modal-title { font-size: 18px; font-weight: 700; color: #bc6a6a; }
        .modal-close { background: none; border: none; color: #888; font-size: 22px; cursor: pointer; line-height: 1; padding: 4px 8px; border-radius: 6px; transition: color 0.2s; }
        .modal-close:hover { color: #fff; }
        .modal-body { overflow-y: auto; flex: 1; }
        .ratings-list { display: flex; flex-direction: column; gap: 10px; }
        .rating-item { display: flex; align-items: center; gap: 14px; background: rgba(255,255,255,0.04); border-radius: 10px; padding: 12px 15px; border: 1px solid rgba(255,255,255,0.07); }
        .rating-stars { font-size: 20px; font-weight: 800; color: #f5c842; min-width: 36px; text-align: center; }
        .rating-serie { flex: 1; font-size: 14px; color: #e0e0e0; }
        .rating-serie small { display: block; color: #666; font-size: 12px; margin-top: 2px; }
        .modal-empty { text-align: center; color: #555; font-style: italic; padding: 30px 0; }
        .modal-loading { text-align: center; color: #777; padding: 30px 0; }

        @media (max-width: 900px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 768px) {
            .content { padding: 40px 15px; }
            .page-title { font-size: 36px; }
            .admin-section { padding: 25px 20px; }
            .section-title { font-size: 22px; }
            .carousel-item { flex-direction: column; text-align: center; }
            .carousel-thumbnail { width: 100%; height: 150px; }
            .drag-handle { position: absolute; top: 10px; left: 10px; }
            .carousel-actions { flex-direction: column; width: 100%; }
            .quick-actions { flex-direction: column; }
            .btn { width: 100%; }
            .search-bar { flex-direction: column; }
        }
        @media (max-width: 480px) {
            .page-title { font-size: 30px; }
            .admin-section { padding: 20px 15px; }
            .section-title { font-size: 20px; }
            .sub-section { padding: 20px; }
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 12px; }
            .stat-number { font-size: 34px; }
        }
    </style>
</head>
<body>

    <?php include 'header.php'; ?>

    <div class="content">
        <?php if (!empty($publish_success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($publish_success); ?></div>
        <?php endif; ?>
        <?php if (!empty($publish_error)): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($publish_error); ?></div>
        <?php endif; ?>
        <?php if (!empty($carousel_success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($carousel_success); ?></div>
        <?php endif; ?>
        <?php if (!empty($carousel_error)): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($carousel_error); ?></div>
        <?php endif; ?>
        <?php if (!empty($account_msg)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($account_msg); ?></div>
        <?php endif; ?>
        <?php if (!empty($account_error)): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($account_error); ?></div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card stat-card--series">
                <svg class="stat-icon" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="6" y="28" width="32" height="6" rx="2" fill="#bc6a6a" opacity="0.35"/>
                    <rect x="8" y="20" width="28" height="7" rx="2" fill="#bc6a6a" opacity="0.6"/>
                    <rect x="10" y="10" width="24" height="9" rx="2" fill="#bc6a6a"/>
                    <line x1="15" y1="10" x2="15" y2="19" stroke="rgba(0,0,0,0.25)" stroke-width="1.5"/>
                </svg>
                <span class="stat-number"><?php echo $stats['series']; ?></span>
                <span class="stat-label">Séries</span>
            </div>
            <div class="stat-card stat-card--chapters">
                <svg class="stat-icon" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="10" y="5" width="24" height="34" rx="3" fill="#6a9ebc" opacity="0.25"/>
                    <path d="M10 9a3 3 0 0 1 3-3h14l7 7v26a3 3 0 0 1-3 3H13a3 3 0 0 1-3-3V9z" fill="#6a9ebc" opacity="0.5"/>
                    <path d="M27 6v7h7" fill="none" stroke="#6a9ebc" stroke-width="1.5" stroke-linejoin="round"/>
                    <line x1="15" y1="20" x2="29" y2="20" stroke="#6a9ebc" stroke-width="2" stroke-linecap="round"/>
                    <line x1="15" y1="25" x2="29" y2="25" stroke="#6a9ebc" stroke-width="2" stroke-linecap="round"/>
                    <line x1="15" y1="30" x2="23" y2="30" stroke="#6a9ebc" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span class="stat-number"><?php echo $stats['chapitres']; ?></span>
                <span class="stat-label">Chapitres</span>
            </div>
            <div class="stat-card stat-card--members">
                <svg class="stat-icon" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="16" cy="14" r="6" fill="#6abc8a" opacity="0.7"/>
                    <path d="M4 36c0-7 5.4-12 12-12s12 5 12 12" fill="#6abc8a" opacity="0.5"/>
                    <circle cx="31" cy="13" r="5" fill="#6abc8a"/>
                    <path d="M28 36c0-5.5 3.5-10 8-11.5" stroke="#6abc8a" stroke-width="2.5" stroke-linecap="round" fill="none" opacity="0.9"/>
                </svg>
                <span class="stat-number"><?php echo $stats['membres']; ?></span>
                <span class="stat-label">Membres</span>
            </div>
            <div class="stat-card stat-card--staff">
                <svg class="stat-icon" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22 4L8 10v12c0 8.5 6 16.5 14 19 8-2.5 14-10.5 14-19V10L22 4z" fill="#bc9a6a" opacity="0.3"/>
                    <path d="M22 4L8 10v12c0 8.5 6 16.5 14 19 8-2.5 14-10.5 14-19V10L22 4z" stroke="#bc9a6a" stroke-width="2" stroke-linejoin="round" fill="none"/>
                    <path d="M22 14l1.8 5.5H29l-4.3 3.1 1.6 5.4L22 25l-4.3 3-1.6-5.4L12 19.5h5.2z" fill="#bc9a6a"/>
                </svg>
                <span class="stat-number"><?php echo $stats['staff']; ?></span>
                <span class="stat-label">Staff</span>
            </div>
        </div>

        <div class="admin-section">
            <h2 class="section-title">Recherche de comptes</h2>

            <form method="POST" class="search-bar">
                <input type="hidden" name="action" value="search_users">
                <input
                    type="text"
                    name="search_query"
                    class="form-input"
                    placeholder="Rechercher par pseudo…"
                    value="<?php echo htmlspecialchars($search_query); ?>"
                >
                <button type="submit" class="btn btn-primary">Rechercher</button>
                <button type="button" class="btn-outline" onclick="loadAllMembers()">Tous les membres</button>
            </form>

            <?php if (!empty($search_error)): ?>
                <div class="alert alert-error"><?php echo $search_error; ?></div>
            <?php endif; ?>

            <?php if ($search_performed && empty($search_error)): ?>
                <?php if (empty($search_results)): ?>
                    <div class="no-results">Aucun compte trouvé pour « <?php echo htmlspecialchars($search_query); ?> ».</div>
                <?php else: ?>
                    <div class="user-table-wrap">
                        <table class="user-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Pseudo</th>
                                    <th>Rôle</th>
                                    <th>Inscrit le</th>
                                    <th>Actions</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($search_results as $u): ?>
                                <tr>
                                    <td><?php echo $u['id']; ?></td>
                                    <td><?php echo htmlspecialchars($u['username']); ?></td>
                                    <td>
                                        <?php
                                        if ($u['is_admin'] >= 1) { $curRole = 'admin'; $badgeCls = 'badge-admin'; $badgeLbl = 'Admin'; }
                                        elseif (!empty($u['is_staff'])) { $curRole = 'staff'; $badgeCls = 'badge-staff'; $badgeLbl = 'Staff'; }
                                        else { $curRole = 'membre'; $badgeCls = 'badge-member'; $badgeLbl = 'Membre'; }
                                        ?>
                                        <span class="badge <?= $badgeCls ?>"><?= $badgeLbl ?></span>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($u['created_at'])); ?></td>
                                    <td>
                                        <div class="action-cell">
                                            <?php if ($u['id'] !== (int)($_SESSION['user_id'] ?? 0)): ?>
                                            <form method="POST" class="inline-form" onsubmit="return confirm('Changer le rôle de ce membre ?')">
                                                <input type="hidden" name="action"       value="toggle_admin">
                                                <input type="hidden" name="target_id"    value="<?php echo $u['id']; ?>">
                                                <input type="hidden" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>">
                                                <input type="hidden" name="do_search"    value="1">
                                                <div class="role-drop" style="position:relative;display:inline-block;">
                                                    <button type="button" onclick="toggleRoleDrop(this)" class="btn-xs btn-xs-promote" style="min-width:75px;display:flex;align-items:center;gap:4px;justify-content:space-between;"><?= $badgeLbl ?> <span style="font-size:10px;">▼</span></button>
                                                    <div class="role-menu" style="display:none;position:absolute;top:110%;left:0;background:#111;border:1px solid rgba(188,106,106,.4);border-radius:10px;z-index:999;overflow:hidden;min-width:90px;box-shadow:0 8px 24px rgba(0,0,0,.7);">
                                                        <?php foreach(['membre','staff','admin'] as $r): ?>
                                                        <button type="submit" name="new_role" value="<?= $r ?>" style="display:block;width:100%;padding:9px 14px;background:<?= $curRole===$r?'rgba(188,106,106,.25)':'transparent' ?>;color:<?= $curRole===$r?'#bc6a6a':'#fff' ?>;border:none;cursor:pointer;font-size:13px;font-weight:600;text-align:left;"><?= ucfirst($r) ?></button>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                            </form>
                                            <?php endif; ?>

                                            <?php if ($u['id'] !== (int)($_SESSION['user_id'] ?? 0)): ?>
                                                <form method="POST" class="inline-form">
                                                    <input type="hidden" name="action"       value="delete_user">
                                                    <input type="hidden" name="target_id"    value="<?php echo $u['id']; ?>">
                                                    <input type="hidden" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>">
                                                    <input type="hidden" name="do_search"    value="1">
                                                    <button type="submit" class="btn-xs btn-xs-delete"
                                                            onclick="return confirm('Supprimer définitivement ce compte ?')">
                                                        Supprimer
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <button class="btn-dots" title="Voir les séries notées"
                                            onclick="openRatingsModal(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars(addslashes($u['username'])); ?>')">
                                            ···
                                        </button>
                                        <a href="profil.php?user_id=<?php echo $u['id']; ?>" class="btn-xs btn-xs-promote" title="Voir le profil" target="_blank" style="margin-left:6px;text-decoration:none;"></a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <p style="text-align:right;color:#666;font-size:12px;margin-top:10px;">
                        <?php echo count($search_results); ?> résultat(s) — max. 50 affichés
                    </p>
                <?php endif; ?>
            <?php else: ?>
                <div class="search-placeholder" id="searchPlaceholder">Entrez un pseudo pour trouver un compte.</div>
            <?php endif; ?>

            <div id="allMembersWrap" style="display:none; margin-top: 20px;"></div>
        </div>

        <div class="admin-section">
            <h2 class="section-title">Gestion du Carousel</h2>

            <div class="sub-section">
                <h3 class="section-subtitle"><?php echo $edit_image ? 'Modifier l\'image' : 'Ajouter une image'; ?></h3>

                <?php if ($edit_image): ?>
                <div class="image-preview-wrap">
                    <p class="preview-label">Aperçu de l'image</p>
                    <div class="preview-pc">
                        <img id="imagePreview"
                             src="<?php echo htmlspecialchars($edit_image['image_url']); ?>"
                             alt="Aperçu"
                             onerror="this.style.display='none';document.getElementById('previewError').style.display='block'">
                    </div>
                    <p id="previewError" style="display:none;color:#ff6b6b;font-size:13px;margin-bottom:10px;">Image introuvable ou URL invalide.</p>
                </div>
                <?php else: ?>
                <div class="image-preview-wrap" id="newPreviewWrap" style="display:none;">
                    <p class="preview-label">Aperçu</p>
                    <div class="preview-pc">
                        <img id="imagePreviewNew" src="" alt="Aperçu"
                             onerror="this.style.display='none'">
                    </div>
                </div>
                <?php endif; ?>

                <form method="POST" class="admin-form">
                    <input type="hidden" name="action" value="<?php echo $edit_image ? 'edit_carousel' : 'add_carousel'; ?>">
                    <?php if ($edit_image): ?>
                        <input type="hidden" name="image_id" value="<?php echo $edit_image['id']; ?>">
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="image_url" class="form-label">URL de l'image *</label>
                        <input type="url" id="image_url" name="image_url" class="form-input"
                               placeholder="https://example.com/image.jpg"
                               value="<?php echo $edit_image ? htmlspecialchars($edit_image['image_url']) : ''; ?>"
                               oninput="updatePreview(this.value)"
                               required>
                    </div>

                    <div class="form-group">
                        <label for="carousel_title" class="form-label">Titre *</label>
                        <input type="text" id="carousel_title" name="carousel_title" class="form-input"
                               placeholder="Titre affiché sur l'image"
                               value="<?php echo $edit_image ? htmlspecialchars($edit_image['title']) : ''; ?>"
                               required>
                    </div>

                    <div class="form-group">
                        <label for="carousel_description" class="form-label">Description</label>
                        <textarea id="carousel_description" name="carousel_description" class="form-textarea"
                                  placeholder="Description de l'image" rows="3"><?php echo $edit_image ? htmlspecialchars($edit_image['description']) : ''; ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="link_url" class="form-label">Lien de redirection</label>
                        <input type="text" id="link_url" name="link_url" class="form-input"
                               value="<?php echo $edit_image ? htmlspecialchars($edit_image['link_url'] ?? '') : ''; ?>">
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="submit" class="btn <?php echo $edit_image ? 'btn-primary' : 'btn-success'; ?>">
                            <?php echo $edit_image ? 'Modifier l\'image' : 'Ajouter l\'image'; ?>
                        </button>
                        <?php if ($edit_image): ?>
                            <a href="admin.php" class="btn btn-secondary">Annuler</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <h3 class="section-subtitle">Images actuelles (<?php echo count($carousel_images); ?>)</h3>
            <?php if (!empty($carousel_images)): ?>
                <div class="carousel-list" id="carouselList">
                    <?php foreach ($carousel_images as $image): ?>
                    <div class="carousel-item" data-id="<?php echo $image['id']; ?>" draggable="true">
                        <span class="drag-handle">☰</span>
                        <img src="<?php echo htmlspecialchars($image['image_url']); ?>"
                             alt="<?php echo htmlspecialchars($image['title']); ?>"
                             class="carousel-thumbnail">

                        <div class="carousel-info">
                            <strong><?php echo htmlspecialchars($image['title']); ?></strong>
                            <small><?php echo htmlspecialchars($image['description'] ?? 'Aucune description'); ?></small>

                            <?php if (!empty($image['link_url'])): ?>
                                <div class="link-display">
                                    <a href="<?php echo htmlspecialchars($image['link_url']); ?>" target="_blank">
                                        <?php echo htmlspecialchars($image['link_url']); ?>
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="no-link">Aucun lien (image non-cliquable)</div>
                            <?php endif; ?>

                            <small class="date">Ajoutée le <?php echo date('d/m/Y à H:i', strtotime($image['created_at'])); ?></small>
                        </div>

                        <div class="carousel-actions">
                            <a href="admin.php?edit_carousel=<?php echo $image['id']; ?>"
                               class="btn btn-warning">Modifier</a>
                            <form method="POST" style="display: inline;"
                                  onsubmit="return confirm('Voulez-vous vraiment supprimer cette image du carousel ?');">
                                <input type="hidden" name="action" value="delete_carousel">
                                <input type="hidden" name="image_id" value="<?php echo $image['id']; ?>">
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-message">Aucune image dans le carousel pour le moment.</div>
            <?php endif; ?>
        </div>

        <div class="admin-section">
            <h2 class="section-title">Planning des Sorties</h2>
            <p style="color: #999; margin-bottom: 20px;">Gérez le planning hebdomadaire des sorties de chapitres</p>
            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                <a href="admin_planning.php" class="btn btn-primary">Gérer le planning</a>
                <a href="planning.php" class="btn btn-secondary" target="_blank">Voir le planning public</a>
            </div>
        </div>

        <div class="admin-section">
            <h2 class="section-title">Annonces et Mises à Jour</h2>
            <p style="color: #999; margin-bottom: 25px;">Gérez les annonces affichées dans le losange mégaphone. Modifiez chaque annonce individuellement.</p>
            
            <div id="adminAnnounceEditorList" style="margin-bottom:20px;">
                <div class="announce-no-items">Chargement des annonces...</div>
            </div>
            
            <button id="adminAddAnnounceBtn" style="width:100%;padding:12px 20px;border-radius:10px;background:rgba(102,126,234,.2);border:2px dashed rgba(102,126,234,.5);color:#667eea;cursor:pointer;font-weight:700;font-size:14px;margin-bottom:16px;">+ Ajouter une annonce</button>
            
            <div style="display:flex;gap:10px;justify-content:flex-end;">
                <button id="adminResetAnnounceBtn" style="padding:10px 20px;border-radius:10px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff;cursor:pointer;font-size:14px;">Réinitialiser</button>
                <button id="adminSaveAnnounceBtn" style="padding:10px 20px;border-radius:10px;background:#bc6a6a;border:none;color:#fff;cursor:pointer;font-weight:700;font-size:14px;">Sauvegarder</button>
            </div>
        </div>

        <div class="admin-section">
            <h2 class="section-title">Photos de Profil & Bannières</h2>
            <p style="color:#999; margin-bottom:25px;">Gérez les photos de profil et bannières disponibles pour les membres. Les images sont en cercle pour les avatars. Utilisez des liens Imgur directs (se terminant par .jpg/.png).</p>

            <?php if ($avatar_msg): ?>
                <div class="alert alert-success" style="margin-bottom:20px;"><?= htmlspecialchars($avatar_msg) ?></div>
            <?php endif; ?>
            <?php if ($avatar_error): ?>
                <div class="alert alert-error" style="margin-bottom:20px;"><?= htmlspecialchars($avatar_error) ?></div>
            <?php endif; ?>

            <h3 class="section-subtitle">photo de profil (<?= count($all_avatars) ?>)</h3>
            <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">
                <input type="hidden" name="action" value="add_avatar">
                <input type="url" name="av_image_url" class="form-input" placeholder="URL Imgur (https://i.imgur.com/xxx.jpg)" required style="flex:1;min-width:250px;">
                <input type="text" name="av_label" class="form-input" placeholder="Label (ex: Guerrier)" style="max-width:200px;">
                <button type="submit" class="btn btn-success">Ajouter photo de profil</button>
            </form>

            <?php if (!empty($all_avatars)): ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:14px;margin-bottom:32px;">
                <?php foreach ($all_avatars as $av): ?>
                <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px 8px;text-align:center;position:relative;">
                    <img src="<?= htmlspecialchars($av['image_url']) ?>" alt="" style="width:70px;height:70px;border-radius:50%;object-fit:cover;display:block;margin:0 auto 8px;">
                    <div style="font-size:11px;color:#888;margin-bottom:8px;word-break:break-word;"><?= htmlspecialchars($av['label'] ?: '—') ?></div>
                    <form method="POST" onsubmit="return confirm('Supprimer cet avatar ?')">
                        <input type="hidden" name="action" value="delete_avatar">
                        <input type="hidden" name="av_id" value="<?= $av['id'] ?>">
                        <button type="submit" class="btn btn-danger" style="font-size:11px;padding:4px 10px;">✕ Suppr.</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p style="color:#555;font-size:14px;margin-bottom:32px;">Aucun avatar ajouté pour l'instant.</p>
            <?php endif; ?>

            <h3 class="section-subtitle">Bannières (<?= count($all_banners) ?>)</h3>
            <form method="POST" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">
                <input type="hidden" name="action" value="add_banner">
                <input type="url" name="bn_image_url" class="form-input" placeholder="URL Imgur (https://i.imgur.com/xxx.jpg)" required style="flex:1;min-width:250px;">
                <input type="text" name="bn_label" class="form-input" placeholder="Label (ex: Forêt Enneigée)" style="max-width:200px;">
                <button type="submit" class="btn btn-success">Ajouter bannière</button>
            </form>

            <?php if (!empty($all_banners)): ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;">
                <?php foreach ($all_banners as $bn): ?>
                <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:12px;overflow:hidden;position:relative;">
                    <img src="<?= htmlspecialchars($bn['image_url']) ?>" alt="" style="width:100%;aspect-ratio:16/5;object-fit:cover;display:block;">
                    <div style="padding:8px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px;">
                        <span style="font-size:12px;color:#888;"><?= htmlspecialchars($bn['label'] ?: '—') ?></span>
                        <form method="POST" onsubmit="return confirm('Supprimer cette bannière ?')" style="margin:0;">
                            <input type="hidden" name="action" value="delete_banner">
                            <input type="hidden" name="bn_id" value="<?= $bn['id'] ?>">
                            <button type="submit" class="btn btn-danger" style="font-size:11px;padding:4px 10px;">✕</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p style="color:#555;font-size:14px;">Aucune bannière ajoutée pour l'instant.</p>
            <?php endif; ?>
        </div>

        <div class="quick-actions">
            <a href="add_manga.php" class="btn btn-success">Ajouter un nouveau manga</a>
            <a href="index.php" class="btn btn-primary">Retour à l'accueil</a>
        </div>
    </div>

    <script>
        function updatePreview(url) {
            var preview = document.getElementById('imagePreview');
            var err     = document.getElementById('previewError');
            if (preview) {
                preview.src = url;
                preview.style.display = '';
                if (err) err.style.display = 'none';
                return;
            }
            var wrap     = document.getElementById('newPreviewWrap');
            var preview2 = document.getElementById('imagePreviewNew');
            if (wrap && preview2 && url.length > 10) {
                preview2.src = url;
                preview2.style.display = '';
                wrap.style.display = '';
            } else if (wrap) {
                wrap.style.display = 'none';
            }
        }

        const carouselList = document.getElementById('carouselList');
        if (carouselList) {
            carouselList.addEventListener('dragstart', (e) => {
                if (e.target.classList.contains('carousel-item')) {
                    e.target.classList.add('dragging');
                }
            });

            carouselList.addEventListener('dragend', (e) => {
                if (e.target.classList.contains('carousel-item')) {
                    e.target.classList.remove('dragging');
                    saveOrder();
                }
            });

            carouselList.addEventListener('dragover', (e) => {
                e.preventDefault();
                const afterElement = getDragAfterElement(carouselList, e.clientY);
                const draggable = document.querySelector('.dragging');
                if (afterElement == null) {
                    carouselList.appendChild(draggable);
                } else {
                    carouselList.insertBefore(draggable, afterElement);
                }
            });

            function getDragAfterElement(container, y) {
                const draggableElements = [...container.querySelectorAll('.carousel-item:not(.dragging)')];
                return draggableElements.reduce((closest, child) => {
                    const box    = child.getBoundingClientRect();
                    const offset = y - box.top - box.height / 2;
                    if (offset < 0 && offset > closest.offset) {
                        return { offset: offset, element: child };
                    } else {
                        return closest;
                    }
                }, { offset: Number.NEGATIVE_INFINITY }).element;
            }

            function saveOrder() {
                const items     = carouselList.querySelectorAll('.carousel-item');
                const orderData = [];
                items.forEach((item, index) => {
                    orderData.push({ id: item.dataset.id, order: index });
                });

                const formData = new FormData();
                formData.append('action', 'update_order');
                formData.append('order_data', JSON.stringify(orderData));

                fetch(window.location.href, { method: 'POST', body: formData })
                    .then(response => response.text())
                    .then(() => {
                        const msg = document.createElement('div');
                        msg.className = 'alert alert-success';
                        msg.textContent = 'Ordre mis à jour !';
                        msg.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;';
                        document.body.appendChild(msg);
                        setTimeout(() => msg.remove(), 2000);
                    })
                    .catch(error => {
                        console.error('Erreur:', error);
                        alert('Erreur lors de la sauvegarde de l\'ordre');
                    });
            }
        }

        let adminAnnouncesEditing = [];

        function formatDateForInput(dateStr) {
            if (!dateStr) return new Date().toISOString().split('T')[0];
            const parts = dateStr.split('/');
            if (parts.length === 3) return `${parts[2]}-${parts[1]}-${parts[0]}`;
            return dateStr;
        }

        function loadAdminAnnouncesList() {
            fetch('getters/get_announces.php').then(r => r.json()).then(announces => {
                adminAnnouncesEditing = announces.reverse().map(a => ({
                    date: formatDateForInput(a.date),
                    title: a.title || '',
                    message: a.message || ''
                }));
                renderAdminAnnouncesList();
            }).catch(() => {});
        }

        function renderAdminAnnouncesList() {
            const list = document.getElementById('adminAnnounceEditorList');
            if (adminAnnouncesEditing.length === 0) {
                list.innerHTML = '<div class="announce-no-items">Aucune annonce. Cliquez sur "+ Ajouter" pour en créer une.</div>';
                return;
            }
            list.innerHTML = adminAnnouncesEditing.map((a, i) => `
                <div class="announce-item-edit">
                    <div class="announce-item-edit-field">
                        <label class="announce-item-edit-label">Date</label>
                        <input type="date" class="announce-item-edit-input" value="${a.date}" oninput="adminAnnouncesEditing[${i}].date = this.value">
                    </div>
                    <div class="announce-item-edit-field">
                        <label class="announce-item-edit-label">Titre (optionnel)</label>
                        <input type="text" class="announce-item-edit-input" placeholder="Titre de l'annonce..." value="${a.title}" oninput="adminAnnouncesEditing[${i}].title = this.value" maxlength="200">
                    </div>
                    <div class="announce-item-edit-field">
                        <label class="announce-item-edit-label">Message</label>
                        <textarea class="announce-item-edit-textarea" placeholder="Message de l'annonce..." oninput="adminAnnouncesEditing[${i}].message = this.value">${a.message}</textarea>
                    </div>
                    <div class="announce-item-edit-actions">
                        <button class="announce-item-delete-btn" onclick="deleteAdminAnnounceItem(${i})">Supprimer</button>
                    </div>
                </div>
            `).join('');
        }

        function deleteAdminAnnounceItem(index) {
            if (confirm('Êtes-vous sûr de vouloir supprimer cette annonce ?')) {
                adminAnnouncesEditing.splice(index, 1);
                renderAdminAnnouncesList();
            }
        }

        document.getElementById('adminAddAnnounceBtn')?.addEventListener('click', () => {
            adminAnnouncesEditing.unshift({
                date: new Date().toISOString().split('T')[0],
                title: '',
                message: ''
            });
            renderAdminAnnouncesList();
        });

        document.getElementById('adminSaveAnnounceBtn')?.addEventListener('click', () => {
            const content = adminAnnouncesEditing.map(a => {
                if (!a.date) return '';
                if (a.title && a.message) {
                    return `${a.date} | ${a.title} | ${a.message}`;
                } else if (a.message) {
                    return `${a.date} | ${a.message}`;
                }
                return '';
            }).filter(l => l.trim()).join('\n');
            
            fetch('setters/save_announces.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ content: content }) })
                .then(r => r.json()).then(d => {
                    if (d.success) { 
                        alert('Annonces sauvegardées avec succès !');
                        loadAdminAnnouncesList();
                    } else {
                        alert('Erreur: ' + (d.error || 'Impossible de sauvegarder'));
                    }
                }).catch(() => alert('Erreur lors de la sauvegarde'));
        });

        document.getElementById('adminResetAnnounceBtn')?.addEventListener('click', () => {
            if (confirm('Êtes-vous sûr ? Les modifications non sauvegardées seront perdues.')) {
                loadAdminAnnouncesList();
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            loadAdminAnnouncesList();
        });
    </script>

    <?php include 'footer.php'; ?>
    <div class="modal-overlay" id="ratingsModal" onclick="if(event.target===this)closeRatingsModal()">
        <div class="modal-box">
            <div class="modal-header">
                <span class="modal-title" id="ratingsModalTitle">Séries notées</span>
                <button class="modal-close" onclick="closeRatingsModal()">✕</button>
            </div>
            <div class="modal-body">
                <div id="ratingsModalContent" class="modal-loading">Chargement…</div>
            </div>
        </div>
    </div>

    <script>
        function loadAllMembers() {
            const wrap = document.getElementById('allMembersWrap');
            const placeholder = document.getElementById('searchPlaceholder');
            if (placeholder) placeholder.style.display = 'none';
            wrap.style.display = 'block';
            wrap.innerHTML = '<div style="text-align:center;color:#777;padding:20px;">Chargement…</div>';

            fetch('getters/admin_get_members.php')
                .then(r => r.json())
                .then(members => {
                    if (!members || members.length === 0) {
                        wrap.innerHTML = '<div class="no-results">Aucun membre trouvé.</div>';
                        return;
                    }
                    let html = `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                        <span style="color:#999;font-size:13px;">${members.length} membre(s) au total</span>
                        <button onclick="document.getElementById('allMembersWrap').style.display='none'; const p=document.getElementById('searchPlaceholder'); if(p)p.style.display='';" class="btn-xs btn-xs-delete" style="font-size:11px;">✕ Fermer</button>
                    </div>
                    <div class="user-table-wrap"><table class="user-table">
                        <thead><tr><th>#</th><th>Pseudo</th><th>Rôle</th><th>Inscrit le</th><th>Actions</th></tr></thead>
                        <tbody>`;
                    members.forEach(u => {
                        let curRole, badgeCls, badgeLbl;
                        if (parseInt(u.is_admin) >= 1) { curRole='admin'; badgeCls='badge-admin'; badgeLbl='Admin'; }
                        else if (parseInt(u.is_staff) >= 1) { curRole='staff'; badgeCls='badge-staff'; badgeLbl='Staff'; }
                        else { curRole='membre'; badgeCls='badge-member'; badgeLbl='Membre'; }

                        const date = new Date(u.created_at).toLocaleDateString('fr-FR');
                        html += `<tr>
                            <td>${u.id}</td>
                            <td>${escHtml(u.username)}</td>
                            <td><span class="badge ${badgeCls}">${badgeLbl}</span></td>
                            <td>${date}</td>
                            <td style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                                <div class="role-drop" style="position:relative;display:inline-block;">
                                    <button type="button" onclick="toggleRoleDrop(this)" class="btn-xs btn-xs-promote" style="min-width:75px;display:flex;align-items:center;gap:4px;justify-content:space-between;">${badgeLbl} <span style="font-size:10px;">▼</span></button>
                                    <div class="role-menu" style="display:none;position:absolute;top:110%;left:0;background:#111;border:1px solid rgba(188,106,106,.4);border-radius:10px;z-index:9999;overflow:hidden;min-width:90px;box-shadow:0 8px 24px rgba(0,0,0,.7);">
                                            ${['membre','staff','admin'].map(r=>`<button type="button" onclick="changeRole(${u.id}, '${r}', this)" style="display:block;width:100%;padding:9px 14px;background:${curRole===r?'rgba(188,106,106,.25)':'transparent'};color:${curRole===r?'#bc6a6a':'#fff'};border:none;cursor:pointer;font-size:13px;font-weight:600;text-align:left;transition:background .2s;" onmouseover="this.style.background='rgba(188,106,106,.2)'" onmouseout="this.style.background='${curRole===r?'rgba(188,106,106,.25)':'transparent'}'">${r.charAt(0).toUpperCase()+r.slice(1)}</button>`).join('')}
                                    </div>
                                </div>
                                <button class="btn-dots" title="Voir les séries notées" onclick="openRatingsModal(${u.id}, '${escJs(u.username)}')" style="margin-left:2px;">···</button>
                                <a href="profil.php?user_id=${u.id}" class="btn-xs btn-xs-promote" style="text-decoration:none;">profil</a>
                            </td>
                        </tr>`;
                    });
                    html += '</tbody></table></div>';
                    wrap.innerHTML = html;
                })
                .catch(err => {
                    wrap.innerHTML = '<div class="alert alert-error">Erreur lors du chargement des membres.</div>';
                    console.error(err);
                });
        }

        function openRatingsModal(userId, username) {
            document.getElementById('ratingsModalTitle').textContent = 'Séries notées par ' + username;
            document.getElementById('ratingsModalContent').innerHTML = '<div class="modal-loading">Chargement…</div>';
            document.getElementById('ratingsModal').classList.add('active');

            fetch('getters/admin_get_ratings.php?user_id=' + userId)
                .then(r => r.json())
                .then(ratings => {
                    const content = document.getElementById('ratingsModalContent');
                    if (!ratings || ratings.length === 0) {
                        content.innerHTML = '<div class="modal-empty">Ce membre n\'a noté aucune série.</div>';
                        return;
                    }
                    let html = '<div class="ratings-list">';
                    ratings.forEach(r => {
                        const stars = '★'.repeat(Math.round(r.note)) + '☆'.repeat(5 - Math.round(r.note));
                        html += `<div class="rating-item">
                            <div class="rating-stars">${r.note}/5</div>
                            <div class="rating-serie">
                                ${escHtml(r.serie_title)}
                                <small>${stars} — noté le ${r.rated_at ? new Date(r.rated_at).toLocaleDateString('fr-FR') : '—'}</small>
                            </div>
                        </div>`;
                    });
                    html += '</div>';
                    content.innerHTML = html;
                })
                .catch(err => {
                    document.getElementById('ratingsModalContent').innerHTML =
                        '<div class="modal-empty" style="color:#ff6b6b;">Erreur lors du chargement.</div>';
                    console.error(err);
                });
        }

        function closeRatingsModal() {
            document.getElementById('ratingsModal').classList.remove('active');
        }
        function escHtml(str) {
            return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        }
        function escJs(str) {
            return String(str).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
        }

        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeRatingsModal(); });

        function toggleRoleDrop(btn) {
            const menu = btn.nextElementSibling;
            document.querySelectorAll('.role-menu').forEach(m => { if(m !== menu) m.style.display='none'; });
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
        }
        document.addEventListener('click', e => {
            if (!e.target.closest('.role-drop')) document.querySelectorAll('.role-menu').forEach(m => m.style.display='none');
        });

        function changeRole(userId, newRole, btn) {
            if (!confirm('Changer le rôle en "' + newRole + '" ?')) return;
            const fd = new FormData();
            fd.append('action', 'toggle_admin');
            fd.append('target_id', userId);
            fd.append('new_role', newRole);
            fetch(window.location.href, { method: 'POST', body: fd })
                .then(r => { if (r.ok) { location.reload(); } })
                .catch(() => alert('Erreur lors du changement de rôle'));
        }
    </script>

</body>
</html>