<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'check_captcha.php';
require_once 'db.php';

$error_message   = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error_message = 'Veuillez remplir tous les champs.';
    } elseif (mb_strlen($username) < 3) {
        $error_message = 'Le nom d\'utilisateur doit contenir au moins 3 caractères.';
    } elseif (mb_strlen($password) < 6) {
        $error_message = 'Le mot de passe doit contenir au moins 6 caractères.';
    } else {
        try {
            $check = $db->prepare("SELECT id FROM users WHERE username = ?");
            $check->execute([$username]);
            if ($check->fetch()) {
                $error_message = 'Ce nom d\'utilisateur existe déjà.';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
                $stmt->execute([$username, $hashed_password]);

                $success_message = 'Inscription réussie ! Vous pouvez maintenant vous connecter.';
            }
        } catch (PDOException $e) {
            error_log("Erreur register : " . $e->getMessage());
            $error_message = 'Erreur lors de l\'inscription. Veuillez réessayer.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - Yurei Scan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .register-container { display: flex; justify-content: center; align-items: center; min-height: calc(100vh - 160px); padding: 40px 20px; }
        .register-box { background: rgba(255,255,255,0.05); backdrop-filter: blur(15px); border-radius: 25px; padding: 45px 50px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 30px rgba(0,0,0,0.4); width: 100%; max-width: 450px; position: relative; overflow: hidden; }
        .register-box::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: #bc6a6a; }
        .register-title { text-align: center; font-size: 32px; margin-bottom: 35px; font-weight: 700; color: #bc6a6a; }
        .alert { padding: 15px 20px; border-radius: 12px; margin-bottom: 25px; font-size: 14px; animation: slideDown 0.3s ease; }
        .alert-error { background: rgba(231,76,60,0.15); border: 1px solid rgba(231,76,60,0.4); color: #ff6b6b; }
        .alert-success { background: rgba(40,167,69,0.15); border: 1px solid rgba(40,167,69,0.4); color: #51cf66; }
        .alert-success a { color: #51cf66; font-weight: 600; text-decoration: underline; }
        .alert-success a:hover { color: #40c057; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .register-form { display: flex; flex-direction: column; gap: 25px; }
        .form-group { display: flex; flex-direction: column; gap: 10px; }
        .form-label { font-size: 14px; font-weight: 600; color: #e0e0e0; }
        .form-input { padding: 14px 18px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.15); background: rgba(0,0,0,0.3); color: #fff; font-size: 15px; transition: all 0.3s ease; }
        .form-input:focus { outline: none; border-color: #bc6a6a; background: rgba(0,0,0,0.4); box-shadow: 0 0 0 3px rgba(188,106,106,0.1); }
        .form-input::placeholder { color: #777; }
        .submit-btn { background: #bc6a6a; color: white; border: none; padding: 15px; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(188,106,106,0.4); margin-top: 10px; }
        .submit-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(188,106,106,0.6); }
        .submit-btn:active { transform: translateY(0); }
        .form-footer { text-align: center; margin-top: 25px; padding-top: 25px; border-top: 1px solid rgba(255,255,255,0.1); }
        .form-footer a { color: #bc6a6a; text-decoration: none; font-weight: 600; transition: color 0.3s ease; }
        .form-footer a:hover { color: #a85c5c; text-decoration: underline; }
        .password-hint { font-size: 12px; color: #999; margin-top: -5px; }
        @media (max-width: 768px) { .register-box { padding: 35px 30px; } .register-title { font-size: 28px; } }
        @media (max-width: 480px) { .register-container { padding: 20px 10px; } .register-box { padding: 30px 25px; border-radius: 20px; } .register-title { font-size: 26px; } }
    </style>
</head>
<?php include 'header.php'; ?>
<body>

    <div class="register-container">
        <div class="register-box">
            <h2 class="register-title">Inscription</h2>

            <?php if (!empty($error_message)): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success_message); ?>
                    <a href="login.php">Se connecter maintenant</a>
                </div>
            <?php endif; ?>

            <form method="POST" class="register-form">
                <div class="form-group">
                    <label for="username" class="form-label">Nom d'utilisateur</label>
                    <input type="text" id="username" name="username" class="form-input"
                           placeholder="Choisissez un nom d'utilisateur"
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                           required autocomplete="username" minlength="3">
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Mot de passe</label>
                    <input type="password" id="password" name="password" class="form-input"
                           placeholder="Créez un mot de passe"
                           required autocomplete="new-password" minlength="6">
                    <p class="password-hint">Minimum 6 caractères</p>
                </div>

                <button type="submit" class="submit-btn">S'inscrire</button>
            </form>

            <div class="form-footer">
                <p>Déjà inscrit ? <a href="login.php">Se connecter</a></p>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>