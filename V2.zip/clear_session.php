<?php
session_start();
session_destroy();
echo "Session détruite. <a href='/'>Retour au site</a>";
?>