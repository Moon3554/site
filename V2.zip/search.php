<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';

header('Content-Type: application/json; charset=utf-8');

$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if (strlen($query) < 2) {
    http_response_code(200);
    echo json_encode([], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $show_adult  = (isset($_GET['adult']) && $_GET['adult'] === '1') || (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1);
    $adult_where = $show_adult ? '' : 'AND (is_adult = 0 OR is_adult IS NULL)';

    $stmt = $db->prepare("
        SELECT 
            id,
            title,
            image_url AS cover_image,
            status
        FROM mangas
        WHERE title LIKE :search
        $adult_where
        ORDER BY title ASC
        LIMIT 10
    ");

    $searchTerm = '%' . $query . '%';
    $stmt->execute([':search' => $searchTerm]);

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($results)) {
        echo json_encode([], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $countStmt = $db->prepare("
        SELECT COUNT(*) 
        FROM chapters 
        WHERE manga_id = :id
    ");

    foreach ($results as &$result) {
        $countStmt->execute([':id' => $result['id']]);
        $result['chapter_count'] = (int) $countStmt->fetchColumn();

        $result['cover_image'] = $result['cover_image'] ?: 'image/default.jpg';
        $result['status']      = $result['status']      ?: 'En cours';
    }

    echo json_encode($results, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

} catch (PDOException $e) {
    http_response_code(500);

    
    echo json_encode([
        'error' => 'Erreur serveur lors de la recherche'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Erreur inattendue'
    ], JSON_UNESCAPED_UNICODE);
}