<?php
require_once 'check_captcha.php';
session_start();
require_once 'db.php';

try {
    $stmt = $db->query("SELECT * FROM carousel_images WHERE is_active = 1 ORDER BY display_order ASC, id ASC");
    $db_carousel_images = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $carousel_images = [];
    foreach ($db_carousel_images as $img) {
        $cx = isset($img['crop_x']) && $img['crop_x'] !== null ? (float)$img['crop_x'] : null;
        $cy = isset($img['crop_y']) && $img['crop_y'] !== null ? (float)$img['crop_y'] : null;
        $cw = isset($img['crop_w']) && $img['crop_w'] !== null ? (float)$img['crop_w'] : null;
        $ch = isset($img['crop_h']) && $img['crop_h'] !== null ? (float)$img['crop_h'] : null;
        if ($cx !== null && $cw !== null) {
            $mob_ox = round(($cx + $cw / 2) * 100, 2);
            $mob_oy = round(($cy + $ch / 2) * 100, 2);
        } else {
            $mob_ox = 50;
            $mob_oy = 50;
        }
        $carousel_images[] = [
            'src'      => $img['image_url'],
            'alt'      => $img['description'] ?? $img['title'],
            'title'    => $img['title'],
            'link_url' => $img['link_url'] ?? null,
            'mob_ox'   => $mob_ox,
            'mob_oy'   => $mob_oy,
        ];
    }
    
    if (empty($carousel_images)) {
        $carousel_images = [
            [
                'src' => 'https://via.placeholder.com/1200x400/FF6B6B/FFFFFF?text=Carousel+Vide',
                'alt' => 'Aucune image configurée dans le carousel',
                'title' => 'Configuration requise',
                'link_url' => null
            ]
        ];
    }
} catch (PDOException $e) {
    $carousel_images = [
        [
            'src' => 'https://via.placeholder.com/1200x400/FF6B6B/FFFFFF?text=Erreur+Carousel',
            'alt' => 'Erreur de chargement du carousel',
            'title' => 'Erreur technique',
            'link_url' => null
        ]
    ];
}

try {
    $stmt = $db->query("
        SELECT DISTINCT
            m.id as manga_id, 
            m.title, 
            m.image_url, 
            m.status,
            c.chapter_number, 
            c.id as chapter_id, 
            c.created_at
        FROM chapters c
        JOIN mangas m ON c.manga_id = m.id
        ORDER BY c.created_at DESC
        LIMIT 5
    ");
    $dernières_sorties = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $dernières_sorties = [];
    error_log("Erreur récupération sorties: " . $e->getMessage());
}

try {
    $stmt = $db->query("
        SELECT m.id, m.title, m.image_url,
               COALESCE(SUM(c.views), 0) AS total_views
        FROM mangas m
        LEFT JOIN chapters c ON c.manga_id = m.id
        GROUP BY m.id
        ORDER BY total_views DESC
        LIMIT 3
    ");
    $top_vus = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $top_vus = [];
}

try {
    $stmt = $db->query("
        SELECT m.id, m.title, m.image_url,
               ROUND(AVG(r.rating), 1) AS avg_rating,
               COUNT(r.id) AS vote_count
        FROM mangas m
        JOIN manga_ratings r ON r.manga_id = m.id
        GROUP BY m.id
        HAVING vote_count >= 1
        ORDER BY avg_rating DESC, vote_count DESC
        LIMIT 3
    ");
    $top_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $top_notes = []; 
}

$historique = [];
if (!empty($_SESSION['user_id'])) {
    try {
        $stmt = $db->prepare("
            SELECT m.id AS manga_id, m.title, m.image_url,
                   rh.chapter_id, c.chapter_number, rh.read_at
            FROM reading_history rh
            JOIN mangas m   ON m.id = rh.manga_id
            JOIN chapters c ON c.id = rh.chapter_id
            WHERE rh.user_id = ?
            ORDER BY rh.read_at DESC
            LIMIT 5
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $historique = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $historique = [];
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://i.ibb.co/LdCC28Wk/logo-site.png">
    <title>Yurei Scan</title>

    <meta name="description" content="La Yurei Scan est une jeune équipe de scantrad fondée le 22 juin 2025. Découvrez notre histoire, nos mangas en scantrad et notre équipe passionnée.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://yurei-scan.fr/">
    <meta property="og:title" content="Yurei Scan - Scantrad Manga">
    <meta property="og:description" content="La Yurei Scan est une jeune équipe de scantrad fondée le 22 juin 2025. Découvrez notre histoire, nos mangas en scantrad et notre équipe passionnée.">
    <meta property="og:image" content="https://i.ibb.co/LdCC28Wk/logo-site.png">
    <meta property="og:image:width" content="600">
    <meta property="og:image:height" content="600">
    <meta property="og:site_name" content="Yurei Scan">
    <meta property="og:locale" content="fr_FR">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Yurei Scan - Scantrad Manga">
    <meta name="twitter:description" content="La Yurei Scan est une jeune équipe de scantrad fondée le 22 juin 2025. Découvrez notre histoire, nos mangas en scantrad et notre équipe passionnée.">
    <meta name="twitter:image" content="https://i.ibb.co/LdCC28Wk/logo-site.png">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .content { max-width: 1400px; margin: 0 auto; padding: 0 20px; }
        .carousel-container { position: relative; margin: 30px 0 50px; overflow: hidden; border-radius: 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.6); background: #000; }
        .carousel-wrapper { display: flex; transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1); width: 100%; }
        .carousel-slide { min-width: 100%; position: relative; overflow: hidden; }
        .carousel-slide::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.6) 40%, transparent 100%); z-index: 1; pointer-events: none; }
        .carousel-link { display: block; text-decoration: none; color: inherit; width: 100%; height: 100%; position: relative; }
        .carousel-slide img { width: 100%; height: 500px; object-fit: cover; display: block; transition: transform 0.6s ease; }
        @media (max-width: 768px) {
            .carousel-slide { display: block; position: relative; }
            .carousel-slide img { height: auto; width: 100%; max-height: none; object-fit: contain; object-position: center center; background: #000; transform: none !important; display: block; }
            .carousel-slide:hover img { transform: none !important; }
            .carousel-slide::before { display: block; background: linear-gradient(to top, rgba(0,0,0,0.88) 0%, rgba(0,0,0,0.5) 45%, transparent 100%); height: 42%; top: auto; bottom: 0; }
            .slide-overlay { position: absolute !important; bottom: 0 !important; left: 0 !important; right: 0 !important; padding: 12px 14px 14px !important; background: none !important; transform: none !important; z-index: 2; }
            .slide-title { font-size: 15px !important; margin: 0 0 3px !important; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; text-shadow: 0 1px 6px rgba(0,0,0,0.9); }
            .slide-description { font-size: 12px !important; -webkit-line-clamp: 1 !important; line-clamp: 1 !important; text-shadow: 0 1px 4px rgba(0,0,0,0.9); }
            .carousel-link { display: block !important; }
        }
        .carousel-link img { cursor: pointer; }
        .carousel-slide:hover img { transform: scale(1.05); }
        .slide-overlay { position: absolute; bottom: 0; left: 0; right: 0; padding: 40px; z-index: 2; transform: translateY(0); transition: transform 0.3s ease; pointer-events: none; }
        .slide-title { font-size: 36px; margin: 0 0 10px; font-weight: 700; text-shadow: 2px 2px 8px rgba(0,0,0,0.8); letter-spacing: 1px; }
        .slide-description { font-size: 16px; margin: 0; opacity: 0.95; text-shadow: 1px 1px 4px rgba(0,0,0,0.8); max-width: 600px; }
        .carousel-btn { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); color: white; border: 2px solid rgba(255,255,255,0.3); width: 50px; height: 50px; border-radius: 50%; cursor: pointer; font-size: 20px; transition: all 0.3s ease; z-index: 10; display: flex; align-items: center; justify-content: center; }
        .carousel-btn:hover { background: rgba(255,255,255,0.3); border-color: rgba(255,255,255,0.6); transform: translateY(-50%) scale(1.1); }
        .carousel-btn.prev { left: 20px; }
        .carousel-btn.next { right: 20px; }
        .carousel-indicators { position: relative; margin-top: -44px; display: flex; justify-content: center; gap: 12px; z-index: 100; pointer-events: none; }
        .carousel-indicators .indicator { pointer-events: auto; }
        .indicator { width: 12px; height: 12px; border-radius: 50%; background: rgba(255,255,255,0.3); cursor: pointer; transition: all 0.3s ease; border: 2px solid transparent; }
        .indicator:hover { background: rgba(255,255,255,0.6); }
        .indicator.active { background: #fff; width: 32px; border-radius: 6px; }
        .sections-container { display: grid; grid-template-columns: 1fr 1fr; grid-template-rows: auto auto; gap: 24px; margin: 50px 0 60px; }
        .col-left-discord { grid-column: 1; grid-row: 1; }
        .col-left-cagnotte { grid-column: 1; grid-row: 2; }
        .col-right-sorties { grid-column: 2; grid-row: 1 / 3; }
        .content-section { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 28px 24px; box-shadow: 0 8px 32px rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); transition: all 0.3s ease; position: relative; overflow: hidden; display: flex; flex-direction: column; }
        .content-section::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #bc6a6a; transform: scaleX(0); transition: transform 0.3s ease; }
        .content-section:hover { transform: translateY(-4px); box-shadow: 0 12px 48px rgba(188, 106, 106, 0.3); border-color: rgba(255,255,255,0.2); }
        .content-section:hover::before { transform: scaleX(1); }
        .content-section h2 { font-size: 20px; margin-bottom: 20px; color: #fff; text-transform: uppercase; letter-spacing: 2px; text-align: center; font-weight: 600; position: relative; padding-bottom: 12px; }
        .content-section h2::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 50px; height: 2px; background: #bc6a6a; border-radius: 2px; }
        .content-section p { color: #bbb; margin: 10px 0; text-align: center; font-size: 15px; }
        .discord-card { align-items: center; justify-content: center; min-height: 220px; }
        .discord-body { display: flex; align-items: center; gap: 22px; width: 100%; justify-content: center; flex-wrap: wrap; }
        .discord-logo { width: 150px; height: 150px; border-radius: 26px; object-fit: contain; flex-shrink: 0; box-shadow: 0 2px 8px rgba(88,101,242,0.25); }
        .discord-right { display: flex; flex-direction: column; align-items: center; gap: 10px; }
        .discord-btn { display: inline-block; background: linear-gradient(135deg, #5865f2 0%, #4752c4 100%); color: #fff; text-decoration: none; padding: 12px 34px; border-radius: 15px; font-size: 17px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; box-shadow: 0 4px 18px rgba(88,101,242,0.45); transition: all 0.3s ease; border: none; cursor: pointer; }
        .discord-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 24px rgba(88,101,242,0.6); background: linear-gradient(135deg, #6c75f5 0%, #5a65d8 100%); }
        .discord-sub { color: #ccc; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; line-height: 1.4; text-align: center; }
        .discord-right h2, .cagnotte-right h2 { margin-bottom: 2px; }
        .cagnotte-card { align-items: center; justify-content: center; }
        .cagnotte-body { display: flex; align-items: center; gap: 20px; width: 100%; justify-content: center; flex-wrap: wrap; }
        .cagnotte-illustration { width: 150px; height: 150px; border-radius: 26px; object-fit: cover; flex-shrink: 0; border: 2px solid rgba(255,255,255,0.08); }
        .cagnotte-right { display: flex; flex-direction: column; align-items: center; gap: 8px; }
        .cagnotte-link { display: inline-flex; align-items: center; text-decoration: none; }
        .cagnotte-link img { max-height: 64px; width: auto; border-radius: 10px; filter: drop-shadow(0 3px 8px rgba(0,0,0,0.3)); transition: transform 0.3s ease, filter 0.3s ease; }
        .cagnotte-link:hover img { transform: translateY(-2px) scale(1.04); filter: drop-shadow(0 3px 8px rgba(0,185,254,0.4)); }
        .cagnotte-sub { color: #bbb; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; text-align: center; }
        .sorties-card { height: 100%; display: flex; flex-direction: column; }
        .sorties-separator { text-align: center; color: rgba(255,255,255,0.25); font-size: 18px; letter-spacing: 4px; margin-bottom: 14px; margin-top: -4px; }
        .sorties-list { display: flex; flex-direction: column; gap: 10px; flex: 1; }
        .sortie-item { display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 10px 14px; text-decoration: none; color: inherit; transition: background 0.25s ease, border-color 0.25s ease; min-height: 52px; }
        .sortie-item:hover { background: rgba(255,255,255,0.1); border-color: rgba(188, 106, 106, 0.4); }
        .sortie-thumb { width: 44px; height: 56px; border-radius: 8px; object-fit: cover; flex-shrink: 0; border: 1px solid rgba(255,255,255,0.1); }
        .sortie-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
        .sortie-title { font-size: 14px; font-weight: 600; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .sortie-chapter { font-size: 13px; color: #999; display: flex; align-items: center; gap: 6px; }
        .sortie-chapter::before { content: '→'; color: #bc6a6a; font-weight: 700; }
        .sortie-badge { flex-shrink: 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; padding: 4px 10px; border-radius: 20px; white-space: nowrap; }
        .sortie-badge.en-cours { background: rgba(188, 106, 106, 0.18); color: #bc6a6a; border: 1px solid rgba(188, 106, 106, 0.3); }
        .sortie-badge.termine { background: rgba(46,204,113,0.15); color: #2ecc71; border: 1px solid rgba(46,204,113,0.3); }
        .sortie-item.empty { background: rgba(255,255,255,0.03); border-color: rgba(255,255,255,0.05); min-height: 52px; }
        .bottom-sections { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 24px; margin: 0 0 60px; }
        .top3-section, .historique-section { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 28px 24px; box-shadow: 0 8px 32px rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); position: relative; overflow: hidden; }
        .top3-section::before, .historique-section::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #bc6a6a; }
        .top3-section h2, .historique-section h2 { font-size: 16px; margin-bottom: 18px; color: #fff; text-transform: uppercase; letter-spacing: 2px; text-align: center; font-weight: 600; position: relative; padding-bottom: 12px; }
        .top3-section h2::after, .historique-section h2::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 40px; height: 2px; background: #bc6a6a; border-radius: 2px; }
        .top3-list, .historique-list { display: flex; flex-direction: column; gap: 10px; }
        .top3-item, .histo-item { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.07); border-radius: 12px; padding: 9px 12px; text-decoration: none; color: inherit; transition: background 0.25s, border-color 0.25s; }
        .top3-item:hover, .histo-item:hover { background: rgba(255,255,255,0.09); border-color: rgba(188,106,106,0.4); }
        .top3-rank { font-size: 18px; font-weight: 800; color: #bc6a6a; width: 22px; text-align: center; flex-shrink: 0; }
        .top3-thumb, .histo-thumb { width: 38px; height: 50px; border-radius: 7px; object-fit: cover; flex-shrink: 0; border: 1px solid rgba(255,255,255,0.1); }
        .top3-info, .histo-info { flex: 1; min-width: 0; }
        .top3-title, .histo-title { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .top3-sub, .histo-sub { font-size: 11px; color: #999; margin-top: 2px; }
        .top3-empty, .histo-empty { text-align: center; color: #666; font-size: 13px; padding: 20px 0; }
        .stars-mini { color: #f4c430; font-size: 11px; letter-spacing: 1px; }
        .section-icon { width: 18px; height: 18px; vertical-align: middle; margin-right: 6px; flex-shrink: 0; display: inline-block; }
        .sub-icon { width: 12px; height: 12px; vertical-align: middle; margin-right: 4px; flex-shrink: 0; display: inline-block; opacity: 0.85; }
        .histo-connect { text-align: center; padding: 20px 10px; color: #888; font-size: 13px; line-height: 1.7; }
        .histo-connect a { color: #bc6a6a; font-weight: 700; text-decoration: none; }
        @media (max-width: 900px) {
            .bottom-sections { grid-template-columns: 1fr 1fr; }
            .historique-section { grid-column: 1 / -1; order: -1; }
        }
        @media (max-width: 768px) {
            .bottom-sections { grid-template-columns: 1fr; }
            .sections-container { grid-template-columns: 1fr; grid-template-rows: auto; gap: 20px; margin: 30px 0 50px; }
            .col-left-discord { grid-column: 1; grid-row: auto; }
            .col-left-cagnotte { grid-column: 1; grid-row: auto; }
            .col-right-sorties { grid-column: 1; grid-row: auto; }
            .content { padding: 0 15px; }
            .carousel-container { margin: 20px 0 0; border-radius: 15px; }
            .slide-title { font-size: 20px; line-height: 1.3; }
            .slide-description { font-size: 13px; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.4; }
            .carousel-btn { display: none !important; }
            .carousel-indicators { position: static !important; margin-top: 0 !important; margin-bottom: 30px !important; display: flex !important; justify-content: center; padding: 6px 0 7px !important; background: rgba(0,0,0,0.55) !important; gap: 10px !important; z-index: auto !important; }
            .indicator { width: 10px !important; height: 10px !important; background: rgba(255,255,255,0.5) !important; border: 2px solid rgba(255,255,255,0.3) !important; }
            .indicator.active { width: 28px !important; background: #fff !important; border-color: #fff !important; }
        }
        @media (max-width: 968px) and (min-width: 769px) {
            .sections-container { gap: 20px; }
            .carousel-slide img { height: 350px; }
            .slide-title { font-size: 26px; }
            .slide-overlay { padding: 25px; }
        }
        @media (max-width: 480px) {
            .slide-title { font-size: 18px; }
            .discord-body, .cagnotte-body { flex-direction: column; gap: 14px; }
            .carousel-indicators { bottom: 12px !important; gap: 10px !important; }
            .indicator { width: 8px !important; height: 8px !important; }
            .indicator.active { width: 24px !important; }
        }
    </style>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "Yurei Scan",
            "url": "https://yurei-scan.fr",
            "description": "Yurei Scan est une équipe de scantrad passionnée fondée en 2025.",
            "image": "https://i.ibb.co/LdCC28Wk/logo-site.png"
        }
</script>
</head>
<?php include 'header.php'; ?>
<body>

    <div class="content">

        <?php if (!empty($carousel_images)): ?>
        <div class="carousel-container" id="carousel">
            <div class="carousel-wrapper" id="carouselWrapper">
                <?php foreach ($carousel_images as $index => $image): 
                    $mob_style = sprintf(
                        '--mob-ox:%.2f%%;--mob-oy:%.2f%%',
                        $image['mob_ox'] ?? 50,
                        $image['mob_oy'] ?? 50
                    );
                ?>
                <div class="carousel-slide" data-slide="<?php echo $index; ?>" style="<?php echo $mob_style; ?>">
                    <?php if (!empty($image['link_url'])): ?>
                        <a href="<?php echo htmlspecialchars($image['link_url']); ?>" class="carousel-link">
                            <img src="<?php echo htmlspecialchars($image['src']); ?>" 
                                 alt="<?php echo htmlspecialchars($image['alt']); ?>">
                            <div class="slide-overlay">
                                <h3 class="slide-title"><?php echo htmlspecialchars($image['title']); ?></h3>
                                <p class="slide-description"><?php echo htmlspecialchars($image['alt']); ?></p>
                            </div>
                        </a>
                    <?php else: ?>
                        <img src="<?php echo htmlspecialchars($image['src']); ?>" 
                             alt="<?php echo htmlspecialchars($image['alt']); ?>">
                        <div class="slide-overlay">
                            <h3 class="slide-title"><?php echo htmlspecialchars($image['title']); ?></h3>
                            <p class="slide-description"><?php echo htmlspecialchars($image['alt']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>

            <button class="carousel-btn prev" type="button" aria-label="Précédent">❮</button>
            <button class="carousel-btn next" type="button" aria-label="Suivant">❯</button>
        </div>

        <div class="carousel-indicators">
            <?php foreach ($carousel_images as $index => $image): ?>
            <span class="indicator <?php echo $index === 0 ? 'active' : ''; ?>" 
                  data-slide="<?php echo $index; ?>" 
                  aria-label="Slide <?php echo $index + 1; ?>"></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="sections-container">

            <div class="content-section discord-card col-left-discord">
                <div class="discord-body">
                    <img 
                        src="https://i.ibb.co/XxMV7TCk/17d97122af427adce72413d695ee0c75-1000x1000x1.jpg" 
                        alt="Discord Logo" 
                        class="discord-logo">
                    <div class="discord-right">
                        <h2>↓ Notre Discord ↓</h2>
                        <a href=" https://discord.gg/BV7K5bgMAv" target="_blank" rel="noopener noreferrer" class="discord-btn">
                            Clique ici !</a>
                        <span class="discord-sub">Rejoins-nous !</span>
                    </div>
                </div>
            </div>

            <div class="content-section cagnotte-card col-left-cagnotte">
                <div class="cagnotte-body">
                    <img 
                        src="https://i.ibb.co/4wBVq1jT/logo-site.png" 
                        alt="Mascotte Yurei" 
                        class="cagnotte-illustration">
                    <div class="cagnotte-right">
                        <h2>↓ notre cagnotte ↓</h2>
                        <a href="https://ko-fi.com/yureiscan" target="_blank" rel="noopener noreferrer" class="cagnotte-link">
                            <img src="https://i.ibb.co/XZHTqvM8/3b98ea8f-b0d6-424a-a1f3-e60c8c6f61ba-kofi.png" 
                                 alt="Ko-fi — Soutenir Yurei Scan">
                        </a>
                        <span class="cagnotte-sub">Merci à tous !!</span>
                    </div>
                </div>
            </div>

            <div class="content-section sorties-card col-right-sorties">
                <h2>↓ Dernières Sorties ↓</h2>
                <div class="sorties-list">
                    <?php
                    $total_slots = 5;
                    $count = 0;

                    if (!empty($dernières_sorties)):
                        foreach ($dernières_sorties as $sortie):
                            $count++;
                            $chapter_num = $sortie['chapter_number'];
                            if (is_numeric($chapter_num)) {
                                $cnf = (float)$chapter_num;
                                $chapter_num = (floor($cnf) == $cnf) 
                                    ? (string)(int)$cnf 
                                    : rtrim(rtrim(number_format($cnf, 1, '.', ''), '0'), '.');
                            }

                            $status = isset($sortie['status']) ? strtolower(trim($sortie['status'])) : '';
                            $badge_class = 'en-cours';
                            $badge_label = 'En cours';
                            
                            if (in_array($status, ['terminé', 'termine', 'completed'])) {
                                $badge_class = 'termine';
                                $badge_label = 'Terminé';
                            }
                        ?>
                    <a href="chapter.php?id=<?php echo (int)$sortie['manga_id']; ?>&chapter_id=<?php echo (int)$sortie['chapter_id']; ?>" 
                       class="sortie-item">
                        <?php if (!empty($sortie['image_url'])): ?>
                            <img src="<?php echo htmlspecialchars($sortie['image_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($sortie['title']); ?>" 
                                 class="sortie-thumb">
                        <?php else: ?>
                            <div class="sortie-thumb" style="background:#222;"></div>
                        <?php endif; ?>

                        <div class="sortie-info">
                            <span class="sortie-title"><?php echo htmlspecialchars($sortie['title']); ?></span>
                            <span class="sortie-chapter">Chapitre <?php echo htmlspecialchars($chapter_num); ?></span>
                        </div>

                        <span class="sortie-badge <?php echo $badge_class; ?>"><?php echo $badge_label; ?></span>
                    </a>
                    <?php 
                        endforeach;
                    endif;
                    ?>

                    <?php for ($i = $count; $i < $total_slots; $i++): ?>
                    <div class="sortie-item empty"></div>
                    <?php endfor; ?>
                </div>
            </div>

        </div>

        <div class="bottom-sections">

            <div class="historique-section">
                <h2>
                    <svg class="section-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12 6 12 12 16 14"/>
                    </svg>
                    Historique :
                </h2>
                <?php if (empty($_SESSION['user_id'])): ?>
                    <div class="histo-connect">
                        <a href="login.php">Connectez-vous</a> pour retrouver<br>votre historique de lecture.
                    </div>
                <?php elseif (empty($historique)): ?>
                    <p class="histo-empty">Vous n'avez pas encore commencé de lecture.</p>
                <?php else: ?>
                    <div class="historique-list">
                        <?php foreach ($historique as $h): ?>
                        <?php
                            $cn = $h['chapter_number'];
                            if (is_numeric($cn)) {
                                $cnf = (float)$cn;
                                $cn  = floor($cnf) == $cnf
                                    ? (string)(int)$cnf
                                    : rtrim(rtrim(number_format($cnf, 1, '.', ''), '0'), '.');
                            }
                        ?>
                        <a href="chapter.php?id=<?php echo (int)$h['manga_id']; ?>&chapter_id=<?php echo (int)$h['chapter_id']; ?>" class="histo-item">
                            <?php if (!empty($h['image_url'])): ?>
                                <img src="<?php echo htmlspecialchars($h['image_url']); ?>" class="histo-thumb" alt="">
                            <?php else: ?>
                                <div class="histo-thumb" style="background:#222;"></div>
                            <?php endif; ?>
                            <div class="histo-info">
                                <div class="histo-title"><?php echo htmlspecialchars($h['title']); ?></div>
                                <div class="histo-sub">
                                    <svg class="sub-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                                    </svg>
                                    Chap. <?php echo htmlspecialchars($cn); ?> — <?php echo date('d/m/Y', strtotime($h['read_at'])); ?>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="top3-section">
                <h2>
                    <svg class="section-icon" viewBox="10 0 80 100" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M50 95 C22 95 8 78 8 60 C8 38 22 24 34 16 C34 28 40 34 46 32 C44 20 52 8 62 4 C59 16 66 22 70 20 C80 30 92 44 92 60 C92 78 78 95 50 95 Z"/>
                        <path d="M36 30 C30 22 32 12 38 6 C36 14 40 20 44 18"/>
                    </svg>
                    Top 3 les plus vus :
                </h2>
                <div class="top3-list">
                    <?php if (!empty($top_vus)): ?>
                        <?php foreach ($top_vus as $i => $m): ?>
                        <a href="manga.php?id=<?php echo (int)$m['id']; ?>" class="top3-item">
                            <span class="top3-rank"><?php echo $i + 1; ?></span>
                            <?php if (!empty($m['image_url'])): ?>
                                <img src="<?php echo htmlspecialchars($m['image_url']); ?>" class="top3-thumb" alt="">
                            <?php else: ?>
                                <div class="top3-thumb" style="background:#222;"></div>
                            <?php endif; ?>
                            <div class="top3-info">
                                <div class="top3-title"><?php echo htmlspecialchars($m['title']); ?></div>
                                <div class="top3-sub">
                                    <svg class="sub-icon" viewBox="10 0 80 100" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" style="color:#fff;">
                                        <path d="M50 95 C22 95 8 78 8 60 C8 38 22 24 34 16 C34 28 40 34 46 32 C44 20 52 8 62 4 C59 16 66 22 70 20 C80 30 92 44 92 60 C92 78 78 95 50 95 Z"/>
                                        <path d="M36 30 C30 22 32 12 38 6 C36 14 40 20 44 18"/>
                                    </svg>
                                    <?php echo number_format($m['total_views']); ?> vues
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="top3-empty">Aucune donnée pour l'instant.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="top3-section">
                <h2>
                    <svg class="section-icon" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2l-2.81 6.63L2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>
                    Top 3 les mieux notés :
                </h2>
                <div class="top3-list">
                    <?php if (!empty($top_notes)): ?>
                        <?php foreach ($top_notes as $i => $m): ?>
                        <?php
                            $avg     = (float)$m['avg_rating'];
                            $full    = (int)floor($avg);
                            $half    = ($avg - $full) >= 0.5 ? 1 : 0;
                            $empty_s = 5 - $full - $half;
                            $stars   = str_repeat('★', $full) . ($half ? '½' : '') . str_repeat('☆', $empty_s);
                        ?>
                        <a href="manga.php?id=<?php echo (int)$m['id']; ?>" class="top3-item">
                            <span class="top3-rank"><?php echo $i + 1; ?></span>
                            <?php if (!empty($m['image_url'])): ?>
                                <img src="<?php echo htmlspecialchars($m['image_url']); ?>" class="top3-thumb" alt="">
                            <?php else: ?>
                                <div class="top3-thumb" style="background:#222;"></div>
                            <?php endif; ?>
                            <div class="top3-info">
                                <div class="top3-title"><?php echo htmlspecialchars($m['title']); ?></div>
                                <div class="top3-sub">
                                    <svg class="sub-icon" viewBox="0 0 24 24" fill="currentColor" style="color:#f4c430;">
                                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2l-2.81 6.63L2 9.24l5.46 4.73L5.82 21z"/>
                                    </svg>
                                    <span class="stars-mini"><?php echo $stars; ?></span>
                                    <?php echo $avg; ?>/5 (<?php echo (int)$m['vote_count']; ?> votes)
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="top3-empty">Pas encore de notes.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script>
        const wrapper = document.getElementById('carouselWrapper');
        const slides = document.querySelectorAll('.carousel-slide');
        const totalSlides = slides.length;
        const prevBtn = document.querySelector('.carousel-btn.prev');
        const nextBtn = document.querySelector('.carousel-btn.next');
        const indicators = document.querySelectorAll('.indicator');

        let currentSlideIndex = 0;
        let isTransitioning = false;
        let autoPlayInterval;

        if (totalSlides > 1) {
            const firstClone = slides[0].cloneNode(true);
            const lastClone = slides[totalSlides - 1].cloneNode(true);
            firstClone.classList.add('clone');
            lastClone.classList.add('clone');
            wrapper.appendChild(firstClone);
            wrapper.insertBefore(lastClone, slides[0]);
            wrapper.style.transform = `translateX(-100%)`;
        }

        function updateIndicators() {
            indicators.forEach((ind, i) => {
                ind.classList.toggle('active', i === currentSlideIndex);
            });
        }

        function goToSlide(targetIndex) {
            if (isTransitioning) return;
            isTransitioning = true;
            currentSlideIndex = targetIndex < 0 ? totalSlides - 1 : targetIndex % totalSlides;
            const offset = -(currentSlideIndex + 1) * 100;
            wrapper.style.transition = 'transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
            wrapper.style.transform = `translateX(${offset}%)`;

            wrapper.addEventListener('transitionend', function handler() {
                wrapper.removeEventListener('transitionend', handler);
                isTransitioning = false;
                if (targetIndex >= totalSlides) {
                    currentSlideIndex = 0;
                    wrapper.style.transition = 'none';
                    wrapper.style.transform = `translateX(-100%)`;
                } else if (targetIndex < 0) {
                    currentSlideIndex = totalSlides - 1;
                    wrapper.style.transition = 'none';
                    wrapper.style.transform = `translateX(${-(totalSlides) * 100}%)`;
                }
                updateIndicators();
                requestAnimationFrame(() => {
                    wrapper.style.transition = 'transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
                });
            });
        }

        function nextSlide() { goToSlide(currentSlideIndex + 1); resetAutoPlay(); }
        function prevSlide() { goToSlide(currentSlideIndex - 1); resetAutoPlay(); }

        nextBtn.addEventListener('click', nextSlide);
        prevBtn.addEventListener('click', prevSlide);

        let touchStartX = 0;
        let touchStartY = 0;
        wrapper.addEventListener('touchstart', (e) => {
            touchStartX = e.touches[0].clientX;
            touchStartY = e.touches[0].clientY;
        }, { passive: true });
        wrapper.addEventListener('touchend', (e) => {
            const dx = e.changedTouches[0].clientX - touchStartX;
            const dy = e.changedTouches[0].clientY - touchStartY;
            if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
                dx < 0 ? nextSlide() : prevSlide();
            }
        }, { passive: true });

        indicators.forEach((ind, i) => {
            ind.addEventListener('click', () => { goToSlide(i); resetAutoPlay(); });
        });

        function startAutoPlay() { autoPlayInterval = setInterval(nextSlide, 9000); }
        function stopAutoPlay()  { clearInterval(autoPlayInterval); }
        function resetAutoPlay() { stopAutoPlay(); startAutoPlay(); }

        document.getElementById('carousel').addEventListener('mouseenter', stopAutoPlay);
        document.getElementById('carousel').addEventListener('mouseleave', startAutoPlay);

        if (totalSlides > 0) {
            updateIndicators();
            if (totalSlides > 1) startAutoPlay();
        }

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

        document.querySelectorAll('.content-section').forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(30px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(section);
        });
    </script>
</body>
</html>