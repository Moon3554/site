<?php 
require_once 'check_captcha.php';
session_start();?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentions Légales - Yurei Scan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background: #000; color: #ececec; line-height: 1.7; min-height: 100vh; }
        .content { max-width: 1000px; margin: 0 auto; padding: 60px 20px; }
        .page-title { text-align: center; font-size: 38px; margin-bottom: 60px; font-weight: 800; color: #bc6a6a; text-transform: uppercase; letter-spacing: 3px; }
        .main-alert { background: rgba(255, 166, 0, 0.05); border: 1px solid rgba(255, 166, 0, 0.2); border-left: 4px solid #ffa600; padding: 25px; border-radius: 12px; margin-bottom: 40px; backdrop-filter: blur(5px); }
        .main-alert h2 { color: #ffa600; font-size: 20px; margin-bottom: 12px; display: flex; align-items: center; gap: 10px; text-transform: uppercase; }
        .legal-grid { display: flex; flex-direction: column; gap: 25px; }
        .legal-card { background: rgba(255, 255, 255, 0.03); border-radius: 15px; padding: 30px; border: 1px solid rgba(255, 255, 255, 0.08); transition: transform 0.3s ease, background 0.3s ease; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); }
        .legal-card:hover { background: rgba(255, 255, 255, 0.05); border-color: rgba(188, 106, 106, 0.3); box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3); }
        .legal-card h3 { font-size: 20px; color: #bc6a6a; margin-bottom: 18px; display: flex; align-items: center; font-weight: 600; }
        .legal-card h3::before { content: "•"; margin-right: 10px; color: #bc6a6a; }
        .legal-card p { color: #b0b0b0; font-size: 15px; margin-bottom: 15px; }
        .highlight { color: #ffffff; background: rgba(188, 106, 106, 0.1); padding: 10px 15px; border-radius: 8px; display: inline-block; border: 1px dashed rgba(188, 106, 106, 0.3); }
        strong { color: #fff; font-weight: 600; }
        @media (max-width: 768px) {
            .content { padding: 40px 15px; }
            .page-title { font-size: 28px; margin-bottom: 40px; }
            .legal-card { padding: 20px; }
            .main-alert { padding: 20px; }
            .main-alert h2 { font-size: 18px; }
        }
        @media (max-width: 480px) {
            .content { padding: 30px 10px; }
            .page-title { font-size: 24px; letter-spacing: 2px; }
            .legal-card { padding: 18px; }
            .legal-card h3 { font-size: 18px; }
            .legal-card p { font-size: 14px; }
            .main-alert { padding: 18px; }
            .highlight { padding: 8px 12px; font-size: 14px; }
        }
    </style>
</head>
<?php include 'header.php'; ?>
<body>

    <div class="content">
        <h1 class="page-title">Informations Légales</h1>

        <div class="main-alert">
            <h2>Important</h2>
            <p>
                <strong>Yurei Scan</strong> est un site réalisé par des passionnés, pour des passionnés. 
                Aucun des fichiers présentés sur ce site n'est hébergé physiquement sur nos serveurs.
                Nous ne tirons aucun profit direct de la diffusion des œuvres présentées.
                <br><br>
                Si vous appréciez une œuvre, <strong>le meilleur moyen de soutenir l'auteur est d'acheter les tomes originaux</strong> 
                (physiques ou numériques) ou de souscrire aux plateformes légales de diffusion dès que l'œuvre est licenciée dans votre pays.
            </p>
        </div>

        <div class="legal-grid">
            <div class="legal-card">
                <h3>Propriété Intellectuelle & DMCA</h3>
                <p>Nous respectons les droits de propriété intellectuelle d'autrui. La politique de Yurei Scan est de répondre aux avis valides de violation présumée du droit d'auteur.</p>
                <p>Si vous êtes détenteur d'un droit d'auteur (ou son représentant légal) et que vous estimez que votre œuvre a été copiée d'une manière qui constitue une violation du droit d'auteur sur notre site, veuillez nous contacter immédiatement.</p>
                <p>Dès réception d'une demande de retrait valide et vérifiée (DMCA Takedown Notice), nous nous engageons à retirer le contenu concerné dans un délai de 24 à 48 heures ouvrées.</p>
                <p class="highlight">Pour toute demande de retrait, contactez nous via : <strong>admin@yurei-scan.fr</strong></p>
            </div>

            <div class="legal-card">
                <h3>Politique de Confidentialité</h3>
                <p><strong>Données collectées :</strong> Lors de l'inscription, nous collectons uniquement votre nom d'utilisateur et votre mot de passe. Votre mot de passe est stocké de manière chiffrée et n'est jamais lisible, même par notre équipe. Aucune donnée personnelle identifiable (nom réel, adresse, téléphone, email) n'est collectée.</p>
                <p><strong>Durée de conservation :</strong> Vos données sont conservées tant que votre compte est actif. Vous pouvez demander la suppression de votre compte et de vos données à tout moment en nous contactant.</p>
                <p><strong>Cookies :</strong> Ce site utilise un cookie de session pour maintenir votre connexion lorsque vous êtes connecté à votre compte. Ce cookie est temporaire et supprimé à la fermeture de votre navigateur. Aucun cookie de tracking ou publicitaire n'est utilisé.</p>
                <p>Nous ne vendons, n'échangeons et ne transférons aucune donnée à des tiers extérieurs.</p>
                <p><strong>Vos droits (RGPD) :</strong> Conformément au Règlement Général sur la Protection des Données (RGPD), vous disposez d'un droit d'accès, de rectification et de suppression de vos données. Pour exercer ces droits, contactez-nous via : <strong>admin@yurei-scan.fr</strong></p>
            </div>

            <div class="legal-card">
                <h3>Hébergement</h3>
                <p>Le site Yurei Scan est hébergé par <strong>InfinityFree</strong>. <strong>Yurei Scan n'héberge aucune image directement.</strong> Pour tout retrait de contenu, contactez notre équipe via <strong>admin@yurei-scan.fr</strong>.</p>
                <p>Responsable de la publication : <strong>The Quagmire</strong><br>
                    Contact technique : <strong>Moon3554</strong></p>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>