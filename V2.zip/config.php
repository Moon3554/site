<?php
define('DB_HOST', 'sql312.infinityfree.com');
define('DB_NAME', 'if0_42146427_yurei_scn');
define('DB_USER', 'if0_42146427');
define('DB_PASS', 'fZypZTKDRT');