<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

require_once 'db.php';

try {
    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar VARCHAR(500) DEFAULT NULL");
    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS banner VARCHAR(500) DEFAULT NULL");
    $db->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS fav_manga_id INT DEFAULT NULL");
} catch (PDOException $e) {}

$target_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : $_SESSION['user_id'];
$is_own_profile = ($target_id === (int)$_SESSION['user_id']);

$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$target_id]);
$user = $stmt->fetch();

$username      = $user['username'] ?? 'Utilisateur';
$membre_depuis = date('d/m/Y', strtotime($user['created_at']));
$role          = ($user['is_admin'] ?? 0) ? 'ADMIN' : (($user['is_staff'] ?? 0) ? 'STAFF' : 'MEMBRE');
$avatar_url    = $user['avatar'] ?? null;
$banner_url    = $user['banner'] ?? null;

$avatars = [];
$banners = [];
$mangas  = [];
$fav_manga = null;
try {
    $avatars = $db->query("SELECT * FROM profile_avatars ORDER BY created_at ASC")->fetchAll(PDO::FETCH_ASSOC);
    $banners = $db->query("SELECT * FROM profile_banners ORDER BY created_at ASC")->fetchAll(PDO::FETCH_ASSOC);
    $mangas  = $db->query("SELECT id, title, image_url FROM mangas ORDER BY title ASC")->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($user['fav_manga_id'])) {
        $s = $db->prepare("SELECT id, title, image_url FROM mangas WHERE id = ?");
        $s->execute([$user['fav_manga_id']]);
        $fav_manga = $s->fetch(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {}

$stat_chapters = 0;
$stat_ratings  = 0;

try {
    $s = $db->prepare("SELECT COUNT(*) FROM manga_ratings WHERE user_id = ?");
    $s->execute([$target_id]);
    $stat_ratings = (int)$s->fetchColumn();
} catch (PDOException $e) {}

try {
    $s = $db->prepare("SELECT COUNT(*) FROM reading_history WHERE user_id = ?");
    $s->execute([$target_id]);
    $stat_chapters = (int)$s->fetchColumn();
} catch (PDOException $e) {}

include 'header.php';
?>
<style>
.profile-page { max-width: 1100px; margin: 30px auto; padding: 0 20px; display: flex; flex-direction: column; gap: 20px; }
.profile-card { background: #0d0d0d; border: 1px solid rgba(188,106,106,.25); border-radius: 20px; overflow: visible; box-shadow: 0 0 40px rgba(188,106,106,.08); }
.profile-banner { width: 100%; height: auto; aspect-ratio: 4 / 1; background: #111; position: relative; overflow: hidden; cursor: pointer; border-radius: 20px 20px 0 0; }
.profile-banner img { width: 100%; height: 100%; object-fit: cover; object-position: center center; transition: .3s; }
.profile-banner:hover img { opacity: .8; }
.profile-banner-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg, #1a0a0a 0%, #150505 40%, #0d0d0d 100%); display: flex; align-items: center; justify-content: center; }
.profile-banner-placeholder span { font-size: 13px; color: rgba(255,255,255,.15); letter-spacing: 4px; text-transform: uppercase; font-weight: 600; }
.edit-overlay { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.45); opacity: 0; transition: .2s; pointer-events: none; }
.profile-banner:hover .edit-overlay,
.profile-avatar-wrap:hover .edit-overlay { opacity: 1; }
.edit-overlay span { font-size: 13px; font-weight: 700; color: #fff; letter-spacing: 2px; text-transform: uppercase; background: rgba(188,106,106,.8); padding: 8px 18px; border-radius: 20px; }
.profile-info-row { display: flex; align-items: center; gap: 20px; padding: 0 24px 0 134px; height: 80px; background: #141414; border-bottom: 1px solid rgba(255,255,255,.07); position: relative; overflow: visible; }
.profile-avatar-wrap { width: 100px; height: 100px; border-radius: 50%; border: 4px solid #141414; background: rgba(255,255,255,.08); flex-shrink: 0; display: flex; align-items: center; justify-content: center; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,.5); cursor: pointer; position: absolute; left: 20px; top: 50%; transform: translateY(-50%); }
.profile-avatar-wrap img { width: 100%; height: 100%; object-fit: cover; }
.profile-avatar-wrap svg { width: 48px; height: 48px; fill: rgba(255,255,255,.5); }
.profile-meta { display: flex; flex-direction: column; gap: 4px; padding-top: 0; }
.profile-name { font-size: 22px; font-weight: 700; color: #bc6a6a; line-height: 1; }
.profile-badges { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.profile-badge { padding: 3px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; border: 1px solid rgba(255,255,255,.25); color: #fff; background: rgba(255,255,255,.08); }
.profile-badge.admin { border-color: #bc6a6a; color: #bc6a6a; background: rgba(188,106,106,.12); }
.profile-badge.staff { border-color: rgba(255,255,255,.4); }
.profile-badge.membre { border-color: rgba(255,255,255,.2); color: rgba(255,255,255,.6); }
.profile-date { display: flex; align-items: center; gap: 8px; font-size: 14px; color: rgba(255,255,255,.7); }
.profile-date svg { width: 16px; height: 16px; fill: currentColor; flex-shrink: 0; }
.profile-stats { display: grid; grid-template-columns: repeat(3, 1fr); padding: 24px 30px; gap: 12px; }
.profile-stat { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; padding: 18px 14px; background: rgba(255,255,255,.03); border: 1px solid rgba(255,255,255,.08); border-radius: 18px; text-align: center; min-height: 120px; }
.profile-stat-value { font-size: 30px; font-weight: 700; color: #bc6a6a; }
.profile-stat-label { font-size: 12px; color: rgba(255,255,255,.55); text-transform: uppercase; letter-spacing: 1px; }
.profile-section-card { background: rgba(255,255,255,.02); border: 1px solid rgba(255,255,255,.07); border-radius: 18px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,.3); }
.profile-section-title { padding: 18px 24px; border-bottom: 1px solid rgba(255,255,255,.08); font-size: 14px; font-weight: 700; color: rgba(255,255,255,.75); text-transform: uppercase; letter-spacing: 2px; display: flex; align-items: center; justify-content: space-between; }
.profile-section-voir-tout { font-size: 12px; color: #bc6a6a; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; text-decoration: none; display: none; }
.profile-empty { text-align: center; padding: 40px 20px; color: rgba(255,255,255,.45); font-size: 14px; }


.fav-manga-wrap { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 16px; background: #0d0d0d; cursor: pointer; position: relative; }
.fav-manga-wrap:hover .fav-edit-overlay { opacity: 1; }
.fav-manga-cover { width: 70px; height: 100px; object-fit: cover; border-radius: 8px; border: 2px solid rgba(188,106,106,.4); box-shadow: 0 4px 16px rgba(0,0,0,.5); }
.fav-manga-title { font-size: 11px; color: rgba(255,255,255,.5); text-align: center; max-width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.fav-manga-label { font-size: 12px; color: #bc6a6a; text-transform: uppercase; letter-spacing: 1px; text-align: center; }
.fav-edit-overlay { position: absolute; inset: 0; background: rgba(0,0,0,.55); opacity: 0; transition: .2s; display: flex; align-items: center; justify-content: center; }
.fav-edit-overlay span { font-size: 11px; font-weight: 700; color: #fff; background: rgba(188,106,106,.85); padding: 5px 12px; border-radius: 20px; }
.fav-manga-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; width: 70px; height: 100px; border: 2px dashed rgba(188,106,106,.3); border-radius: 8px; color: rgba(188,106,106,.5); font-size: 22px; }

.history-list { display: flex; flex-direction: column; }
.history-item { display: flex; align-items: center; gap: 14px; padding: 14px 20px; border-bottom: 1px solid rgba(255,255,255,.05); transition: background .15s; text-decoration: none; }
.history-item:last-child { border-bottom: none; }
.history-item:hover { background: rgba(255,255,255,.025); }
.history-cover-link { flex-shrink: 0; display: block; }
.history-cover { width: 50px; height: 70px; object-fit: cover; border-radius: 7px; border: 2px solid rgba(188,106,106,.25); box-shadow: 0 4px 12px rgba(0,0,0,.5); display: block; }
.history-cover-placeholder { width: 50px; height: 70px; border-radius: 7px; background: rgba(255,255,255,.06); border: 2px solid rgba(188,106,106,.15); }
.history-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 5px; }
.history-top-row { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }
.history-title { font-size: 14px; font-weight: 700; color: #fff; text-decoration: none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; line-height: 1.3; }
.history-title:hover { color: #bc6a6a; }
.history-sub { font-size: 12px; color: rgba(255,255,255,.4); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.history-bar-row { display: flex; align-items: center; gap: 10px; }
.history-bar-track { flex: 1; height: 5px; background: rgba(255,255,255,.1); border-radius: 99px; overflow: hidden; }
.history-bar-fill { height: 100%; background: #bc6a6a; border-radius: 99px; box-shadow: 0 0 8px rgba(188,106,106,.35); }
.history-percent { font-size: 12px; font-weight: 700; color: #bc6a6a; flex-shrink: 0; min-width: 32px; text-align: right; }

.mobile-section-gap { display: none; }

@media (max-width: 640px) {
    .mobile-section-gap {
        display: block;
        height: 10px;
        background: #0a0a0a;
        border-top: 1px solid rgba(255,255,255,.05);
        border-bottom: 1px solid rgba(255,255,255,.05);
    }
}

@media (max-width: 968px) and (min-width: 641px) {
    .profile-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); padding: 18px 18px 20px; }
    .profile-stat { min-height: 130px; }
    .fav-manga-wrap { width: 100%; margin-top: 8px; }
}

@media (max-width: 640px) {

    .profile-page { margin: 0; padding: 0 0 48px; gap: 0; }

    .profile-card { background: transparent; border: none; border-radius: 0; box-shadow: none; }

    .profile-banner {
        aspect-ratio: 21 / 9 !important;
        border-radius: 0 !important;
        width: 100%;
    }
    .profile-banner img {
        object-position: center center;
    }

    .profile-card { overflow: visible !important; }
    .profile-banner { margin-bottom: 0; display: block; }
    .profile-info-row {
        flex-direction: row;
        align-items: flex-end;
        text-align: left;
        padding: 10px 16px 14px 100px;
        margin-top: 0;
        background: #0d0d0d;
        border-bottom: 1px solid rgba(255,255,255,.07);
        position: relative;
        z-index: 2;
        gap: 12px;
        height: auto;
        overflow: visible;
    }
    .profile-avatar-wrap {
        position: absolute !important;
        left: 16px !important;
        top: -14px !important;
        bottom: auto !important;
        transform: none !important;
        width: 72px; height: 72px;
        border: 3px solid #0d0d0d;
        box-shadow: 0 4px 20px rgba(0,0,0,.5);
        z-index: 3;
        flex-shrink: 0;
        margin-top: 0;
    }
    .profile-meta { align-items: flex-start; text-align: left; padding-top: 0; gap: 3px; }
    .profile-name {
        font-size: 20px;
        font-weight: 700;
        color: #bc6a6a;
        letter-spacing: .3px;
    }
    .profile-badges { justify-content: flex-start; margin-top: 2px; }
    .profile-badge { font-size: 10px; padding: 2px 10px; letter-spacing: .8px; }
    .profile-badge.admin { background: rgba(188,106,106,.12); border-color: #bc6a6a; color: #bc6a6a; }
    .profile-date { font-size: 11px; color: rgba(255,255,255,.7); justify-content: flex-start; margin-top: 2px; }

    .profile-stats {
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-template-rows: auto auto;
        gap: 10px;
        padding: 16px 14px 0;
        background: transparent;
    }

    .profile-stat {
        background: #111;
        border: 1px solid rgba(255,255,255,.07);
        border-radius: 16px;
        padding: 18px 12px 14px;
        min-height: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 6px;
        position: relative;
        overflow: hidden;
        transition: border-color .2s;
    }
    .profile-stat::before {
        content: '';
        position: absolute;
        left: 0; top: 16px; bottom: 16px;
        width: 3px;
        background: #333;
        border-radius: 0 3px 3px 0;
        transition: background .2s;
    }
    .profile-stat:hover { border-color: rgba(188,106,106,.3); }
    .profile-stat:hover::before { background: #bc6a6a; }
    .profile-stat:active { opacity: .85; }
    .profile-stat > div > svg { width: 32px !important; height: 32px !important; }
    .profile-stat-value { font-size: 30px !important; }
    .profile-stat-label { font-size: 10px !important; letter-spacing: .8px; }

    .fav-manga-wrap {
        grid-column: 1 / -1;
        flex-direction: row;
        align-items: center;
        justify-content: flex-start;
        gap: 14px;
        padding: 12px 16px;
        background: #111;
        border: 1px solid rgba(255,255,255,.07);
        border-radius: 16px;
        width: 100%;
        position: relative;
        overflow: hidden;
        cursor: pointer;
        transition: border-color .2s;
        min-height: 0;
    }
    .fav-manga-wrap::before {
        content: '';
        position: absolute;
        left: 0; top: 12px; bottom: 12px;
        width: 3px;
        background: #333;
        border-radius: 0 3px 3px 0;
        transition: background .2s;
    }
    .fav-manga-wrap:hover { border-color: rgba(188,106,106,.3); }
    .fav-manga-wrap:hover::before { background: #bc6a6a; }
    .fav-manga-cover { width: 46px; height: 64px; flex-shrink: 0; border-radius: 7px; border: 1px solid rgba(188,106,106,.3); }
    .fav-manga-empty { width: 46px; height: 64px; font-size: 18px; flex-shrink: 0; border-radius: 7px; border: 1px dashed rgba(188,106,106,.3); }
    .fav-manga-label {
        font-size: 9px; letter-spacing: 1.5px;
        color: #bc6a6a; text-transform: uppercase; white-space: nowrap;
        margin-bottom: 2px;
    }
    .fav-manga-title {
        font-size: 13px; font-weight: 600; color: #fff;
        white-space: normal; max-width: none;
        overflow: visible; text-overflow: unset;
        text-align: left; line-height: 1.3;
    }
    .fav-edit-overlay { border-radius: 16px; }

    .fav-text-inner { display: flex; flex-direction: column; gap: 3px; align-items: flex-start; flex: 1; min-width: 0; }

    .profile-section-card {
        background: #000;
        border: none;
        border-top: 1px solid rgba(255,255,255,.07);
        border-bottom: 1px solid rgba(255,255,255,.07);
        border-radius: 0;
        margin: 0;
        overflow: hidden;
        position: relative;
    }
    .profile-section-card::before { display: none; }

    .profile-section-title {
        padding: 14px 16px;
        font-size: 11px;
        letter-spacing: 2px;
        color: rgba(255,255,255,.5);
        border-bottom: 1px solid rgba(255,255,255,.06);
        background: #000;
    }
    .profile-section-voir-tout {
        display: block;
        font-size: 11px;
        color: #bc6a6a;
        letter-spacing: .5px;
        font-weight: 600;
    }

    .history-list { background: #000; }
    .history-item {
        padding: 12px 16px;
        gap: 12px;
        border-bottom: 1px solid rgba(255,255,255,.05);
        background: transparent;
        transition: background .15s;
    }
    .history-item:last-child { border-bottom: none; }
    .history-item:active { background: rgba(188,106,106,.06); }
    .history-cover { width: 44px; height: 62px; border-radius: 6px; border-width: 1px; }
    .history-cover-placeholder { width: 44px; height: 62px; border-radius: 6px; }
    .history-title { font-size: 13px; font-weight: 600; }
    .history-sub { font-size: 11px; }
    .history-bar-track { height: 3px; background: rgba(255,255,255,.08); }
    .history-bar-fill { box-shadow: none; }
    .history-percent { font-size: 11px; min-width: 30px; }
}

.picker-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.88); backdrop-filter: blur(16px); z-index: 4000; align-items: center; justify-content: center; }
.picker-overlay.active { display: flex; }
.picker-modal { background: #111; border: 1px solid rgba(188,106,106,.3); border-radius: 22px; padding: 36px 32px; max-width: 640px; width: 94%; max-height: 85vh; overflow-y: auto; position: relative; scrollbar-width: thin; }
.picker-modal h2 { font-size: 22px; font-weight: 700; color: #fff; margin-bottom: 6px; }
.picker-modal p  { font-size: 13px; color: #666; margin-bottom: 28px; }
.picker-close { position: absolute; top: 14px; right: 14px; background: rgba(255,255,255,.07); border: none; color: #aaa; width: 34px; height: 34px; border-radius: 50%; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; }
.picker-close:hover { background: rgba(231,76,60,.3); color: #fff; }
.picker-avatar-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 14px; }
.picker-avatar-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; }
.picker-avatar-circle { width: 80px; height: 80px; border-radius: 50%; overflow: hidden; border: 3px solid transparent; transition: .2s; background: #1a1a1a; position: relative; }
.picker-avatar-circle img { width: 100%; height: 100%; object-fit: cover; display: block; }
.picker-avatar-item:hover .picker-avatar-circle { border-color: #bc6a6a; transform: scale(1.06); }
.picker-avatar-item.selected .picker-avatar-circle { border-color: #bc6a6a; box-shadow: 0 0 0 3px rgba(188,106,106,.35); }
.picker-item-label { font-size: 11px; color: #888; text-align: center; }
.picker-banner-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }
.picker-banner-item { cursor: pointer; border-radius: 10px; overflow: hidden; border: 3px solid transparent; transition: .2s; position: relative; }
.picker-banner-item img { width: 100%; aspect-ratio: 16/5; object-fit: cover; display: block; }
.picker-banner-item:hover { border-color: #bc6a6a; transform: scale(1.02); }
.picker-banner-item.selected { border-color: #bc6a6a; box-shadow: 0 0 0 3px rgba(188,106,106,.3); }
.picker-banner-item .picker-item-label { padding: 6px 8px; background: #0d0d0d; font-size: 11px; color: #888; }
.picker-check { position: absolute; top: 6px; right: 6px; background: #bc6a6a; color: #fff; border-radius: 50%; width: 22px; height: 22px; display: none; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; }
.picker-banner-item.selected .picker-check { display: flex; }
.picker-avatar-selected-check { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); background: rgba(188,106,106,.85); color: #fff; border-radius: 50%; width: 28px; height: 28px; display: none; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; }
.picker-avatar-item.selected .picker-avatar-selected-check { display: flex; }
.picker-empty { text-align: center; padding: 30px; color: #555; font-size: 14px; }
.picker-save-btn { width: 100%; margin-top: 24px; padding: 15px; background: #bc6a6a; border: none; color: #fff; border-radius: 13px; font-size: 15px; font-weight: 700; cursor: pointer; transition: .2s; }
.picker-save-btn:hover { background: #a85c5c; }
.picker-save-btn:disabled { opacity: .5; cursor: not-allowed; }
.picker-feedback { text-align: center; font-size: 13px; color: #51cf66; margin-top: 10px; display: none; }
.picker-manga-search { width: 100%; padding: 10px 14px; border-radius: 10px; border: 1px solid rgba(255,255,255,.15); background: rgba(0,0,0,.4); color: #fff; font-size: 14px; margin-bottom: 16px; outline: none; }
.picker-manga-search:focus { border-color: #bc6a6a; }
.picker-manga-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 12px; max-height: 400px; overflow-y: auto; scrollbar-width: none; -ms-overflow-style: none; }
.picker-manga-grid::-webkit-scrollbar { display: none; }
.picker-manga-item { display: flex; flex-direction: column; align-items: center; gap: 6px; cursor: pointer; }
.picker-manga-cover { width: 70px; height: 100px; object-fit: cover; border-radius: 8px; border: 3px solid transparent; transition: .2s; }
.picker-manga-item:hover .picker-manga-cover { border-color: #bc6a6a; transform: scale(1.04); }
.picker-manga-item.selected .picker-manga-cover { border-color: #bc6a6a; box-shadow: 0 0 0 3px rgba(188,106,106,.35); }
.picker-manga-item .picker-item-label { font-size: 10px; color: #888; text-align: center; max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

@media (max-width: 640px) {
    .picker-overlay { align-items: flex-end; }
    .picker-modal { border-radius: 22px 22px 0 0; max-width: 100%; padding: 28px 20px 36px; }
    .picker-banner-grid { grid-template-columns: 1fr; }
}
</style>

<div class="profile-page">

    <div class="profile-card">

        <div class="profile-banner" id="bannerZone" <?= $is_own_profile ? 'onclick="openPicker(\'banner\')" title="Changer la bannière"' : '' ?>>
            <?php if ($banner_url): ?>
                <img src="<?= htmlspecialchars($banner_url) ?>" alt="Bannière" id="bannerImg">
            <?php else: ?>
                <div class="profile-banner-placeholder" id="bannerPlaceholder">
                    <span><?= $is_own_profile ? 'Cliquez pour choisir une bannière' : '' ?></span>
                </div>
            <?php endif; ?>
            <?php if ($is_own_profile): ?><div class="edit-overlay"><span>Modifier</span></div><?php endif; ?>
        </div>

        <div class="profile-info-row">
            <div class="profile-avatar-wrap" id="avatarZone" <?= $is_own_profile ? 'onclick="openPicker(\'avatar\')" title="Changer l\'avatar"' : '' ?>>
                <?php if ($avatar_url): ?>
                    <img src="<?= htmlspecialchars($avatar_url) ?>" alt="Avatar" id="avatarImg">
                <?php else: ?>
                    <svg viewBox="0 0 24 24" id="avatarSvg"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
                <?php endif; ?>
                <?php if ($is_own_profile): ?><div class="edit-overlay"><span>modifier</span></div><?php endif; ?>
            </div>

            <div class="profile-meta">
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <div class="profile-name"><?= htmlspecialchars($username) ?></div>
                    <?php $badgeClass = strtolower($role); ?>
                    <span class="profile-badge <?= $badgeClass ?>"><?= $role ?></span>
                </div>
                <div class="profile-date">
                    <svg viewBox="0 0 24 24"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z"/></svg>
                    Membre depuis le <?= $membre_depuis ?>
                </div>
            </div>
        </div>

        <div class="profile-stats">
            <div class="profile-stat">
                <div style="display:flex;align-items:center;justify-content:center;gap:12px;">
                    <svg viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:52px;height:52px;filter:drop-shadow(0 0 6px #6abc8a);flex-shrink:0;">
                        <path d="M8 8h12c3 0 2 2 2 2v24s-1-2-2-2H8V8z" fill="#6abc8a" opacity="0.5"/>
                        <path d="M36 8H24c-3 0-2 2-2 2v24s1-2 2-2h12V8z" fill="#6abc8a" opacity="0.9"/>
                        <line x1="22" y1="10" x2="22" y2="32" stroke="#6abc8a" stroke-width="1.5"/>
                        <line x1="26" y1="14" x2="33" y2="14" stroke="#fff" stroke-width="1.5" stroke-linecap="round" opacity="0.4"/>
                        <line x1="26" y1="19" x2="33" y2="19" stroke="#fff" stroke-width="1.5" stroke-linecap="round" opacity="0.4"/>
                        <line x1="26" y1="24" x2="33" y2="24" stroke="#fff" stroke-width="1.5" stroke-linecap="round" opacity="0.4"/>
                    </svg>
                    <span class="profile-stat-value" style="color:#6abc8a;font-size:38px;"><?= $stat_chapters ?></span>
                </div>
                <span class="profile-stat-label" style="color:#6abc8a;font-size:14px;">Chapitres lus</span>
            </div>

            <div class="profile-stat">
                <div style="display:flex;align-items:center;justify-content:center;gap:12px;">
                    <svg viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:52px;height:52px;filter:drop-shadow(0 0 6px #f5c842);flex-shrink:0;">
                        <path d="M22 6l4.5 9 10 1.5-7.2 7 1.7 10L22 29l-9 4.5 1.7-10L7.5 16.5l10-1.5z" fill="#f5c842" opacity="0.85" stroke="#f5c842" stroke-width="1.5" stroke-linejoin="round"/>
                    </svg>
                    <span class="profile-stat-value" style="color:#f5c842;font-size:38px;"><?= $stat_ratings ?></span>
                </div>
                <span class="profile-stat-label" style="color:#f5c842;font-size:14px;">Œuvres notées</span>
            </div>

            <div class="fav-manga-wrap" id="favMangaWrap" <?= $is_own_profile ? 'onclick="openPicker(\'manga\')" title="Choisir un coup de coeur"' : '' ?>>
                <span class="fav-manga-label" id="favMangaLabel">Coup de cœur :</span>
                <?php if ($fav_manga): ?>
                    <img src="<?= htmlspecialchars($fav_manga['image_url'] ?? '') ?>" alt="<?= htmlspecialchars($fav_manga['title']) ?>" class="fav-manga-cover" id="favMangaCover">
                    <span class="fav-manga-title" id="favMangaTitle"><?= htmlspecialchars($fav_manga['title']) ?></span>
                <?php else: ?>
                    <div class="fav-manga-empty" id="favMangaEmpty">＋</div>
                    <span class="fav-manga-title" id="favMangaTitle" style="color:rgba(188,106,106,.4);"><?= $is_own_profile ? 'Choisir' : 'Aucun' ?></span>
                <?php endif; ?>
                <?php if ($is_own_profile): ?><div class="fav-edit-overlay"><span>Modifier</span></div><?php endif; ?>
            </div>
        </div>

    </div>

    <div class="mobile-section-gap"></div>


    <div class="profile-section-card">
        <div class="profile-section-title">
            Activité récente
        </div>
        <div class="history-list">
        <?php
        $history = [];
        try {
            $stmt_h = $db->prepare("
                SELECT
                    rh.manga_id,
                    rh.chapter_id,
                    rh.read_at,
                    m.title                                        AS manga_title,
                    m.image_url                                    AS manga_cover,
                    c.chapter_number                               AS chapter_number,
                    (SELECT MAX(c2.chapter_number)
                     FROM chapters c2
                     WHERE c2.manga_id = rh.manga_id)             AS max_chapter
                FROM reading_history rh
                JOIN mangas m ON m.id = rh.manga_id
                LEFT JOIN chapters c ON c.id = rh.chapter_id
                WHERE rh.user_id = ?
                AND rh.id = (
                    SELECT rh2.id FROM reading_history rh2
                    WHERE rh2.user_id = rh.user_id AND rh2.manga_id = rh.manga_id
                    ORDER BY rh2.read_at DESC, rh2.id DESC
                    LIMIT 1
                )
                ORDER BY rh.read_at DESC
                LIMIT 5
            ");
            $stmt_h->execute([$target_id]);
            $history = $stmt_h->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {}

        if (empty($history)): ?>
            <div class="profile-empty">Aucune activité pour le moment.</div>
        <?php else:
            foreach ($history as $h):
                $chap_lu  = $h['chapter_number'] !== null ? (float)$h['chapter_number'] : null;
                $chap_max = $h['max_chapter']    !== null ? (float)$h['max_chapter']    : null;

                if ($chap_lu !== null && $chap_max !== null) {
                    $chap_lu_str  = ($chap_lu  == (int)$chap_lu)  ? (int)$chap_lu  : $chap_lu;
                    $chap_max_str = ($chap_max == (int)$chap_max) ? (int)$chap_max : $chap_max;
                    $sub_str  = 'Chapitre '.$chap_lu_str.' / '.$chap_max_str;
                    $percent  = min(100, round($chap_lu / $chap_max * 100));
                } elseif ($chap_lu !== null) {
                    $chap_lu_str = ($chap_lu == (int)$chap_lu) ? (int)$chap_lu : $chap_lu;
                    $sub_str = 'Chapitre '.$chap_lu_str;
                    $percent = null;
                } else {
                    $sub_str = 'Chapitre —';
                    $percent = null;
                }
        ?>
            <div class="history-item">
                <a href="manga.php?id=<?= (int)$h['manga_id'] ?>" class="history-cover-link">
                    <?php if (!empty($h['manga_cover'])): ?>
                        <img src="<?= htmlspecialchars($h['manga_cover']) ?>" alt="" class="history-cover">
                    <?php else: ?>
                        <div class="history-cover history-cover-placeholder"></div>
                    <?php endif; ?>
                </a>
                <div class="history-info">
                    <div class="history-top-row">
                        <a href="manga.php?id=<?= (int)$h['manga_id'] ?>" class="history-title"><?= htmlspecialchars($h['manga_title']) ?></a>
                    </div>
                    <div class="history-sub"><?= htmlspecialchars($sub_str) ?></div>
                    <?php if ($percent !== null): ?>
                    <div class="history-bar-row">
                        <div class="history-bar-track">
                            <div class="history-bar-fill" style="width:<?= $percent ?>%"></div>
                        </div>
                        <span class="history-percent"><?= $percent ?>%</span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; endif; ?>
        </div>
    </div>

</div>

<div class="picker-overlay" id="avatarPicker">
    <div class="picker-modal">
        <button class="picker-close" onclick="closePicker('avatar')">✕</button>
        <h2>Choisissez votre photo de profil</h2>
        <p>Le changement de la photo de profil s'effectuera en se déconnectant puis en se reconnectant</p>
        <?php if (empty($avatars)): ?>
            <div class="picker-empty">Aucune photo de profil disponible pour le moment.</div>
        <?php else: ?>
        <div class="picker-avatar-grid" id="avatarGrid">
            <?php foreach ($avatars as $av): ?>
            <div class="picker-avatar-item <?= ($avatar_url === $av['image_url']) ? 'selected' : '' ?>"
                 data-id="<?= $av['id'] ?>"
                 data-url="<?= htmlspecialchars($av['image_url']) ?>"
                 onclick="selectItem('avatar', this)">
                <div class="picker-avatar-circle">
                    <img src="<?= htmlspecialchars($av['image_url']) ?>" alt="<?= htmlspecialchars($av['label']) ?>">
                    <div class="picker-avatar-selected-check">✓</div>
                </div>
                <span class="picker-item-label"><?= htmlspecialchars($av['label'] ?: '') ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <button class="picker-save-btn" id="avatarSaveBtn" onclick="saveChoice('avatar')" disabled>Choisir cet avatar</button>
        <div class="picker-feedback" id="avatarFeedback">✓ Avatar mis à jour !</div>
        <?php endif; ?>
    </div>
</div>

<div class="picker-overlay" id="bannerPicker">
    <div class="picker-modal">
        <button class="picker-close" onclick="closePicker('banner')">✕</button>
        <h2>Choisissez votre bannière</h2>
        <p>Cliquez sur une bannière pour la sélectionner</p>
        <?php if (empty($banners)): ?>
            <div class="picker-empty">Aucune bannière disponible pour le moment.<br>Un admin peut en ajouter depuis le panneau d'administration.</div>
        <?php else: ?>
        <div class="picker-banner-grid" id="bannerGrid">
            <?php foreach ($banners as $bn): ?>
            <div class="picker-banner-item <?= ($banner_url === $bn['image_url']) ? 'selected' : '' ?>"
                 data-id="<?= $bn['id'] ?>"
                 data-url="<?= htmlspecialchars($bn['image_url']) ?>"
                 onclick="selectItem('banner', this)">
                <img src="<?= htmlspecialchars($bn['image_url']) ?>" alt="<?= htmlspecialchars($bn['label']) ?>">
                <div class="picker-check">✓</div>
                <div class="picker-item-label"><?= htmlspecialchars($bn['label'] ?: '') ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <button class="picker-save-btn" id="bannerSaveBtn" onclick="saveChoice('banner')" disabled>Choisir cette bannière</button>
        <div class="picker-feedback" id="bannerFeedback">✓ Bannière mise à jour !</div>
        <?php endif; ?>
    </div>
</div>

<div class="picker-overlay" id="mangaPicker">
    <div class="picker-modal">
        <button class="picker-close" onclick="closePicker('manga')">✕</button>
        <h2>Choisissez votre coup de cœur</h2>
        <p>Sélectionnez un manga de la bibliothèque</p>
        <input type="text" class="picker-manga-search" placeholder="Filtrer..." oninput="filterMangas(this.value)">
        <?php if (empty($mangas)): ?>
            <div class="picker-empty">Aucun manga disponible.</div>
        <?php else: ?>
        <div class="picker-manga-grid" id="mangaGrid">
            <?php foreach ($mangas as $m): ?>
            <div class="picker-manga-item <?= (!empty($user['fav_manga_id']) && $user['fav_manga_id'] == $m['id']) ? 'selected' : '' ?>"
                 data-id="<?= $m['id'] ?>"
                 data-url="<?= htmlspecialchars($m['image_url'] ?? '') ?>"
                 data-title="<?= htmlspecialchars(strtolower($m['title'])) ?>"
                 onclick="selectItem('manga', this)">
                <img src="<?= htmlspecialchars($m['image_url'] ?? '') ?>" alt="" class="picker-manga-cover">
                <span class="picker-item-label"><?= htmlspecialchars($m['title']) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <button class="picker-save-btn" id="mangaSaveBtn" onclick="saveChoice('manga')" disabled>Choisir ce manga</button>
        <div class="picker-feedback" id="mangaFeedback">Coup de cœur mis à jour !</div>
        <?php endif; ?>
    </div>
</div>

<script>
(function() {
    if (window.innerWidth > 640) return;
    const wrap = document.getElementById('favMangaWrap');
    if (!wrap) return;
    const label = document.getElementById('favMangaLabel');
    const title = document.getElementById('favMangaTitle');
    if (!label || !title) return;
    const textDiv = document.createElement('div');
    textDiv.className = 'fav-text-inner';
    const cover = document.getElementById('favMangaCover') || document.getElementById('favMangaEmpty');
    if (cover) {
        cover.after(textDiv);
    } else {
        wrap.appendChild(textDiv);
    }
    textDiv.appendChild(label);
    textDiv.appendChild(title);
})();

let pickerSelected = { avatar: null, banner: null };

function openPicker(type) {
    document.getElementById(type + 'Picker').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closePicker(type) {
    document.getElementById(type + 'Picker').classList.remove('active');
    document.body.style.overflow = '';
}

function selectItem(type, el) {
    const grid = document.getElementById(type + 'Grid');
    const cls = type === 'avatar' ? 'picker-avatar-item' : type === 'banner' ? 'picker-banner-item' : 'picker-manga-item';
    grid.querySelectorAll('.' + cls).forEach(i => i.classList.remove('selected'));
    el.classList.add('selected');
    pickerSelected[type] = { id: el.dataset.id, url: el.dataset.url, title: el.querySelector('.picker-item-label')?.textContent };
    const btn = document.getElementById(type + 'SaveBtn');
    if (btn) btn.disabled = false;
}

function filterMangas(query) {
    const q = query.toLowerCase();
    document.querySelectorAll('#mangaGrid .picker-manga-item').forEach(item => {
        item.style.display = item.dataset.title.includes(q) ? '' : 'none';
    });
}

async function saveChoice(type) {
    const sel = pickerSelected[type];
    if (!sel) return;
    const btn = document.getElementById(type + 'SaveBtn');
    btn.disabled = true;
    btn.textContent = 'Enregistrement…';

    try {
        const res  = await fetch('setters/set_avatar.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type, id: parseInt(sel.id) })
        });
        const data = await res.json();
        if (data.success) {
            if (type === 'avatar') {
                let img = document.getElementById('avatarImg');
                const svg = document.getElementById('avatarSvg');
                if (!img) {
                    img = document.createElement('img');
                    img.id = 'avatarImg';
                    const wrap = document.getElementById('avatarZone');
                    if (svg) svg.remove();
                    wrap.insertBefore(img, wrap.firstChild);
                }
                img.src = sel.url;
            } else if (type === 'banner') {
                let img = document.getElementById('bannerImg');
                const ph = document.getElementById('bannerPlaceholder');
                if (!img) {
                    img = document.createElement('img');
                    img.id = 'bannerImg';
                    const zone = document.getElementById('bannerZone');
                    if (ph) ph.remove();
                    zone.insertBefore(img, zone.firstChild);
                }
                img.src = sel.url;
            } else if (type === 'manga') {
                let cover = document.getElementById('favMangaCover');
                const empty = document.getElementById('favMangaEmpty');
                if (!cover) {
                    cover = document.createElement('img');
                    cover.id = 'favMangaCover';
                    cover.className = 'fav-manga-cover';
                    const wrap = document.getElementById('favMangaWrap');
                    if (empty) empty.remove();
                    const label = wrap.querySelector('.fav-manga-label');
                    label.insertAdjacentElement('afterend', cover);
                }
                cover.src = sel.url;
                const titleEl = document.getElementById('favMangaTitle');
                if (titleEl) { titleEl.textContent = sel.title; titleEl.style.color = ''; }
            }
            const fb = document.getElementById(type + 'Feedback');
            fb.style.display = 'block';
            setTimeout(() => { fb.style.display = 'none'; closePicker(type); }, 1500);
        }
    } catch(e) {}
    btn.disabled = false;
    btn.textContent = type === 'avatar' ? 'Choisir cet avatar' : type === 'banner' ? 'Choisir cette bannière' : 'Choisir ce manga';
}

document.getElementById('avatarPicker').addEventListener('click', function(e) { if (e.target === this) closePicker('avatar'); });
document.getElementById('bannerPicker').addEventListener('click', function(e) { if (e.target === this) closePicker('banner'); });
document.getElementById('mangaPicker').addEventListener('click', function(e) { if (e.target === this) closePicker('manga'); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closePicker('avatar'); closePicker('banner'); closePicker('manga'); } });
</script>