<?php
$encoded = $_GET['u'] ?? '';

if ($encoded === '') {
    http_response_code(400);
    exit('Paramètre u manquant.');
}

$url = base64_decode(strtr($encoded, '-_', '+/'));

if ($url === false || $url === '') {
    http_response_code(400);
    exit('Paramètre u invalide.');
}

$host = parse_url($url, PHP_URL_HOST);
if (!$host || !preg_match('/(^|\.)mangadex\.(org|network)$/i', $host)) {
    http_response_code(403);
    exit('Hôte non autorisé.');
}

$opts = [
    'http' => [
        'method'  => 'GET',
        'timeout' => 20,
        'header'  => implode("\r\n", [
            'User-Agent: YureiScan/1.0 (contact@yurei-scan.fr)',
            'Referer: https://mangadex.org/',
            'Accept: image/*',
        ]),
        'ignore_errors' => true,
    ],
];

$ctx  = stream_context_create($opts);
$data = @file_get_contents($url, false, $ctx);

if ($data === false) {
    http_response_code(502);
    exit('Impossible de récupérer l\'image.');
}

$contentType = 'image/jpeg';
if (isset($http_response_header)) {
    foreach ($http_response_header as $h) {
        if (stripos($h, 'Content-Type:') === 0) {
            $contentType = trim(substr($h, 13));
            break;
        }
    }
}

header('Content-Type: ' . $contentType);
header('Cache-Control: public, max-age=86400');
echo $data;