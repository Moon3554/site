<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'check_captcha.php';
require_once 'db.php';

$error_message   = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error_message = 'Veuillez remplir tous les champs.';
    } else {
        try {
            $stmt = $db->prepare("SELECT id, username, password, is_admin FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['is_admin'] = $user['is_admin'];
                $_SESSION['username'] = $user['username'];

                $success_message = 'Connexion réussie ! Redirection...';
                header("Refresh: 1; URL=index.php");
                exit();
            } else {
                $error_message = 'Nom d\'utilisateur ou mot de passe incorrect.';
            }
        } catch (PDOException $e) {
            $error_message = 'Erreur de connexion : ' . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Yurei Scan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .login-container { display: flex; justify-content: center; align-items: center; min-height: calc(100vh - 160px); padding: 40px 20px; }
        .login-box { background: rgba(255,255,255,0.05); backdrop-filter: blur(15px); border-radius: 25px; padding: 45px 50px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 30px rgba(0,0,0,0.4); width: 100%; max-width: 450px; position: relative; overflow: hidden; }
        .login-box::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: #bc6a6a; }
        .login-title { text-align: center; font-size: 32px; margin-bottom: 35px; font-weight: 700; color: #bc6a6a; }
        .alert { padding: 15px 20px; border-radius: 12px; margin-bottom: 25px; font-size: 14px; animation: slideDown 0.3s ease; }
        .alert-error { background: rgba(231,76,60,0.15); border: 1px solid rgba(231,76,60,0.4); color: #ff6b6b; }
        .alert-success { background: rgba(40,167,69,0.15); border: 1px solid rgba(40,167,69,0.4); color: #51cf66; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .login-form { display: flex; flex-direction: column; gap: 25px; }
        .form-group { display: flex; flex-direction: column; gap: 10px; }
        .form-label { font-size: 14px; font-weight: 600; color: #e0e0e0; }
        .form-input { padding: 14px 18px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.15); background: rgba(0,0,0,0.3); color: #fff; font-size: 15px; transition: all 0.3s ease; }
        .form-input:focus { outline: none; border-color: #bc6a6a; background: rgba(0,0,0,0.4); box-shadow: 0 0 0 3px rgba(188,106,106,0.1); }
        .form-input::placeholder { color: #777; }
        .submit-btn { background: #bc6a6a; color: white; border: none; padding: 15px; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(188,106,106,0.4); margin-top: 10px; }
        .submit-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(188,106,106,0.6); }
        .submit-btn:active { transform: translateY(0); }
        .form-footer { text-align: center; margin-top: 25px; padding-top: 25px; border-top: 1px solid rgba(255,255,255,0.1); }
        .form-footer a { color: #bc6a6a; text-decoration: none; font-weight: 600; transition: color 0.3s ease; }
        .form-footer a:hover { color: #a85c5c; text-decoration: underline; }
        .login-info { display: flex; flex-direction: column; gap: 10px; background: rgba(188,106,106,0.08); border: 1px solid rgba(188,106,106,0.2); border-radius: 12px; padding: 15px 18px; margin-bottom: 25px; }
        .login-info-item { display: flex; align-items: center; gap: 10px; font-size: 14px; color: #ccc; }
        .login-info-icon { font-size: 18px; flex-shrink: 0; }
        @media (max-width: 480px) {
            .login-box { padding: 30px 25px; }
            .login-title { font-size: 26px; }
        }
    </style>
</head>
<?php include 'header.php'; ?>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2 class="login-title">Connexion</h2>

            <div class="login-info">
                <div class="login-info-item">
                    <span>Connectez-vous pour retrouver l'historique de vos lectures, noter vos mangas préférés et avoir accès aux différentes annonces et mises à jour du site.</span>
                </div>
            </div>

            <?php if (!empty($error_message)): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
            <?php endif; ?>

            <form method="POST" class="login-form">
                <div class="form-group">
                    <label for="username" class="form-label">Nom d'utilisateur</label>
                    <input type="text" id="username" name="username" class="form-input"
                           placeholder="Entrez votre nom d'utilisateur"
                           required autocomplete="username">
                </div>
                <div class="form-group">
                    <label for="password" class="form-label">Mot de passe</label>
                    <input type="password" id="password" name="password" class="form-input"
                           placeholder="Entrez votre mot de passe"
                           required autocomplete="current-password">
                </div>
                <button type="submit" class="submit-btn">Se connecter</button>
            </form>

            <div class="form-footer">
                <p>Pas encore de compte ? <a href="register.php">S'inscrire</a></p>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>