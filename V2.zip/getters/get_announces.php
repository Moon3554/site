<?php
header('Content-Type: application/json; charset=utf-8');

$file = __DIR__ . '/../announces.txt';

if (isset($_GET['raw'])) {
    if (!file_exists($file)) {
        echo '';
    } else {
        echo file_get_contents($file);
    }
    exit;
}

if (!file_exists($file)) {
    echo json_encode([]);
    exit;
}

$lines  = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$result = [];

foreach (array_reverse($lines) as $line) {
    $line = trim($line);
    if ($line === '' || strpos($line, '#') === 0) continue; 

    if (strpos($line, '|') !== false) {
        $parts = explode('|', $line, 3);
        $date    = trim($parts[0]);
        $title   = isset($parts[2]) ? trim($parts[1]) : '';
        $message = isset($parts[2]) ? trim($parts[2]) : trim($parts[1]);
        $ts      = strtotime($date);

        $result[] = [
            'date'    => $ts ? date('d/m/Y', $ts) : $date,
            'title'   => htmlspecialchars($title, ENT_QUOTES, 'UTF-8'),
            'message' => htmlspecialchars($message, ENT_QUOTES, 'UTF-8'),
            'ts'      => $ts ?: 0,
        ];
    } else {
        $result[] = [
            'date'    => '',
            'title'   => '',
            'message' => htmlspecialchars(trim($line), ENT_QUOTES, 'UTF-8'),
            'ts'      => 0,
        ];
    }
}

echo json_encode($result, JSON_UNESCAPED_UNICODE);