<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    http_response_code(403);
    echo json_encode([]);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

if ($user_id <= 0) {
    echo json_encode([]);
    exit();
}

try {
    $stmt = $db->prepare("
        SELECT
            m.title        AS serie_title,
            r.rating       AS note,
            r.created_at   AS rated_at
        FROM manga_ratings r
        JOIN mangas m ON m.id = r.manga_id
        WHERE r.user_id = ?
        ORDER BY r.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $ratings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($ratings);
} catch (PDOException $e) {
    http_response_code(200);
    echo json_encode([]);
}