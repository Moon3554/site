<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    http_response_code(403);
    echo json_encode([]);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

try {
    $stmt = $db->query(
        "SELECT id, username, is_admin, is_staff, created_at
         FROM users
         ORDER BY created_at DESC"
    );
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($members);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([]);
}