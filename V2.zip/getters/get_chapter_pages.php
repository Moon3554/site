<?php
require_once __DIR__ . '/../db.php';

if (!isset($_GET['chapter_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'chapter_id manquant']);
    exit;
}

$chapter_id = (int)$_GET['chapter_id'];

try {
    $stmt = $db->prepare("SELECT id, page_url, page_order FROM chapter_pages WHERE chapter_id = ? ORDER BY page_order ASC");
    $stmt->execute([$chapter_id]);
    $pages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json');
    echo json_encode($pages);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
