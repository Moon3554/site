<?php
session_start();
require_once __DIR__ . '/../db.php';

if (!isset($_GET['manga_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'manga_id requis']);
    exit;
}

$manga_id = (int)$_GET['manga_id'];

try {
    $stmt = $db->prepare("
        SELECT chapter_number 
        FROM planning_sorties 
        WHERE manga_id = :manga_id 
        AND statut IN ('prevu', 'en_cours', 'sorti')
        ORDER BY CAST(chapter_number AS DECIMAL(10,2)) DESC, id DESC
        LIMIT 1
    ");
    $stmt->execute([':manga_id' => $manga_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $lastChapter = $result ? $result['chapter_number'] : null;
    
    header('Content-Type: application/json');
    echo json_encode(['lastChapter' => $lastChapter]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
