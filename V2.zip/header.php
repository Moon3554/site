<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (isset($_SESSION['user_id']) && !isset($_SESSION['user_avatar'])) {
    try {
        require_once __DIR__ . '/db.php';
        $stmt = $db->prepare("SELECT avatar FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $_SESSION['user_avatar'] = $row['avatar'] ?? null;
    } catch (Exception $e) { $_SESSION['user_avatar'] = null; }
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
*{margin:0;padding:0;box-sizing:border-box}
img{user-select:none;-webkit-user-drag:none;pointer-events:auto}
body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#000;color:#fff;padding-top:70px}

.main-header{position:fixed;top:0;left:0;width:100%;background:#000;border-bottom:3px solid #333;box-shadow:0 4px 20px rgba(0,0,0,.5);z-index:1000}
.header-container{max-width:1600px;margin:0 auto;padding:15px 30px;display:flex;justify-content:space-between;align-items:center;gap:20px}

.burger-menu{display:none;cursor:pointer;padding:8px;z-index:1001;width:44px;height:44px;align-items:center;justify-content:center;position:relative}
.burger-icon{width:24px;height:24px;position:relative;transition:.5s ease-in-out}
.burger-icon span{display:block;position:absolute;height:3px;width:100%;background:#fff;border-radius:3px;left:0;transition:.25s ease-in-out}
.burger-icon span:nth-child(1){top:0}
.burger-icon span:nth-child(2),.burger-icon span:nth-child(3){top:10px}
.burger-icon span:nth-child(4){top:20px}
.burger-menu.active .burger-icon span:nth-child(1),.burger-menu.active .burger-icon span:nth-child(4){top:10px;width:0;left:50%}
.burger-menu.active .burger-icon span:nth-child(2){transform:rotate(45deg)}
.burger-menu.active .burger-icon span:nth-child(3){transform:rotate(-45deg)}

.site-logo{display:flex;align-items:center;text-decoration:none;flex-shrink:0}
.logo-img{height:40px;margin-right:10px}
.site-title{font-size:28px;font-weight:700;color:#bc6a6a;white-space:nowrap}

.nav-links{display:flex;align-items:center;gap:25px;justify-content:center}
.nav-link{display:flex;align-items:center;gap:8px;color:#fff;text-decoration:none;font-weight:600;font-size:17px;padding:8px 0;transition:all .3s ease;position:relative}
.nav-link::after{content:'';position:absolute;bottom:0;left:0;width:0;height:2px;background:#bc6a6a;transition:width .3s ease}
.nav-link:hover{color:#bc6a6a}
.nav-link:hover::after{width:100%}
.nav-link-icon{width:22px;height:22px;fill:currentColor}

.header-right-tools{display:flex;align-items:center;gap:12px;flex-shrink:0}
.auth-section{display:flex;gap:18px;flex-shrink:0;margin-left:auto;align-items:center}
.auth-btn{padding:10px 20px;border-radius:25px;font-size:14px;font-weight:600;text-decoration:none;background:rgba(255,255,255,.1);color:#fff;border:2px solid rgba(255,255,255,.3);transition:all .3s ease;white-space:nowrap}
.auth-btn:hover{background:rgba(255,255,255,.2);border-color:#bc6a6a}

.user-menu-wrap{position:relative;flex-shrink:0}
.user-avatar-btn{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.1);border:2px solid rgba(255,255,255,.3);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .3s ease;overflow:hidden;padding:0}
.user-avatar-btn:hover{border-color:#bc6a6a;background:rgba(188,106,106,.15)}
.user-avatar-btn svg{width:24px;height:24px;fill:#fff;flex-shrink:0}
.user-avatar-btn img{width:100%;height:100%;object-fit:cover;border-radius:50%;}
.user-dropdown{position:absolute;top:calc(100% + 12px);right:0;width:200px;background:rgba(10,10,10,.97);backdrop-filter:blur(20px);border:1px solid rgba(188,106,106,.35);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.7);display:none;opacity:0;transition:opacity .2s;z-index:2000;overflow:hidden}
.user-menu-wrap.open .user-dropdown{display:block;opacity:1}
.user-dropdown-item{display:flex;align-items:center;gap:12px;padding:13px 18px;color:#fff;text-decoration:none;font-size:14px;font-weight:600;transition:all .25s ease;border-bottom:1px solid rgba(255,255,255,.06)}
.user-dropdown-item:last-child{border-bottom:none}
.user-dropdown-item:hover{background:rgba(188,106,106,.2);color:#bc6a6a}
.user-dropdown-item svg{width:18px;height:18px;fill:currentColor;flex-shrink:0}
.user-dropdown-sep{height:1px;background:rgba(255,255,255,.08);margin:4px 0}

.search-container{position:relative}
.search-input{width:200px;padding:10px 40px 10px 15px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);border-radius:25px;color:#fff;font-size:14px;outline:none;transition:all .3s ease}
.search-input::placeholder,.mobile-search-input::placeholder{color:rgba(255,255,255,.5)}
.search-input:focus{border-color:#bc6a6a;width:250px;background:rgba(255,255,255,.15)}
.search-btn,.mobile-search-btn{position:absolute;right:5px;top:50%;transform:translateY(-50%);width:40px;height:40px;display:flex;align-items:center;justify-content:center;background:transparent;border:none;color:#fff;cursor:pointer;padding:0;transition:color .3s ease;flex-shrink:0}
.search-btn:hover{color:#bc6a6a}
.search-btn svg,.mobile-search-btn svg{width:20px;height:20px;fill:currentColor;flex-shrink:0}
.search-results{position:absolute;top:100%;left:0;right:0;margin-top:10px;background:rgba(0,0,0,.98);backdrop-filter:blur(20px);border:1px solid rgba(188,106,106,.3);border-radius:15px;max-height:400px;overflow-y:auto;display:none;box-shadow:0 8px 32px rgba(0,0,0,.6);z-index:1001}
.search-results.active{display:block}
.search-result-item{display:flex;align-items:center;gap:15px;padding:12px 15px;color:#fff;text-decoration:none;transition:all .3s ease;border-bottom:1px solid rgba(255,255,255,.05)}
.search-result-item:last-child{border-bottom:none}
.search-result-item:hover{background:rgba(188,106,106,.2)}
.search-result-cover{width:50px;height:70px;object-fit:cover;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.3);flex-shrink:0}
.search-result-info{flex:1;min-width:0}
.search-result-title{font-weight:600;font-size:15px;margin-bottom:4px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.search-result-meta{font-size:12px;color:rgba(255,255,255,.6)}
.search-no-results,.search-loading{padding:20px;text-align:center;font-size:14px}
.search-no-results{color:rgba(255,255,255,.6)}
.search-loading{color:#bc6a6a}

.mobile-menu{position:fixed;top:70px;left:-100%;width:280px;height:calc(100vh - 70px);background:rgba(0,0,0,.98);backdrop-filter:blur(10px);transition:left .3s ease;z-index:999;overflow-y:auto;padding:20px 0}
.mobile-menu.active{left:0}
.mobile-menu-overlay{position:fixed;top:70px;left:0;width:100%;height:calc(100vh - 70px);background:rgba(0,0,0,.7);display:none;z-index:998}
.mobile-menu-overlay.active{display:block}
.mobile-search{display:none;padding:15px 20px}
.mobile-search-container{position:relative}
.mobile-search-input{width:100%;padding:12px 40px 12px 15px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);border-radius:25px;color:#fff;font-size:14px;outline:none}
.mobile-search-input:focus{border-color:#bc6a6a;background:rgba(255,255,255,.15)}
.mobile-search-container .search-results{position:relative;margin-top:10px}
.mobile-nav-link{display:flex;align-items:center;gap:15px;color:#fff;text-decoration:none;font-weight:600;font-size:16px;padding:18px 25px;transition:all .3s ease;border-left:4px solid transparent}
.mobile-nav-link:hover,.mobile-nav-link:active{background:rgba(188,106,106,.2);border-left-color:#bc6a6a;color:#bc6a6a}
.mobile-nav-link svg{width:24px;height:24px;fill:currentColor;flex-shrink:0}

.adult-filter-wrap{display:flex;align-items:center;gap:8px;flex-shrink:0;cursor:pointer;width:140px}
.adult-filter-icon-svg{width:34px;height:34px;flex-shrink:0;transition:opacity .3s,filter .3s;filter:grayscale(1);opacity:.4}
.adult-filter-wrap.active .adult-filter-icon-svg{filter:grayscale(0);opacity:1}
.adult-filter-wrap.active .adult-filter-icon-svg line,.mobile-adult-row.active svg line{display:none}
.adult-toggle{position:relative;width:44px;height:24px;flex-shrink:0}
.adult-toggle input{opacity:0;width:0;height:0;position:absolute}
.adult-toggle-slider{position:absolute;inset:0;background:#2a2a2a;border-radius:24px;border:2px solid #444;transition:all .3s ease;cursor:pointer}
.adult-toggle-slider::before{content:'';position:absolute;width:16px;height:16px;border-radius:50%;background:#666;top:50%;left:2px;transform:translateY(-50%);transition:all .3s ease}
.adult-toggle input:checked + .adult-toggle-slider{background:rgba(188,106,106,.25);border-color:#bc6a6a}
.adult-toggle input:checked + .adult-toggle-slider::before{background:#bc6a6a;left:calc(100% - 18px);box-shadow:0 0 8px rgba(188,106,106,.7)}
.mobile-adult-row{display:flex;align-items:center;gap:12px;padding:16px 25px;border-top:1px solid #1a1a1a;border-bottom:1px solid #1a1a1a;margin-bottom:8px}
.mobile-adult-row svg{flex-shrink:0;transition:opacity .3s,filter .3s;filter:grayscale(1);opacity:.4}
.mobile-adult-row.active svg{filter:grayscale(0);opacity:1}
.mobile-adult-label{color:#fff;font-weight:600;font-size:15px;flex:1}

.announce-diamond-wrap{position:relative;flex-shrink:0}
.announce-diamond-wrap-mobile{display:none;position:relative;align-items:center;flex-shrink:0;z-index:1002}
.announce-diamond{position:relative;width:38px;height:38px;background:transparent;border:2px solid #fff;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .25s,box-shadow .25s,border-color .25s;box-shadow:0 2px 10px rgba(255,255,255,.15)}
.announce-diamond:hover{border-color:#bc6a6a;box-shadow:0 4px 16px rgba(188,106,106,.5)}
.announce-diamond svg{color:#fff;transition:color .25s}
.announce-diamond:hover svg{color:#bc6a6a}
.announce-diamond.has-news::after{content:'';position:absolute;top:-4px;right:-4px;width:10px;height:10px;background:#e74c3c;border-radius:50%;border:2px solid #000}
.announce-popup{position:absolute;top:calc(100% + 15px);right:0;width:320px;background:rgba(10,10,10,.97);backdrop-filter:blur(20px);border:1px solid rgba(188,106,106,.35);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.7);display:none;opacity:0;transition:opacity .2s;z-index:2000;max-height:500px}
.announce-diamond-wrap.open .announce-popup{display:block;opacity:1}
.announce-diamond-wrap-mobile .announce-popup{position:fixed;top:62px;left:10px;right:10px;width:auto;max-width:340px;z-index:9999}
.announce-diamond-wrap-mobile.open .announce-popup{display:block;opacity:1}
.announce-popup-header{display:flex;align-items:center;justify-content:space-between;padding:14px 18px 10px;border-bottom:1px solid rgba(255,255,255,.08);font-weight:700;font-size:15px;color:#bc6a6a}
.announce-popup-body{padding:10px 18px 14px;max-height:420px;overflow-y:auto;scrollbar-width:none;-ms-overflow-style:none}
.announce-popup-body::-webkit-scrollbar{display:none}
.announce-login-message{text-align:center;padding:16px 12px;color:#aaa}
.announce-login-message-icon{margin-bottom:10px;display:flex;justify-content:center}
.announce-login-message h3{color:#bc6a6a;font-size:15px;margin-bottom:6px;font-weight:700}
.announce-login-message p{font-size:12px;line-height:1.4;margin-bottom:10px}
.announce-login-actions{display:flex;gap:8px;flex-direction:column;margin-top:8px}
.announce-login-actions a{padding:10px 16px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600;transition:all .3s ease;text-align:center}
.announce-login-actions .btn-login{background:#bc6a6a;color:#fff;border:1px solid #bc6a6a}
.announce-login-actions .btn-login:hover{background:#a85858;border-color:#a85858}
.announce-login-actions .btn-register{background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.2)}
.announce-login-actions .btn-register:hover{background:rgba(188,106,106,.15);border-color:rgba(188,106,106,.4)}
.announce-edit-btn{background:none;border:none;cursor:pointer;font-size:14px;padding:2px 6px;border-radius:6px;color:#fff;opacity:.6;transition:opacity .2s}
.announce-edit-btn:hover{opacity:1;background:rgba(188,106,106,.2)}
.announce-item{padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06);font-size:14px;color:#ddd;line-height:1.5}
.announce-item:last-child{border-bottom:none}
.announce-item-date{font-size:11px;color:#666;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px}
.announce-item-title{font-size:13px;color:#bc6a6a;font-weight:700;margin:6px 0 4px;margin-bottom:6px}
.announce-item-text{color:#e0e0e0}
.announce-empty,.announce-loading{text-align:center;font-size:13px;padding:20px 0}
.announce-empty{color:#555}
.announce-loading{color:#bc6a6a}
.announce-editor-modal{position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(6px);z-index:9999;display:none;align-items:center;justify-content:center}
.announce-editor-modal.open{display:flex}
.announce-editor-box{background:#111;border:1px solid rgba(188,106,106,.4);border-radius:16px;padding:28px;width:600px;max-width:95vw;max-height:85vh;overflow-y:auto}
.announce-editor-box h3{color:#bc6a6a;margin-bottom:8px;font-size:18px}
.announce-editor-box > p{color:#888;font-size:13px;margin-bottom:20px}
.announce-item-edit{background:rgba(255,255,255,.05);border:1px solid rgba(188,106,106,.2);border-radius:12px;padding:16px;margin-bottom:12px;transition:border-color .3s ease}
.announce-item-edit:hover{border-color:rgba(188,106,106,.4)}
.announce-item-edit-field{margin-bottom:12px}
.announce-item-edit-field:last-child{margin-bottom:0}
.announce-item-edit-label{display:block;color:#bc6a6a;font-size:12px;font-weight:600;margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px}
.announce-item-edit-input,.announce-item-edit-textarea{width:100%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:8px;color:#fff;font-size:14px;padding:10px;font-family:inherit;outline:none;transition:border-color .3s ease}
.announce-item-edit-input:focus,.announce-item-edit-textarea:focus{border-color:#bc6a6a;background:rgba(255,255,255,.12)}
.announce-item-edit-textarea{min-height:80px;resize:vertical}
.announce-item-edit-actions{display:flex;gap:8px;margin-top:12px;justify-content:flex-end}
.announce-item-delete-btn{padding:6px 12px;border-radius:6px;background:rgba(231,76,60,.2);border:1px solid rgba(231,76,60,.4);color:#e74c3c;font-size:12px;cursor:pointer;font-weight:600;transition:all .3s ease}
.announce-item-delete-btn:hover{background:rgba(231,76,60,.3);border-color:#e74c3c}
.announce-no-items{text-align:center;color:#666;padding:20px;font-size:14px}
.announce-editor-actions{display:flex;gap:10px;margin-top:20px;justify-content:flex-end;border-top:1px solid rgba(255,255,255,.08);padding-top:20px}

@media(max-width:968px){
    body{padding-top:60px}
    .header-container{padding:15px 20px}
    .site-logo{margin-left:auto}
    .site-title{font-size:24px}
    .logo-img{height:35px}
    .nav-links,.auth-section,.header-right-tools,.adult-filter-wrap{display:none}
    .burger-menu{display:flex}
    .announce-diamond-wrap-mobile{display:flex !important;margin-left:-12px}
    .mobile-search{display:block}
    .main-header{border-bottom:2px solid #333}
    .mobile-menu,.mobile-menu-overlay{top:60px;height:calc(100vh - 60px)}
}
@media(max-width:480px){
    .site-title{font-size:20px}
    .logo-img{height:30px;margin-right:8px}
    .mobile-menu{width:100%}
    .header-container{padding:12px 15px}
}
</style>

<header class="main-header" id="mainHeader">
    <div class="header-container">
        <div class="burger-menu" id="burgerMenu">
            <div class="burger-icon"><span></span><span></span><span></span><span></span></div>
        </div>

        <div class="announce-diamond-wrap-mobile" id="announceDiamondWrapMobile">
            <div class="announce-diamond" id="announceDiamondMobile" title="Annonces">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
            </div>
            <div class="announce-popup" id="announcePopupMobile">
                <div class="announce-popup-header">
                    <span>Annonces</span>
                    <?php if (!empty($_SESSION['is_admin'])): ?>
                    <button class="announce-edit-btn" onclick="openAnnounceEditor(event)">modifier les annonces</button>
                    <?php endif; ?>
                </div>
                <div class="announce-popup-body" id="announceBodyMobile"><div class="announce-loading">Chargement...</div></div>
            </div>
        </div>

        <a href="index.php" class="site-logo">
            <img src="https://i.ibb.co/LdCC28Wk/logo-site.png" alt="Logo" class="logo-img">
            <span class="site-title">Yurei Scan</span>
        </a>

        <nav class="nav-links">
            <?php
            $page = basename($_SERVER['PHP_SELF']);
            $nav = [
                ['index.php','M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z','Accueil'],
                ['manga_list.php','M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z','Séries'],
                ['planning.php','M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z','Planning'],
                ['recrutement.php','M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z','Candidatures'],
                ['informations.php','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z','Information'],
            ];
            foreach ($nav as [$href, $path, $label]):
            ?>
            <a href="<?= $href ?>" class="nav-link">
                <svg class="nav-link-icon" viewBox="0 0 24 24"><path d="<?= $path ?>"/></svg>
                <span><?= $label ?></span>
            </a>
            <?php endforeach; ?>
        </nav>

        <div class="header-right-tools">
            <div class="search-container">
                <input type="text" class="search-input" id="searchInput" placeholder="Rechercher..." autocomplete="off">
                <button class="search-btn" id="searchBtn">
                    <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
                </button>
                <div class="search-results" id="searchResults"></div>
            </div>

            <div class="adult-filter-wrap" id="adultFilterWrap" title="Afficher/masquer le contenu adulte (18+)" style="<?php echo basename($_SERVER['PHP_SELF']) !== 'manga_list.php' ? 'visibility:hidden;pointer-events:none;' : ''; ?>">
                <svg class="adult-filter-icon-svg" viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="16" fill="#c0392b"/>
                    <text x="18" y="23" text-anchor="middle" font-size="12" font-weight="900" fill="white" font-family="Arial,sans-serif">18+</text>
                    <line x1="5" y1="5" x2="31" y2="31" stroke="white" stroke-width="2.8" stroke-linecap="round"/>
                    <circle cx="18" cy="18" r="16" fill="none" stroke="#e74c3c" stroke-width="1.5"/>
                </svg>
                <label class="adult-toggle" onclick="event.stopPropagation()">
                    <input type="checkbox" id="adultToggle">
                    <span class="adult-toggle-slider"></span>
                </label>
            </div>
        </div>

        <div class="auth-section">
            <div class="announce-diamond-wrap" id="announceDiamondWrap">
                <div class="announce-diamond" id="announceDiamond" title="Annonces et mises à jour">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                </div>
                <div class="announce-popup" id="announcePopup">
                    <div class="announce-popup-header">
                        <span>Annonces & Mises à jour :</span>
                        <?php if (!empty($_SESSION['is_admin'])): ?>
                        <button class="announce-edit-btn" id="announceEditBtn" onclick="openAnnounceEditor(event)" title="Modifier">✏️</button>
                        <?php endif; ?>
                    </div>
                    <div class="announce-popup-body" id="announceBody"><div class="announce-loading">Chargement...</div></div>
                </div>
            </div>
            <div class="user-menu-wrap" id="userMenuWrap">
                <button class="user-avatar-btn" id="userAvatarBtn" title="Mon compte">
                    <?php if (!empty($_SESSION['user_avatar'])): ?>
                        <img src="<?= htmlspecialchars($_SESSION['user_avatar']) ?>" alt="Avatar">
                    <?php else: ?>
                        <svg viewBox="0 0 24 24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
                    <?php endif; ?>
                </button>
                <div class="user-dropdown" id="userDropdown">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="profil.php" class="user-dropdown-item">
                            <svg viewBox="0 0 24 24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg>
                            Mon profil
                        </a>
                        <?php if (!empty($_SESSION['is_admin'])): ?>
                        <a href="admin.php" class="user-dropdown-item">
                            <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
                            Admin
                        </a>
                        <?php endif; ?>
                        <div class="user-dropdown-sep"></div>
                        <a href="logout.php" class="user-dropdown-item">
                            <svg viewBox="0 0 24 24"><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>
                            Déconnexion
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="user-dropdown-item">
                            <svg viewBox="0 0 24 24"><path d="M11 7L9.6 8.4l2.6 2.6H2v2h10.2l-2.6 2.6L11 17l5-5-5-5zm9 12h-8v2h8c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-8v2h8v14z"/></svg>
                            Connexion
                        </a>
                        <a href="register.php" class="user-dropdown-item">
                            <svg viewBox="0 0 24 24"><path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                            S'inscrire
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</header>


<?php if (!empty($_SESSION['is_admin'])): ?>
<div class="announce-editor-modal" id="announceEditorModal">
    <div class="announce-editor-box">
        <h3>Modifier les annonces</h3>
        <p>Date • Titre (optionnel) • Message</p>
        
        <div id="announceEditorList" style="margin-bottom:20px;">
            <div class="announce-no-items">Chargement des annonces...</div>
        </div>
        
        <button id="addAnnounceItemBtn" style="width:100%;padding:12px 20px;border-radius:10px;background:rgba(102,126,234,.2);border:2px dashed rgba(102,126,234,.5);color:#667eea;cursor:pointer;font-weight:700;font-size:14px;margin-bottom:16px;">+ Ajouter une annonce</button>
        
        <div class="announce-editor-actions">
            <button id="cancelAnnounceBtn" style="padding:10px 20px;border-radius:10px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff;cursor:pointer;font-size:14px;">Annuler</button>
            <button id="saveAnnounceBtn" style="padding:10px 20px;border-radius:10px;background:#bc6a6a;border:none;color:#fff;cursor:pointer;font-weight:700;font-size:14px;">Sauvegarder</button>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="mobile-menu" id="mobileMenu">
    <div class="mobile-search">
        <div class="mobile-search-container">
            <input type="text" class="mobile-search-input" id="searchInputMobile" placeholder="Rechercher..." autocomplete="off">
            <button class="mobile-search-btn" id="searchBtnMobile">
                <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
            </button>
            <div class="search-results" id="searchResultsMobile"></div>
        </div>
    </div>

    <?php if (basename($_SERVER['PHP_SELF']) === 'manga_list.php'): ?>
    <div class="mobile-adult-row" id="mobileAdultRow">
        <svg width="28" height="28" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="16" fill="#c0392b"/>
            <text x="18" y="23" text-anchor="middle" font-size="12" font-weight="900" fill="white" font-family="Arial,sans-serif">18+</text>
            <line x1="5" y1="5" x2="31" y2="31" stroke="white" stroke-width="2.8" stroke-linecap="round"/>
            <circle cx="18" cy="18" r="16" fill="none" stroke="#e74c3c" stroke-width="1.5"/>
        </svg>
        <span class="mobile-adult-label">Contenu adulte</span>
        <label class="adult-toggle" onclick="event.stopPropagation()">
            <input type="checkbox" id="adultToggleMobile">
            <span class="adult-toggle-slider"></span>
        </label>
    </div>
    <?php endif; ?>

    <?php
    $mobileNav = [
        ['index.php','M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z','Accueil'],
        ['profil.php','M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z','Profil'],
        ['manga_list.php','M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z','Séries'],
        ['planning.php','M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z','Planning'],
        ['recrutement.php','M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z','Candidatures'],
        ['informations.php','M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z','Information'],
    ];
    foreach ($mobileNav as [$href, $path, $label]):
    ?>
    <a href="<?= $href ?>" class="mobile-nav-link">
        <svg viewBox="0 0 24 24"><path d="<?= $path ?>"/></svg>
        <span><?= $label ?></span>
    </a>
    <?php endforeach; ?>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="logout.php" class="mobile-nav-link">
            <svg viewBox="0 0 24 24"><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>
            <span>Déconnexion</span>
        </a>
        <?php if (!empty($_SESSION['is_admin'])): ?>
        <a href="admin.php" class="mobile-nav-link">
            <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
            <span>Admin</span>
        </a>
        <?php endif; ?>
    <?php else: ?>
        <a href="login.php" class="mobile-nav-link">
            <svg viewBox="0 0 24 24"><path d="M11 7L9.6 8.4l2.6 2.6H2v2h10.2l-2.6 2.6L11 17l5-5-5-5zm9 12h-8v2h8c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-8v2h8v14z"/></svg>
            <span>Connexion</span>
        </a>
        <a href="register.php" class="mobile-nav-link">
            <svg viewBox="0 0 24 24"><path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
            <span>S'inscrire</span>
        </a>
    <?php endif; ?>
</div>
<div class="mobile-menu-overlay" id="mobileMenuOverlay"></div>

<script>
const burgerMenu = document.getElementById('burgerMenu');
const mobileMenu = document.getElementById('mobileMenu');
const mobileOverlay = document.getElementById('mobileMenuOverlay');

function toggleMenu() {
    burgerMenu.classList.toggle('active');
    mobileMenu.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
    document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
}
burgerMenu.addEventListener('click', toggleMenu);
mobileOverlay.addEventListener('click', toggleMenu);
document.querySelectorAll('.mobile-nav-link').forEach(l => l.addEventListener('click', () => mobileMenu.classList.contains('active') && toggleMenu()));
document.querySelectorAll('img').forEach(img => img.addEventListener('dragstart', e => e.preventDefault()));
document.addEventListener('contextmenu', e => e.preventDefault());

let searchTimeout;
const ADULT = () => localStorage.getItem('yurei_adult_enabled') === '1' ? '1' : '0';

function performSearch(input, results) {
    const q = input.value.trim();
    if (q.length < 2) { results.classList.remove('active'); return; }
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        results.innerHTML = '<div class="search-loading">Recherche...</div>';
        results.classList.add('active');
        fetch(`search.php?q=${encodeURIComponent(q)}&adult=${ADULT()}`)
            .then(r => r.json())
            .then(data => {
                results.innerHTML = data.length === 0
                    ? '<div class="search-no-results">Aucun résultat</div>'
                    : data.map(m => `<a href="manga.php?id=${m.id}" class="search-result-item">
                        <img src="${m.cover_image}" alt="${m.title}" class="search-result-cover" onerror="this.src='https://via.placeholder.com/50x70?text=No+Image'">
                        <div class="search-result-info">
                            <div class="search-result-title">${m.title}</div>
                            <div class="search-result-meta">${m.status||'En cours'} • ${m.chapter_count||0} chapitres</div>
                        </div></a>`).join('');
            })
            .catch(() => { results.innerHTML = '<div class="search-no-results">Erreur de recherche</div>'; });
    }, 300);
}

function goToSearchPage(q) { if (q.trim().length >= 2) window.location.href = `search.php?q=${encodeURIComponent(q.trim())}`; }

function setupSearch(inputId, resultsId, btnId) {
    const input = document.getElementById(inputId), results = document.getElementById(resultsId), btn = document.getElementById(btnId);
    if (!input) return;
    input.addEventListener('input', () => performSearch(input, results));
    btn.addEventListener('click', e => { e.preventDefault(); goToSearchPage(input.value); });
    input.addEventListener('keypress', e => { if (e.key === 'Enter') { e.preventDefault(); goToSearchPage(input.value); } });
}
setupSearch('searchInput', 'searchResults', 'searchBtn');
setupSearch('searchInputMobile', 'searchResultsMobile', 'searchBtnMobile');
document.addEventListener('click', e => {
    if (!e.target.closest('.search-container') && !e.target.closest('.mobile-search-container'))
        document.querySelectorAll('.search-results').forEach(r => r.classList.remove('active'));
});

const LS_KEY = 'yurei_announce_seen_ts';
const announceDiamond    = document.getElementById('announceDiamond');
const announceWrap       = document.getElementById('announceDiamondWrap');
const announceBody       = document.getElementById('announceBody');
const announceDiamondMob = document.getElementById('announceDiamondMobile');
const announceWrapMob    = document.getElementById('announceDiamondWrapMobile');
const announceBodyMob    = document.getElementById('announceBodyMobile');
let cachedAnnounces = null;

function getSeenTs() { return parseInt(localStorage.getItem(LS_KEY) || '0', 10); }
function markAsSeen(data) { if (data?.[0]?.ts) localStorage.setItem(LS_KEY, data[0].ts); }

function checkBadge(data, el) {
    if (!el || !data?.length) return;
    el.classList.toggle('has-news', data[0]?.ts > getSeenTs());
}

function renderAnnounces(data, bodyEl) {
    if (!bodyEl) return;
    bodyEl.innerHTML = (!data || !data.length)
        ? '<div class="announce-empty">Aucune annonce pour le moment.</div>'
        : [...data].reverse().map(a => `<div class="announce-item">
            <div class="announce-item-date">${a.date||''}</div>
            ${a.title ? `<div class="announce-item-title">${a.title}</div>` : ''}
            <div class="announce-item-text">${a.message}</div>
        </div>`).join('');
}

function loadAnnounces(bodyEl, diamondEl) {
    if (!bodyEl) return;
    bodyEl.innerHTML = '<div class="announce-loading">Chargement...</div>';
    if (cachedAnnounces !== null) {
        renderAnnounces(cachedAnnounces, bodyEl);
        markAsSeen(cachedAnnounces);
        [announceDiamond, announceDiamondMob].forEach(el => el?.classList.remove('has-news'));
        return;
    }
    fetch('getters/get_announces.php')
        .then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(data => {
            cachedAnnounces = data;
            renderAnnounces(data, bodyEl);
            markAsSeen(data);
            [announceDiamond, announceDiamondMob].forEach(el => el?.classList.remove('has-news'));
        })
        .catch(err => { bodyEl.innerHTML = `<div class="announce-empty">Erreur: ${err.message}</div>`; });
}

function initBadges() {
    fetch('getters/get_announces.php').then(r => r.json()).then(data => {
        cachedAnnounces = data;
        checkBadge(data, announceDiamond);
        checkBadge(data, announceDiamondMob);
    }).catch(() => {});
}

function toggleAnnounce(wrap, body, diamond, otherWrap) {
    if (!wrap) return;
    wrap.addEventListener('click', function(e) {
        e.stopPropagation();
        const isLoggedIn = <?php echo isset($_SESSION['user_id']) ? 'true' : 'false'; ?>;
        const open = wrap.classList.toggle('open');
        if (open) {
            if (!isLoggedIn) {
                body.innerHTML = `<div class="announce-login-message">
                    <div class="announce-login-message-icon"><svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#bc6a6a" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="2,4 12,13 22,4"/></svg></div>
                    <h3>Connectez-vous pour voir les annonces</h3>
                    <p>Les annonces et mises à jour du site sont réservées aux utilisateurs connectés.</p>
                    <div class="announce-login-actions">
                        <a href="login.php" class="btn-login">Connexion</a>
                        <a href="register.php" class="btn-register">S'inscrire</a>
                    </div>
                </div>`;
            } else {
                loadAnnounces(body, diamond);
            }
        } else {
            otherWrap?.classList.remove('open');
        }
    });
}
toggleAnnounce(announceWrap, announceBody, announceDiamond, announceWrapMob);
toggleAnnounce(announceWrapMob, announceBodyMob, announceDiamondMob, announceWrap);

document.addEventListener('click', e => {
    if (announceWrap && !announceWrap.contains(e.target)) announceWrap.classList.remove('open');
    if (announceWrapMob && !announceWrapMob.contains(e.target)) announceWrapMob.classList.remove('open');
});

if (announceDiamond || announceDiamondMob) {
    const isLoggedIn = <?php echo isset($_SESSION['user_id']) ? 'true' : 'false'; ?>;
    if (isLoggedIn) initBadges();
}

function openAnnounceEditor(e) {
    e.stopPropagation();
    document.getElementById('announceEditorModal').classList.add('open');
    loadAnnouncesList();
}

let announcesEditing = [];

function formatDateForInput(dateStr) {
    if (!dateStr) return new Date().toISOString().split('T')[0];
    const parts = dateStr.split('/');
    if (parts.length === 3) return `${parts[2]}-${parts[1]}-${parts[0]}`;
    return dateStr;
}

function loadAnnouncesList() {
    fetch('getters/get_announces.php').then(r => r.json()).then(announces => {
        announcesEditing = announces.reverse().map(a => ({
            date: formatDateForInput(a.date),
            title: a.title || '',
            message: a.message || ''
        }));
        renderAnnouncesList();
    }).catch(() => {});
}

function renderAnnouncesList() {
    const list = document.getElementById('announceEditorList');
    if (announcesEditing.length === 0) {
        list.innerHTML = '<div class="announce-no-items">Aucune annonce. Cliquez sur "+ Ajouter" pour en créer une.</div>';
        return;
    }
    list.innerHTML = announcesEditing.map((a, i) => `
        <div class="announce-item-edit">
            <div class="announce-item-edit-field">
                <label class="announce-item-edit-label">Date</label>
                <input type="date" class="announce-item-edit-input" value="${a.date}" onchange="announcesEditing[${i}].date = this.value">
            </div>
            <div class="announce-item-edit-field">
                <label class="announce-item-edit-label">Titre (optionnel)</label>
                <input type="text" class="announce-item-edit-input" placeholder="Titre de l'annonce..." value="${a.title}" onchange="announcesEditing[${i}].title = this.value" maxlength="200">
            </div>
            <div class="announce-item-edit-field">
                <label class="announce-item-edit-label">Message</label>
                <textarea class="announce-item-edit-textarea" placeholder="Message de l'annonce..." onchange="announcesEditing[${i}].message = this.value">${a.message}</textarea>
            </div>
            <div class="announce-item-edit-actions">
                <button class="announce-item-delete-btn" onclick="deleteAnnounceItem(${i})">🗑️ Supprimer</button>
            </div>
        </div>
    `).join('');
}

function deleteAnnounceItem(index) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette annonce ?')) {
        announcesEditing.splice(index, 1);
        renderAnnouncesList();
    }
}

document.getElementById('addAnnounceItemBtn')?.addEventListener('click', () => {
    announcesEditing.unshift({
        date: new Date().toISOString().split('T')[0],
        title: '',
        message: ''
    });
    renderAnnouncesList();
});

document.getElementById('saveAnnounceBtn')?.addEventListener('click', () => {
    const content = announcesEditing.map(a => {
        if (!a.date) return '';
        if (a.title && a.message) {
            return `${a.date} | ${a.title} | ${a.message}`;
        } else if (a.message) {
            return `${a.date} | ${a.message}`;
        }
        return '';
    }).filter(l => l.trim()).join('\n');
    
    fetch('setters/save_announces.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ content: content }) })
        .then(r => r.json()).then(d => {
            if (d.success) { 
                cachedAnnounces = null; 
                localStorage.removeItem(LS_KEY); 
                document.getElementById('announceEditorModal').classList.remove('open'); 
                initBadges();
                alert('Annonces sauvegardées avec succès !');
            }
        }).catch(() => alert('Erreur lors de la sauvegarde'));
});

document.getElementById('cancelAnnounceBtn')?.addEventListener('click', () => {
    if (confirm('Êtes-vous sûr ? Les modifications non sauvegardées seront perdues.')) {
        document.getElementById('announceEditorModal').classList.remove('open');
    }
});

const userMenuWrap = document.getElementById('userMenuWrap');
const userAvatarBtn = document.getElementById('userAvatarBtn');
if (userAvatarBtn) {
    userAvatarBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        userMenuWrap.classList.toggle('open');
    });
    document.addEventListener('click', (e) => {
        if (userMenuWrap && !userMenuWrap.contains(e.target)) {
            userMenuWrap.classList.remove('open');
        }
    });
}

const mainHeader = document.getElementById('mainHeader');
let lastY = window.scrollY, ticking = false;
window.addEventListener('scroll', () => {
    if (!ticking) {
        requestAnimationFrame(() => {
            const y = window.scrollY;
            mainHeader.style.cssText = `transform:translateY(${y > lastY && y > 80 ? '-100%' : '0'});transition:transform .3s ease`;
            if (y > lastY && y > 80 && mobileMenu.classList.contains('active')) toggleMenu();
            lastY = y; ticking = false;
        });
        ticking = true;
    }
});
</script>