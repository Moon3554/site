<?php
require_once 'check_captcha.php';
require_once 'db.php';
include 'header.php';
session_start();

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    die("❌ Accès interdit !");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['manga_id'])) {
    die("❌ Requête invalide.");
}

include 'header.php';

$manga_id = (int) $_POST['manga_id'];

try {
    $db->beginTransaction();

    $stmt = $db->prepare("DELETE FROM chapters WHERE manga_id = ?");
    $stmt->execute([$manga_id]);

    $stmt = $db->prepare("DELETE FROM mangas WHERE id = ?");
    $stmt->execute([$manga_id]);

    $db->commit();

    echo "<div style='text-align:center; color:limegreen;'>Manga et chapitres supprimés avec succès. Redirection...</div>";
    header("Refresh: 2; URL=manga_list.php");
    exit();
} catch (PDOException $e) {
    $db->rollBack();
    echo "<div style='text-align:center; color:red;'>Erreur lors de la suppression : " . htmlspecialchars($e->getMessage()) . "</div>";
}
?>
