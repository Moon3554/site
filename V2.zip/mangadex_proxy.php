<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Accès refusé.']);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

function mangadex_get(string $url): ?array {
    $opts = [
        'http' => [
            'method'  => 'GET',
            'timeout' => 15,
            'header'  => implode("\r\n", [
                'User-Agent: YureiScan/1.0 (contact@yurei-scan.fr)',
                'Accept: application/json',
            ]),
            'ignore_errors' => true,
        ],
    ];
    $ctx  = stream_context_create($opts);
    $body = @file_get_contents($url, false, $ctx);

    if ($body === false) return null;

    $data = json_decode($body, true);
    return is_array($data) ? $data : null;
}

function extract_chapter_id(string $input): ?string {
    $input = trim($input);

    if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $input)) {
        return strtolower($input);
    }

    if (preg_match('#mangadex\.org/chapter/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})#i', $input, $m)) {
        return strtolower($m[1]);
    }

    return null;
}

$raw_input = trim($_GET['chapter_url'] ?? $_GET['chapter_id'] ?? '');

if ($raw_input === '') {
    echo json_encode(['success' => false, 'error' => 'Paramètre chapter_url ou chapter_id manquant.']);
    exit();
}

$chapter_id = extract_chapter_id($raw_input);

if (!$chapter_id) {
    echo json_encode(['success' => false, 'error' => 'Impossible d\'extraire un UUID valide depuis : ' . htmlspecialchars($raw_input)]);
    exit();
}

$meta_url  = 'https://api.mangadex.org/chapter/' . $chapter_id . '?includes[]=manga&includes[]=scanlation_group';
$meta      = mangadex_get($meta_url);

if (!$meta || ($meta['result'] ?? '') !== 'ok') {
    $detail = $meta['errors'][0]['detail'] ?? 'Chapitre introuvable ou API indisponible.';
    echo json_encode(['success' => false, 'error' => $detail]);
    exit();
}

$attrs          = $meta['data']['attributes'] ?? [];
$chapter_number = $attrs['chapter']   ?? null;
$chapter_title  = $attrs['title']     ?? null;
$volume         = $attrs['volume']    ?? null;
$lang           = $attrs['translatedLanguage'] ?? 'unknown';

$manga_title = null;
foreach ($meta['data']['relationships'] ?? [] as $rel) {
    if ($rel['type'] === 'manga') {
        $titles      = $rel['attributes']['title'] ?? [];
        $manga_title = $titles['en']
                    ?? $titles['fr']
                    ?? (is_array($titles) && !empty($titles) ? reset($titles) : null)
                    ?? null;
        break;
    }
}

$athome_url  = 'https://api.mangadex.org/at-home/server/' . $chapter_id;
$athome      = mangadex_get($athome_url);

if (!$athome || ($athome['result'] ?? '') !== 'ok') {
    echo json_encode(['success' => false, 'error' => 'Impossible de récupérer le serveur de pages MangaDex (at-home).']);
    exit();
}

$base_url    = rtrim($athome['baseUrl'], '/');
$chapter_obj = $athome['chapter'] ?? [];
$hash        = $chapter_obj['hash']        ?? '';
$data_files  = $chapter_obj['data']        ?? [];
$data_saver  = $chapter_obj['dataSaver']   ?? [];

$files = !empty($data_files) ? $data_files : $data_saver;
$quality_path = !empty($data_files) ? 'data' : 'data-saver';

if (empty($files) || empty($hash)) {
    echo json_encode(['success' => false, 'error' => 'Aucune page trouvée pour ce chapitre.']);
    exit();
}

$proto    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$site_dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$proxy_base = $proto . '://' . $_SERVER['HTTP_HOST'] . $site_dir . '/mangadex_image_proxy.php';

$pages = [];
foreach ($files as $filename) {
    $real_url = "{$base_url}/{$quality_path}/{$hash}/{$filename}";
    $encoded  = rtrim(strtr(base64_encode($real_url), '+/', '-_'), '=');
    $pages[] = $proxy_base . '?u=' . $encoded;
}

echo json_encode([
    'success'      => true,
    'chapter_id'   => $chapter_id,
    'chapter_info' => [
        'number'     => $chapter_number,
        'title'      => $chapter_title,
        'volume'     => $volume,
        'lang'       => $lang,
        'manga'      => $manga_title,
        'page_count' => count($pages),
    ],
    'pages' => $pages,
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);