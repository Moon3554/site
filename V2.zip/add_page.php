<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: index.php');
    exit();
}

$manga_id   = isset($_GET['manga_id'])   ? (int)$_GET['manga_id']   : 0;
$chapter_id = isset($_GET['chapter_id']) ? (int)$_GET['chapter_id'] : 0;
$error_msg  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $page_url   = isset($_POST['page_url'])   ? trim($_POST['page_url'])   : '';
    $manga_id   = isset($_POST['manga_id'])   ? (int)$_POST['manga_id']   : 0;
    $chapter_id = isset($_POST['chapter_id']) ? (int)$_POST['chapter_id'] : 0;

    if (empty($page_url)) {
        $error_msg = "L'URL de la page est obligatoire.";
    } elseif (!filter_var($page_url, FILTER_VALIDATE_URL)) {
        $error_msg = "L'URL fournie est invalide.";
    } elseif ($chapter_id > 0) {
        try {
            $stmt = $db->prepare("INSERT INTO chapter_pages (chapter_id, page_url) VALUES (?, ?)");
            $stmt->execute([$chapter_id, $page_url]);

            header("Location: chapter.php?id=$manga_id&chapter_id=$chapter_id");
            exit();
        } catch (PDOException $e) {
            $error_msg = "Erreur BDD : " . htmlspecialchars($e->getMessage());
        }
    }
}
?> 

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter une page</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #111; color: #fff; padding: 20px; }
        .form-container { max-width: 400px; margin: 50px auto; background: #222; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.4); }
        h2 { text-align: center; color: #fff; }
        .error { color: #ff6b6b; background: rgba(231,76,60,0.15); border: 1px solid rgba(231,76,60,0.4); padding: 10px; border-radius: 5px; margin-bottom: 10px; font-size: 14px; }
        input, button { width: 100%; padding: 10px; margin: 10px 0; background: #333; border: 1px solid #444; color: #fff; border-radius: 5px; }
        button { background: #28a745; cursor: pointer; font-weight: bold; }
        button:hover { background: #1e7e34; }
        a.back-btn { display: block; text-align: center; background: #007bff; color: #fff; padding: 8px 12px; border-radius: 5px; text-decoration: none; margin-top: 10px; }
        a.back-btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Ajouter une page au chapitre</h2>

        <?php if (!empty($error_msg)): ?>
            <div class="error"><?php echo $error_msg; ?></div>
        <?php endif; ?>

        <form method="post" action="">
            <input type="hidden" name="manga_id"   value="<?php echo htmlspecialchars($manga_id); ?>">
            <input type="hidden" name="chapter_id" value="<?php echo htmlspecialchars($chapter_id); ?>">

            <label for="page_url">Lien de la page :</label>
            <input type="url" id="page_url" name="page_url"
                   placeholder="Ex : https://i.imgur.com/YYY.jpg"
                   required>

            <button type="submit">Ajouter la page</button>
        </form>

        <a href="chapter.php?id=<?php echo htmlspecialchars($manga_id); ?>&chapter_id=<?php echo htmlspecialchars($chapter_id); ?>" class="back-btn">← Retour au chapitre</a>
    </div>
</body>
</html>
