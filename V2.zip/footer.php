<footer>
  <p style="text-align:center;">&copy; <?php echo date("Y"); ?> Yurei Scan. Tous droits réservés.</p>
</footer>

<style>
footer {
    padding-bottom: 20px;
}
</style>