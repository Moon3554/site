<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'check_captcha.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://i.ibb.co/LdCC28Wk/logo-site.png">
    <title>Recrutement - Équipe Yurei</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .content { max-width: 1000px; margin: 0 auto; padding: 50px 20px; }
        .page-title { text-align: center; font-size: 48px; margin-bottom: 25px; font-weight: 700; color: #bc6a6a; letter-spacing: 2px; text-transform: uppercase; position: relative; padding-bottom: 20px; }
        .page-title::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 120px; height: 4px; background: #bc6a6a; border-radius: 2px; }
        .intro-section { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 35px; margin-bottom: 40px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 32px rgba(0,0,0,0.4); text-align: center; }
        .intro-section p { font-size: 17px; line-height: 1.8; color: #e0e0e0; margin: 0; }
        .roles-section { margin-bottom: 40px; }
        .section-title { font-size: 32px; color: #fff; margin-bottom: 30px; font-weight: 600; text-align: center; position: relative; padding-bottom: 15px; }
        .section-title::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 80px; height: 3px; background: #bc6a6a; border-radius: 2px; }
        .roles-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 25px; }
        .role-card { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 15px; padding: 30px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 32px rgba(0,0,0,0.4); transition: all 0.3s ease; position: relative; overflow: hidden; }
        .role-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #bc6a6a; transform: scaleX(0); transition: transform 0.3s ease; }
        .role-card:hover { transform: translateY(-5px); box-shadow: 0 12px 48px rgba(188,106,106,0.3); border-color: rgba(255,255,255,0.2); }
        .role-card:hover::before { transform: scaleX(1); }
        .role-title { font-size: 22px; color: #bc6a6a; margin-bottom: 15px; font-weight: 600; }
        .role-description { font-size: 15px; color: #ccc; line-height: 1.8; margin-bottom: 15px; }
        .role-requirements { font-size: 14px; color: #bbb; line-height: 1.7; padding-left: 20px; border-left: 3px solid rgba(255,255,255,0.55); }
        .welcome-note { background: rgba(188,106,106,0.1); backdrop-filter: blur(10px); border-radius: 15px; padding: 30px; margin-bottom: 30px; border: 1px solid rgba(188,106,106,0.3); box-shadow: 0 8px 32px rgba(0,0,0,0.4); border-left: 4px solid #bc6a6a; }
        .welcome-note p { font-size: 16px; line-height: 1.8; color: #e0e0e0; margin: 0; }
        @media (max-width: 968px) { .roles-grid { grid-template-columns: 1fr; } .page-title { font-size: 40px; } }
        @media (max-width: 768px) { .content { padding: 40px 15px; } .page-title { font-size: 36px; } .role-card { padding: 25px; } }
        @media (max-width: 480px) { .content { padding: 30px 10px; } .page-title { font-size: 30px; } .role-card { padding: 20px; } }
    </style>
</head>
<?php include 'header.php'; ?>
<body>

    <div class="content">
        <h1 class="page-title">Nous Rejoindre</h1>

        <div class="intro-section">
            <p>Vous souhaitez rejoindre la Yurei Scan et contribuer à ses projets ? Avant de postuler, veuillez lire attentivement les conditions ci-dessous. Nous sommes à la recherche de personnes motivées et sérieuses pour les postes suivants :</p>
        </div>

        <div class="roles-section">
            <h2 class="section-title">Les différents rôles :</h2>

            <div class="roles-grid">
                <div class="role-card">
                    <h3 class="role-title">Cleaner</h3>
                    <p class="role-description">Efface les textes des planches anglaises pour préparer la mise en page.</p>
                    <div class="role-requirements">Un ordinateur est indispensable et une bonne maîtrise de Photoshop est exigée.</div>
                </div>
                <div class="role-card">
                    <h3 class="role-title">Éditeur</h3>
                    <p class="role-description">Remet en place les textes traduits dans les bulles.</p>
                    <div class="role-requirements">Ce rôle nécessite de la précision, de la motivation et un PC avec Photoshop.</div>
                </div>
                <div class="role-card">
                    <h3 class="role-title">Traducteur</h3>
                    <p class="role-description">Traduit les dialogues de l'anglais vers le français.</p>
                    <div class="role-requirements">Une excellente maîtrise de l'anglais est demandée. Les sites de traduction ne sont pas acceptés.</div>
                </div>
                <div class="role-card">
                    <h3 class="role-title">Checkeur</h3>
                    <p class="role-description">Relit les chapitres pour corriger les fautes et incohérences.</p>
                    <div class="role-requirements">Une excellente maîtrise de la langue française est obligatoire. L'utilisation de correcteurs orthographiques et de dictionnaires est fortement recommandée.</div>
                </div>
            </div>
        </div>

        <div class="welcome-note">
            <p>Nous recherchons tous types de profils, et tous les logiciels demandés vous seront fournis une fois votre ticket créé sur le serveur Discord. Si vous souhaitez simplement lire, discuter et suivre nos sorties sans intégrer l'équipe, vous êtes également le bienvenu ! L'équipe Yurei Scan.</p>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>