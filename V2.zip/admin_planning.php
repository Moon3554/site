<?php
require_once 'check_captcha.php';
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: login.php');
    exit();
}

include 'header.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'ajouter':
                    $manga_id = $_POST['manga_id'];
                    $chapter_number = $_POST['chapter_number'];
                    $jour_semaine = $_POST['jour_semaine'];
                    $heure_sortie = !empty($_POST['heure_sortie']) ? $_POST['heure_sortie'] : null;
                    $date_prevue = $_POST['date_prevue'];
                    $notes = $_POST['notes'] ?? '';
                    $ordre = $_POST['ordre_affichage'] ?? 0;
                    $hebdomadaire = isset($_POST['hebdomadaire']) && $_POST['hebdomadaire'] === '1';
                    $bi_hebdomadaire = isset($_POST['bi_hebdomadaire']) && $_POST['bi_hebdomadaire'] === '1';
                    
                    $nb_sorties = 1;
                    $intervalle_jours = 7;
                    if ($hebdomadaire) {
                        $nb_sorties = (int)($_POST['nb_semaines'] ?? 4);
                        $intervalle_jours = 7;
                    } elseif ($bi_hebdomadaire) {
                        $nb_sorties = (int)($_POST['nb_periodes'] ?? 4);
                        $intervalle_jours = 14;
                    }
                    
                    for ($i = 0; $i < $nb_sorties; $i++) {
                        $date_calcule = date('Y-m-d', strtotime($date_prevue . " + " . ($i * $intervalle_jours) . " days"));
                        $chapitre_calcule = $chapter_number;
                        
                        if ($i > 0) {
                            if (is_numeric($chapter_number)) {
                                $chapitre_calcule = (float)$chapter_number + $i;
                                if (floor($chapitre_calcule) == $chapitre_calcule) {
                                    $chapitre_calcule = (int)$chapitre_calcule;
                                }
                            } else {
                                $chapitre_calcule = $chapter_number . " +" . $i;
                            }
                        }
                        
                        $stmt = $db->prepare("
                            INSERT INTO planning_sorties (manga_id, chapter_number, jour_semaine, heure_sortie, date_prevue, notes, ordre_affichage, statut)
                            VALUES (:manga_id, :chapter_number, :jour_semaine, :heure_sortie, :date_prevue, :notes, :ordre, 'prevu')
                        ");
                        $stmt->execute([
                            ':manga_id' => $manga_id,
                            ':chapter_number' => $chapitre_calcule,
                            ':jour_semaine' => $jour_semaine,
                            ':heure_sortie' => $heure_sortie,
                            ':date_prevue' => $date_calcule,
                            ':notes' => $notes,
                            ':ordre' => $ordre
                        ]);
                    }
                    
                    if ($hebdomadaire) {
                        $message = "Sortie hebdomadaire ajoutée avec succès ! $nb_sorties chapitres créés.";
                    } elseif ($bi_hebdomadaire) {
                        $message = "Sortie bi-hebdomadaire ajoutée avec succès ! $nb_sorties chapitres créés.";
                    } else {
                        $message = "Sortie ajoutée au planning avec succès !";
                    }
                    break;

                case 'modifier':
                    $stmt = $db->prepare("
                        UPDATE planning_sorties 
                        SET manga_id = :manga_id, 
                            chapter_number = :chapter_number, 
                            jour_semaine = :jour_semaine,
                            heure_sortie = :heure_sortie,
                            date_prevue = :date_prevue,
                            statut = :statut,
                            notes = :notes,
                            ordre_affichage = :ordre
                        WHERE id = :id
                    ");
                    $stmt->execute([
                        ':id' => $_POST['planning_id'],
                        ':manga_id' => $_POST['manga_id'],
                        ':chapter_number' => $_POST['chapter_number'],
                        ':jour_semaine' => $_POST['jour_semaine'],
                        ':heure_sortie' => $_POST['heure_sortie'],
                        ':date_prevue' => $_POST['date_prevue'],
                        ':statut' => $_POST['statut'],
                        ':notes' => $_POST['notes'] ?? '',
                        ':ordre' => $_POST['ordre_affichage'] ?? 0
                    ]);
                    $message = "Sortie modifiée avec succès !";
                    break;

                case 'supprimer':
                    $stmt = $db->prepare("DELETE FROM planning_sorties WHERE id = :id");
                    $stmt->execute([':id' => $_POST['planning_id']]);
                    $message = "Sortie supprimée du planning !";
                    break;

                case 'tout_nettoyer':
                    $stmt = $db->query("DELETE FROM planning_sorties");
                    $nb = $stmt->rowCount();
                    $message = "Planning entièrement nettoyé ! ($nb entrée(s) supprimée(s))";
                    break;

                case 'decaler':
                    $stmt = $db->prepare("
                        UPDATE planning_sorties 
                        SET date_prevue = DATE_ADD(date_prevue, INTERVAL :jours DAY),
                            jour_semaine = CASE DAYOFWEEK(DATE_ADD(date_prevue, INTERVAL :jours DAY))
                                WHEN 1 THEN 'Dimanche'
                                WHEN 2 THEN 'Lundi'
                                WHEN 3 THEN 'Mardi'
                                WHEN 4 THEN 'Mercredi'
                                WHEN 5 THEN 'Jeudi'
                                WHEN 6 THEN 'Vendredi'
                                WHEN 7 THEN 'Samedi'
                            END,
                            statut = 'reporte'
                        WHERE id = :id
                    ");
                    $stmt->execute([
                        ':id' => $_POST['planning_id'],
                        ':jours' => $_POST['jours_decalage']
                    ]);
                    $message = "Sortie décalée de {$_POST['jours_decalage']} jour(s) !";
                    break;
            }
        }
    } catch (PDOException $e) {
        $error = "Erreur : " . $e->getMessage();
    }
}

$mangas = $db->query("SELECT id, title FROM mangas ORDER BY title ASC")->fetchAll(PDO::FETCH_ASSOC);

$db->exec("
    DELETE FROM planning_sorties
    WHERE date_prevue >= DATE_SUB(CURDATE(), INTERVAL DAYOFWEEK(CURDATE()) + 5 DAY)
      AND date_prevue <  DATE_SUB(CURDATE(), INTERVAL DAYOFWEEK(CURDATE()) - 2 DAY)
      AND DAYOFWEEK(CURDATE()) = 2
");

$planning = $db->query("
    SELECT p.*, m.title as manga_title, m.image_url
    FROM planning_sorties p
    JOIN mangas m ON p.manga_id = m.id
    WHERE p.date_prevue >= DATE_SUB(CURDATE(), INTERVAL DAYOFWEEK(CURDATE()) - 2 DAY)
    ORDER BY p.date_prevue ASC, p.ordre_affichage ASC
")->fetchAll(PDO::FETCH_ASSOC);


$planning_par_jour = [
    'Lundi' => [],
    'Mardi' => [],
    'Mercredi' => [],
    'Jeudi' => [],
    'Vendredi' => [],
    'Samedi' => [],
    'Dimanche' => []
];

foreach ($planning as $sortie) {
    $planning_par_jour[$sortie['jour_semaine']][] = $sortie;
}

$jours_semaine = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Planning - Admin Yurei Scan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #000;
            color: #fff;
            line-height: 1.6;
            min-height: 100vh;
            padding-bottom: 50px;
        }

        .admin-container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .page-header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px 20px;
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .page-header h1 {
            font-size: 36px;
            color: #bc6a6a;
            margin-bottom: 10px;
        }

        .message {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            animation: slideIn 0.3s ease;
        }

        .message.success {
            background: rgba(46,204,113,0.15);
            border: 1px solid rgba(46,204,113,0.3);
            color: #2ecc71;
        }

        .message.error {
            background: rgba(231,76,60,0.15);
            border: 1px solid rgba(231,76,60,0.3);
            color: #e74c3c;
        }

        .add-section {
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 40px;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .add-section h2 {
            font-size: 24px;
            margin-bottom: 25px;
            color: #bc6a6a;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group label {
            font-size: 14px;
            font-weight: 600;
            color: #ccc;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 12px 16px;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 10px;
            color: #fff;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .form-group select option {
            background: #1a1a2e;
            color: #fff;
            padding: 10px;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            background: rgba(255,255,255,0.12);
            border-color: #bc6a6a;
            box-shadow: 0 0 0 3px rgba(188,106,106,0.15);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
            font-family: inherit;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: #bc6a6a;
            color: #fff;
            box-shadow: 0 4px 15px rgba(188,106,106,0.4);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(188,106,106,0.6);
        }

        .btn-danger {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(231,76,60,0.4);
        }

        .btn-warning {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: #fff;
            box-shadow: 0 4px 15px rgba(243,156,18,0.4);
        }

        .btn-small {
            padding: 8px 16px;
            font-size: 13px;
        }

        .planning-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 24px;
            margin-top: 30px;
        }

        .day-card {
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
        }

        .day-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 48px rgba(188,106,106,0.2);
            border-color: rgba(255,255,255,0.2);
        }

        .day-header {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid rgba(188,106,106,0.3);
            color: #bc6a6a;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sortie-card {
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 12px;
            transition: all 0.3s ease;
        }

        .sortie-card:hover {
            background: rgba(255,255,255,0.1);
            border-color: rgba(188,106,106,0.4);
        }

        .sortie-card.compact {
            padding: 10px 12px;
            margin-bottom: 8px;
        }

        .sortie-card.compact .sortie-header {
            margin-bottom: 6px;
        }

        .sortie-card.compact .sortie-thumb {
            width: 40px;
            height: 52px;
        }

        .sortie-card.compact .sortie-title {
            font-size: 14px;
        }

        .sortie-card.compact .sortie-chapter {
            font-size: 12px;
        }

        .sortie-card.compact .sortie-meta {
            font-size: 11px;
            gap: 8px;
            margin: 6px 0;
        }

        .sortie-card.compact .sortie-actions {
            margin-top: 8px;
        }

        .sortie-card.compact .btn-small {
            padding: 6px 12px;
            font-size: 11px;
        }

        .sortie-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 10px;
        }

        .sortie-thumb {
            width: 50px;
            height: 65px;
            border-radius: 8px;
            object-fit: cover;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .sortie-info {
            flex: 1;
        }

        .sortie-title {
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 4px;
        }

        .sortie-chapter {
            font-size: 14px;
            color: #999;
        }

        .sortie-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 10px 0;
            font-size: 13px;
        }

        .sortie-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-prevu {
            background: rgba(52,152,219,0.15);
            color: #3498db;
            border: 1px solid rgba(52,152,219,0.3);
        }

        .badge-en-cours {
            background: rgba(243,156,18,0.15);
            color: #f39c12;
            border: 1px solid rgba(243,156,18,0.3);
        }

        .badge-sorti {
            background: rgba(46,204,113,0.15);
            color: #2ecc71;
            border: 1px solid rgba(46,204,113,0.3);
        }

        .badge-reporte {
            background: rgba(231,76,60,0.15);
            color: #e74c3c;
            border: 1px solid rgba(231,76,60,0.3);
        }

        .sortie-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 12px;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(5px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 20px;
            padding: 30px;
            max-width: 600px;
            width: 100%;
            border: 1px solid rgba(255,255,255,0.1);
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            font-size: 24px;
            margin-bottom: 25px;
            color: #bc6a6a;
        }

        .modal-close {
            float: right;
            font-size: 28px;
            cursor: pointer;
            color: #999;
            transition: color 0.3s ease;
        }

        .modal-close:hover {
            color: #fff;
        }

        .empty-day {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 768px) {
            .planning-grid {
                grid-template-columns: 1fr;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .page-header h1 {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="page-header">
            <h1>Gestion du Planning de Sorties</h1>
            <form method="POST" style="margin-top: 16px;" onsubmit="return confirm('Supprimer TOUS le planning ? Cette action est irréversible.');">
                <input type="hidden" name="action" value="tout_nettoyer">
                <button type="submit" class="btn btn-danger" style="margin: 0 auto;">
                    Tout nettoyer
                </button>
            </form>
        </div>

        <?php if ($message): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="add-section">
            <h2>Ajouter une sortie au planning</h2>
            <form method="POST">
                <input type="hidden" name="action" value="ajouter">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Manga</label>
                        <select name="manga_id" id="manga_id" required onchange="updateChapterNumber()">
                            <option value="">Sélectionner un manga...</option>
                            <?php foreach ($mangas as $manga): ?>
                                <option value="<?php echo $manga['id']; ?>">
                                    <?php echo htmlspecialchars($manga['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Chapitre</label>
                        <input type="text" id="chapter_number" name="chapter_number" placeholder="Ex: 42" required>
                    </div>

                    <div class="form-group">
                        <label>Jour de la semaine</label>
                        <select id="jour_semaine" name="jour_semaine" required onchange="updateDateFromDay()">
                            <?php foreach ($jours_semaine as $jour): ?>
                                <option value="<?php echo $jour; ?>"><?php echo $jour; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Date prévue</label>
                        <input type="date" id="date_prevue" name="date_prevue" required>
                    </div>

                    <div class="form-group">
                        <label>Ordre d'affichage</label>
                        <input type="number" name="ordre_affichage" value="0" min="0">
                    </div>
                </div>

                <div class="form-group">
                    <label>Notes (optionnel)</label>
                    <textarea name="notes" placeholder="Notes internes, raisons d'un report..."></textarea>
                </div>

                <div style="background: rgba(188,106,106,0.08); padding: 20px; border-radius: 12px; border: 1px solid rgba(188,106,106,0.2); margin-bottom: 20px;">
                    <div style="margin-bottom: 20px;">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                            <input type="checkbox" id="hebdomadaire" name="hebdomadaire" value="1" onchange="toggleRecurrence()" style="width: auto; cursor: pointer;">
                            <span style="color: #bc6a6a; font-weight: 700; font-size: 16px;">Sortie hebdomadaire récurrente</span>
                        </label>
                        <small style="color: #999; display: block; margin-top: 8px; margin-left: 26px;">
                            Créer automatiquement plusieurs sorties chaque semaine
                        </small>
                        
                        <div id="hebdo_options" style="display: none; margin-top: 12px; padding: 12px; border-left: 3px solid #bc6a6a; background: rgba(188,106,106,0.05); border-radius: 6px;">
                            <label for="nb_semaines" style="font-size: 13px; color: #ccc; display: block; margin-bottom: 8px;">Nombre de semaines</label>
                            <input type="number" id="nb_semaines" name="nb_semaines" value="4" min="2" max="52" style="width: 150px; padding: 10px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #fff;">
                            <small style="color: #999; display: block; margin-top: 8px;">
                                Ex: 4 semaines = Ch. 10, 11, 12, 13 (jours identiques)
                            </small>
                        </div>
                    </div>

                    <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 20px;">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                            <input type="checkbox" id="bi_hebdomadaire" name="bi_hebdomadaire" value="1" onchange="toggleRecurrence()" style="width: auto; cursor: pointer;">
                            <span style="color: #a85c5c; font-weight: 700; font-size: 16px;">Sortie une semaine sur deux</span>
                        </label>
                        <small style="color: #999; display: block; margin-top: 8px; margin-left: 26px;">
                            Créer automatiquement plusieurs sorties tous les deux semaines
                        </small>
                        
                        <div id="bi_hebdo_options" style="display: none; margin-top: 12px; padding: 12px; border-left: 3px solid #a85c5c; background: rgba(168,92,92,0.05); border-radius: 6px;">
                            <label for="nb_periodes" style="font-size: 13px; color: #ccc; display: block; margin-bottom: 8px;">Nombre de périodes (2 semaines)</label>
                            <input type="number" id="nb_periodes" name="nb_periodes" value="4" min="2" max="26" style="width: 150px; padding: 10px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #fff;">
                            <small style="color: #999; display: block; margin-top: 8px;">
                                Ex: 4 périodes = Ch. 10, 11, 12, 13 (tous les 14 jours)
                            </small>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Ajouter au planning</button>
            </form>
        </div>

        <div class="planning-grid">
            <?php foreach ($jours_semaine as $jour): ?>
                <div class="day-card">
                    <div class="day-header"><?php echo $jour; ?></div>

                    <?php if (empty($planning_par_jour[$jour])): ?>
                        <div class="empty-day">Aucune sortie prévue</div>
                    <?php else: ?>
                        <?php 
                        $sorties = $planning_par_jour[$jour];
                        $prev_manga_id = null;
                        
                        foreach ($sorties as $index => $sortie): 
                            $is_compact = ($prev_manga_id === $sortie['manga_id']);
                            $prev_manga_id = $sortie['manga_id'];
                        ?>
                            <div class="sortie-card <?php echo $is_compact ? 'compact' : ''; ?>">
                                <div class="sortie-header">
                                    <?php if (!$is_compact && $sortie['image_url']): ?>
                                        <img src="<?php echo htmlspecialchars($sortie['image_url']); ?>" 
                                             alt="<?php echo htmlspecialchars($sortie['manga_title']); ?>" 
                                             class="sortie-thumb">
                                    <?php endif; ?>
                                    <div class="sortie-info">
                                        <?php if (!$is_compact): ?>
                                            <div class="sortie-title"><?php echo htmlspecialchars($sortie['manga_title']); ?></div>
                                        <?php endif; ?>
                                        <div class="sortie-chapter">Ch. <?php echo htmlspecialchars($sortie['chapter_number']); ?></div>
                                    </div>
                                </div>

                                <div class="sortie-meta">
                                    <span class="sortie-badge badge-<?php echo $sortie['statut']; ?>">
                                        <?php echo strtoupper(str_replace('_', ' ', $sortie['statut'])); ?>
                                    </span>
                                    <span><?php echo date('d/m/Y', strtotime($sortie['date_prevue'])); ?></span>
                                </div>

                                <?php if ($sortie['notes'] && !$is_compact): ?>
                                    <div style="margin-top: 10px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 8px; font-size: 13px; color: #999;">
                                        <?php echo htmlspecialchars($sortie['notes']); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="sortie-actions">
                                    <button class="btn btn-warning btn-small" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($sortie)); ?>)">
                                        Modifier
                                    </button>
                                    <button class="btn btn-warning btn-small" onclick="openDecalageModal(<?php echo $sortie['id']; ?>, '<?php echo htmlspecialchars($sortie['manga_title']); ?>')">
                                        Décaler
                                    </button>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Supprimer cette sortie du planning ?');">
                                        <input type="hidden" name="action" value="supprimer">
                                        <input type="hidden" name="planning_id" value="<?php echo $sortie['id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-small">Supprimer</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="modal-close" onclick="closeEditModal()">&times;</span>
            <h2 class="modal-header">Modifier la sortie</h2>
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="modifier">
                <input type="hidden" name="planning_id" id="edit_id">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Manga</label>
                        <select name="manga_id" id="edit_manga_id" required>
                            <?php foreach ($mangas as $manga): ?>
                                <option value="<?php echo $manga['id']; ?>">
                                    <?php echo htmlspecialchars($manga['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Chapitre</label>
                        <input type="text" name="chapter_number" id="edit_chapter_number" required>
                    </div>

                    <div class="form-group">
                        <label>Jour de la semaine</label>
                        <select name="jour_semaine" id="edit_jour_semaine" required>
                            <?php foreach ($jours_semaine as $jour): ?>
                                <option value="<?php echo $jour; ?>"><?php echo $jour; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Date prévue</label>
                        <input type="date" name="date_prevue" id="edit_date_prevue" required>
                    </div>

                    <div class="form-group">
                        <label>Statut</label>
                        <select name="statut" id="edit_statut" required>
                            <option value="prevu">Prévu</option>
                            <option value="en_cours">En cours</option>
                            <option value="sorti">Sorti</option>
                            <option value="reporte">Reporté</option>
                            <option value="annule">Annulé</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Ordre</label>
                        <input type="number" name="ordre_affichage" id="edit_ordre" min="0">
                    </div>
                </div>

                <div class="form-group">
                    <label>Notes</label>
                    <textarea name="notes" id="edit_notes"></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Sauvegarder</button>
            </form>
        </div>
    </div>

    <div id="decalageModal" class="modal">
        <div class="modal-content">
            <span class="modal-close" onclick="closeDecalageModal()">&times;</span>
            <h2 class="modal-header">Décaler la sortie</h2>
            <p id="decalage_manga" style="margin-bottom: 20px; color: #ccc;"></p>
            <form method="POST" id="decalageForm">
                <input type="hidden" name="action" value="decaler">
                <input type="hidden" name="planning_id" id="decalage_id">
                
                <div class="form-group">
                    <label>Décalage en jours</label>
                    <input type="number" name="jours_decalage" min="1" max="365" value="7" required>
                    <small style="color: #999;">Nombre de jours à ajouter (ex: 7 pour une semaine)</small>
                </div>

                <button type="submit" class="btn btn-warning">⏱️ Décaler</button>
            </form>
        </div>
    </div>

    <script>
        const joursMap = {
            'Lundi': 1,
            'Mardi': 2,
            'Mercredi': 3,
            'Jeudi': 4,
            'Vendredi': 5,
            'Samedi': 6,
            'Dimanche': 0
        };

        function updateDateFromDay() {
            const joursSelect = document.getElementById('jour_semaine');
            const dateInput = document.getElementById('date_prevue');
            
            if (!joursSelect.value) return;
            
            const jourSelectionne = joursSelect.value;
            const targetDay = joursMap[jourSelectionne];
            
            const today = new Date();
            const todayDay = today.getDay();
            
            let daysToAdd = targetDay - todayDay;
            
            if (daysToAdd <= 0) {
                daysToAdd += 7;
            }
            
            const targetDate = new Date(today);
            targetDate.setDate(targetDate.getDate() + daysToAdd);
            
            const year = targetDate.getFullYear();
            const month = String(targetDate.getMonth() + 1).padStart(2, '0');
            const day = String(targetDate.getDate()).padStart(2, '0');
            
            dateInput.value = `${year}-${month}-${day}`;
        }

        function updateChapterNumber() {
            const mangaSelect = document.getElementById('manga_id');
            const chapterInput = document.getElementById('chapter_number');
            
            if (!mangaSelect.value) {
                chapterInput.value = '';
                return;
            }
            
            fetch('getters/get_last_chapter.php?manga_id=' + mangaSelect.value)
                .then(response => response.json())
                .then(data => {
                    if (data.lastChapter !== null) {
                        const lastChapter = parseFloat(data.lastChapter);
                        const nextChapter = lastChapter + 1;
                        
                        if (Number.isInteger(nextChapter)) {
                            chapterInput.value = nextChapter.toString();
                        } else {
                            chapterInput.value = nextChapter.toFixed(1);
                        }
                    } else {
                        chapterInput.value = '1';
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    chapterInput.value = '1';
                });
        }

        function openEditModal(sortie) {
            document.getElementById('edit_id').value = sortie.id;
            document.getElementById('edit_manga_id').value = sortie.manga_id;
            document.getElementById('edit_chapter_number').value = sortie.chapter_number;
            document.getElementById('edit_jour_semaine').value = sortie.jour_semaine;
            document.getElementById('edit_date_prevue').value = sortie.date_prevue;
            document.getElementById('edit_statut').value = sortie.statut;
            document.getElementById('edit_notes').value = sortie.notes || '';
            document.getElementById('edit_ordre').value = sortie.ordre_affichage;
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        function openDecalageModal(id, mangaTitle) {
            document.getElementById('decalage_id').value = id;
            document.getElementById('decalage_manga').textContent = 'Manga : ' + mangaTitle;
            document.getElementById('decalageModal').classList.add('active');
        }

        function closeDecalageModal() {
            document.getElementById('decalageModal').classList.remove('active');
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }

        function toggleRecurrence() {
            const hebdo = document.getElementById('hebdomadaire');
            const biHebdo = document.getElementById('bi_hebdomadaire');
            const hebdoOptions = document.getElementById('hebdo_options');
            const biHebdoOptions = document.getElementById('bi_hebdo_options');
            
            if (hebdo.checked && biHebdo.checked) {
                biHebdo.checked = false;
            }
            if (biHebdo.checked && hebdo.checked) {
                hebdo.checked = false;
            }
            
            hebdoOptions.style.display = hebdo.checked ? 'block' : 'none';
            biHebdoOptions.style.display = biHebdo.checked ? 'block' : 'none';
        }
    </script>

    <?php include 'footer.php'; ?>
</body>
</html>