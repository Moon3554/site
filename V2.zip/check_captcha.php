<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bots autorisés à bypasser le captcha (réseaux sociaux, moteurs de recherche)
$bot_agents = [
    'facebookexternalhit', 'Facebot',
    'Twitterbot',
    'discordbot',
    'WhatsApp',
    'LinkedInBot',
    'Slackbot',
    'TelegramBot',
    'Googlebot', 'Googlebot-Image',
    'bingbot',
    'Applebot',
    'Pinterest',
    'redditbot',
    'Iframely', 'iframely',
    'vkShare',
    'Embedly',
    'ia_archiver',
];

$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
foreach ($bot_agents as $bot) {
    if (stripos($ua, $bot) !== false) {
        return;
    }
}

if (empty($_SESSION['captcha_ok'])) {
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
        . '://' . ($_SERVER['HTTP_HOST'] ?? 'yurei-scan.fr')
        . ($_SERVER['REQUEST_URI'] ?? '/');
    $_SESSION['captcha_redirect'] = $current_url;

    header('Location: /captcha_secure.php');
    exit();
}