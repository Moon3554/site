<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'db.php';

header('Content-Type: application/json');

if (empty($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Connexion requise pour noter.']);
    exit;
}

$data     = json_decode(file_get_contents('php://input'), true);
$manga_id = isset($data['manga_id']) ? (int)$data['manga_id'] : 0;
$rating   = isset($data['rating'])   ? (int)$data['rating']   : 0;
$user_id  = (int)$_SESSION['user_id'];

if ($manga_id <= 0 || $rating < 1 || $rating > 5) {
    echo json_encode(['success' => false, 'message' => 'Données invalides.']);
    exit;
}

try {
    $stmt = $db->prepare("
        INSERT INTO manga_ratings (manga_id, user_id, rating)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE rating = VALUES(rating), updated_at = NOW()
    ");
    $stmt->execute([$manga_id, $user_id, $rating]);

    $stmt = $db->prepare("
        SELECT ROUND(AVG(rating), 1) as avg_rating, COUNT(*) as vote_count
        FROM manga_ratings
        WHERE manga_id = ?
    ");
    $stmt->execute([$manga_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'success'    => true,
        'avg_rating' => (float)$stats['avg_rating'],
        'vote_count' => (int)$stats['vote_count'],
        'user_rating'=> $rating,
    ]);
} catch (PDOException $e) {
    error_log("rate_manga : " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erreur serveur.']);
}