<?php
require_once 'check_captcha.php';
session_start();
require_once 'db.php';
include 'header.php';

date_default_timezone_set('Europe/Paris');

$week_offset = isset($_GET['week']) ? (int)$_GET['week'] : 0;
$week_offset = max(0, min($week_offset, 4));

$today = new DateTime('now', new DateTimeZone('Europe/Paris'));

$week_start = clone $today;
$week_start->modify('Monday this week');
$week_start->modify(($week_offset * 7) . ' days');

$week_end = clone $week_start;
$week_end->modify('+6 days');

$date_start = $week_start->format('Y-m-d');
$date_end = $week_end->format('Y-m-d');

$jours_en_fr = [
    'Monday' => 'Lundi', 'Tuesday' => 'Mardi', 'Wednesday' => 'Mercredi', 
    'Thursday' => 'Jeudi', 'Friday' => 'Vendredi', 'Saturday' => 'Samedi', 'Sunday' => 'Dimanche'
];

$jour_actuel_fr = $jours_en_fr[$today->format('l')];

$demain_obj = clone $today;
$demain_obj->modify('+1 day');
$jour_demain_fr = $jours_en_fr[$demain_obj->format('l')];

$can_prev = $week_offset > 0;
$can_next = $week_offset < 4;

try {
    $stmt = $db->prepare("
        SELECT p.*, m.title as manga_title, m.image_url, m.status as manga_status
        FROM planning_sorties p
        JOIN mangas m ON p.manga_id = m.id
        WHERE p.statut IN ('prevu', 'en_cours') 
        AND p.date_prevue >= :date_start
        AND p.date_prevue <= :date_end
        ORDER BY p.date_prevue ASC, p.ordre_affichage ASC, p.heure_sortie ASC
    ");
    $stmt->execute([':date_start' => $date_start, ':date_end' => $date_end]);
    $planning = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $planning = [];
}

$planning_par_jour = [
    'Lundi' => [], 'Mardi' => [], 'Mercredi' => [], 'Jeudi' => [], 
    'Vendredi' => [], 'Samedi' => [], 'Dimanche' => []
];

foreach ($planning as $sortie) {
    $planning_par_jour[$sortie['jour_semaine']][] = $sortie;
}

$jours_semaine = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planning des Sorties</title>
    
    <meta name="description" content="Découvrez le planning des prochaines sorties de chapitres manga sur Yurei Scan.">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Planning des Sorties">
    <meta property="og:description" content="Ne ratez plus aucune sortie ! Consultez notre planning hebdomadaire.">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .content { max-width: 1400px; margin: 0 auto; padding: 0 20px; }
        .page-header { text-align: center; margin: 40px 0; padding: 40px 20px; background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); position: relative; overflow: hidden; }
        .page-header::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #bc6a6a; }
        .page-header h1 { font-size: 42px; margin-bottom: 15px; color: #bc6a6a; text-transform: uppercase; letter-spacing: 2px; font-weight: 700; }
        .page-header p { font-size: 18px; color: #bbb; max-width: 600px; margin: 0 auto; }
        .planning-legend { display: flex; justify-content: center; gap: 20px; margin: 30px 0; flex-wrap: wrap; }
        .legend-item { display: flex; align-items: center; gap: 8px; padding: 8px 16px; background: rgba(255,255,255,0.05); border-radius: 20px; font-size: 14px; border: 1px solid rgba(255,255,255,0.1); }
        .legend-dot { width: 12px; height: 12px; border-radius: 50%; }
        .dot-aujourdhui { background: #bc6a6a; }
        .dot-proche { background: #f39c12; }
        .dot-futur { background: #2ecc71; }
        .planning-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 24px; margin: 50px 0 60px; }
        .day-card { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 28px 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); transition: all 0.3s ease; position: relative; overflow: hidden; display: flex; flex-direction: column; }
        .day-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #bc6a6a; transform: scaleX(0); transition: transform 0.3s ease; }
        .day-card:hover { transform: translateY(-4px); box-shadow: 0 8px 30px rgba(188, 106, 106, 0.25); border-color: rgba(255,255,255,0.2); }
        .day-card:hover::before { transform: scaleX(1); }
        .day-card.today { border-color: rgba(188, 106, 106, 0.5); box-shadow: 0 4px 25px rgba(188, 106, 106, 0.3); }
        .day-header { font-size: 26px; font-weight: 700; margin-bottom: 20px; text-align: center; color: #fff; text-transform: uppercase; letter-spacing: 2px; padding-bottom: 15px; border-bottom: 2px solid rgba(255,255,255,0.1); display: flex; align-items: center; justify-content: center; gap: 12px; }
        .day-badge { font-size: 12px; padding: 4px 12px; border-radius: 20px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; }
        .badge-today { background: rgba(188, 106, 106, 0.2); color: #bc6a6a; border: 1px solid rgba(188, 106, 106, 0.4); }
        .badge-tomorrow { background: rgba(243,156,18,0.2); color: #f39c12; border: 1px solid rgba(243,156,18,0.4); }
        .week-navigation { display: flex; align-items: center; justify-content: center; gap: 30px; margin: 30px 0; padding: 20px; background: rgba(255,255,255,0.03); border-radius: 15px; border: 1px solid rgba(255,255,255,0.08); }
        .week-nav-btn { background: #bc6a6a; border: none; color: #fff; padding: 12px 20px; font-size: 20px; cursor: pointer; border-radius: 12px; transition: all 0.3s ease; font-weight: 700; box-shadow: 0 2px 12px rgba(188, 106, 106, 0.25); display: flex; align-items: center; justify-content: center; width: 50px; height: 50px; }
        .week-nav-btn:hover { transform: scale(1.1); box-shadow: 0 4px 20px rgba(188, 106, 106, 0.4); }
        .week-nav-btn:active { transform: scale(0.95); }
        .week-nav-btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }
        .week-display { text-align: center; color: #ccc; font-weight: 600; min-width: 200px; }
        .week-display .dates { font-size: 16px; margin-top: 5px; color: #999; }
        .sorties-list { display: flex; flex-direction: column; gap: 12px; flex: 1; }
        .sortie-item { display: flex; align-items: center; gap: 14px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 14px; text-decoration: none; color: inherit; transition: all 0.3s ease; position: relative; overflow: hidden; }
        .sortie-item::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; background: #bc6a6a; transform: scaleY(0); transition: transform 0.3s ease; }
        .sortie-item:hover { background: rgba(255,255,255,0.12); border-color: rgba(188, 106, 106, 0.4); transform: translateX(5px); }
        .sortie-item:hover::before { transform: scaleY(1); }
        .sortie-thumb { width: 55px; height: 72px; border-radius: 10px; object-fit: cover; flex-shrink: 0; border: 2px solid rgba(255,255,255,0.1); box-shadow: 0 2px 10px rgba(0,0,0,0.25); }
        .sortie-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px; }
        .sortie-title { font-size: 16px; font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; letter-spacing: 0.3px; }
        .sortie-details { display: flex; flex-direction: column; gap: 4px; font-size: 13px; color: #999; }
        .sortie-chapter { display: flex; align-items: center; gap: 6px; font-weight: 600; color: #bc6a6a; }
        .sortie-chapter::before { content: '📖'; }
        .sortie-time { display: flex; align-items: center; gap: 6px; font-size: 12px; }
        .sortie-time::before { content: '🕐'; }
        .sortie-date { font-size: 12px; color: #666; margin-top: 2px; }
        .empty-day { text-align: center; padding: 40px 20px; color: #666; font-style: italic; font-size: 15px; }
        .empty-day::before { display: block; font-size: 48px; margin-bottom: 15px; opacity: 0.5; }
        .info-banner { background: rgba(188, 106, 106, 0.1); border: 1px solid rgba(188, 106, 106, 0.3); border-radius: 15px; padding: 20px; margin: 30px 0; text-align: center; color: #bc6a6a; }
        .info-banner strong { color: #fff; }
        @media (max-width: 768px) {
            .content { padding: 0 15px; }
            .page-header { margin: 20px 0 30px; padding: 25px 15px; }
            .page-header h1 { font-size: 28px; }
            .page-header p { font-size: 15px; }
            .planning-grid { grid-template-columns: 1fr; gap: 20px; margin: 30px 0 50px; }
            .day-header { font-size: 22px; }
            .sortie-title { font-size: 15px; }
            .planning-legend { flex-direction: column; align-items: center; gap: 12px; }
        }
        @media (max-width: 480px) {
            .sortie-thumb { width: 45px; height: 60px; }
            .sortie-title { font-size: 14px; }
            .sortie-details { font-size: 12px; }
        }
    </style>
</head>
<body>
    <div class="content">
        <div class="page-header">
            <h1>Planning des Sorties</h1>
            <p>Découvrez les prochaines sorties de la Yurei Scan :</p>
        </div>

        <div class="week-navigation">
            <button class="week-nav-btn" onclick="previousWeek()" title="Semaine précédente" <?php echo !$can_prev ? 'disabled' : ''; ?>>←</button>
            <div class="week-display">
                <div><?php echo $week_start->format('d/m/Y'); ?> - <?php echo $week_end->format('d/m/Y'); ?></div>
                <div class="dates">
                    <?php 
                    if ($week_offset == 0) {
                        echo 'Semaine actuelle';
                    } else {
                        echo 'Semaine +' . $week_offset;
                    }
                    ?>
                </div>
            </div>
            <button class="week-nav-btn" onclick="nextWeek()" title="Semaine prochaine" <?php echo !$can_next ? 'disabled' : ''; ?>>→</button>
        </div>

        <?php if (empty($planning)): ?>
            <div class="info-banner">
                <strong>Aucune sortie prévue</strong><br>
                Le planning sera mis à jour prochainement !
            </div>
        <?php else: ?>
            <div class="info-banner">
                Certains chapitres peuvent être retardés. 
                <strong>Rejoignez notre Discord</strong> pour être notifié instantanément !
            </div>
        <?php endif; ?>

        <div class="planning-grid">
            <?php
            $aujourdhui = date('l');
            $jours_en = ['Monday' => 'Lundi', 'Tuesday' => 'Mardi', 'Wednesday' => 'Mercredi', 
                         'Thursday' => 'Jeudi', 'Friday' => 'Vendredi', 'Saturday' => 'Samedi', 'Sunday' => 'Dimanche'];
            $jour_actuel = $jours_en[$aujourdhui] ?? 'Lundi';
            
            $demain = date('l', strtotime('+1 day'));
            $jour_demain = $jours_en[$demain] ?? 'Mardi';

            foreach ($jours_semaine as $jour):
                $has_sorties = !empty($planning_par_jour[$jour]);

                $is_today = ($week_offset == 0 && $jour === $jour_actuel);
                $is_tomorrow = false;
                if ($week_offset == 0 && $jour === $jour_demain_fr && $jour !== 'Lundi') {
                    $is_tomorrow = true;
                } elseif ($week_offset == 1 && $jour === 'Lundi' && $jour_actuel_fr === 'Dimanche') {
                    $is_tomorrow = true;
                }
            ?>
                <div class="day-card <?php echo $is_today ? 'today' : ''; ?>">
                    <div class="day-header">
                        <?php echo $jour; ?>
                        <?php if ($is_today): ?>
                            <span class="day-badge badge-today">Aujourd'hui</span>
                        <?php elseif ($is_tomorrow): ?>
                            <span class="day-badge badge-tomorrow">Demain</span>
                        <?php endif; ?>
                    </div>

                    <?php if (!$has_sorties): ?>
                        <div class="empty-day">Aucune sortie prévue ce jour</div>
                    <?php else: ?>
                        <div class="sorties-list">
                            <?php foreach ($planning_par_jour[$jour] as $sortie):
                                $chapter_num = $sortie['chapter_number'];
                                if (is_numeric($chapter_num)) {
                                    $cnf = (float)$chapter_num;
                                    $chapter_num = (floor($cnf) == $cnf) 
                                        ? (string)(int)$cnf 
                                        : rtrim(rtrim(number_format($cnf, 1, '.', ''), '0'), '.');
                                }
                                
                                $date_formatted = date('d/m/Y', strtotime($sortie['date_prevue']));
                                $heure_formatted = !empty($sortie['heure_sortie']) ? substr($sortie['heure_sortie'], 0, 5) : null;
                            ?>
                                <a href="manga.php?id=<?php echo (int)$sortie['manga_id']; ?>" class="sortie-item">
                                    <?php if (!empty($sortie['image_url'])): ?>
                                        <img src="<?php echo htmlspecialchars($sortie['image_url']); ?>" 
                                             alt="<?php echo htmlspecialchars($sortie['manga_title']); ?>" 
                                             class="sortie-thumb">
                                    <?php else: ?>
                                        <div class="sortie-thumb" style="background:#222;"></div>
                                    <?php endif; ?>

                                    <div class="sortie-info">
                                        <span class="sortie-title"><?php echo htmlspecialchars($sortie['manga_title']); ?></span>
                                        <div class="sortie-details">
                                            <span class="sortie-chapter">Chapitre <?php echo htmlspecialchars($chapter_num); ?></span>
                                            <?php if ($heure_formatted): ?>
                                                <span class="sortie-time"><?php echo $heure_formatted; ?></span>
                                            <?php endif; ?>
                                            <span class="sortie-date"><?php echo $date_formatted; ?></span>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script>
        function previousWeek() {
            const currentWeek = new URLSearchParams(window.location.search).get('week') || '0';
            const newWeek = parseInt(currentWeek) - 1;
            window.location.href = '?week=' + newWeek;
        }

        function nextWeek() {
            const currentWeek = new URLSearchParams(window.location.search).get('week') || '0';
            const newWeek = parseInt(currentWeek) + 1;
            window.location.href = '?week=' + newWeek;
        }

        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, index * 100);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

        document.querySelectorAll('.day-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });

        window.addEventListener('load', () => {
            const todayCard = document.querySelector('.day-card.today');
            if (todayCard) {
                setTimeout(() => {
                    todayCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 500);
            }
        });
    </script>
</body>
</html>