<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['chapter_id']) && !empty($_POST['manga_id'])) {

    $chapter_id = (int)$_POST['chapter_id'];
    $manga_id   = (int)$_POST['manga_id'];

    try {
        $db->beginTransaction();

        $stmt = $db->prepare("DELETE FROM chapter_pages WHERE chapter_id = ?");
        $stmt->execute([$chapter_id]);

        $stmt = $db->prepare("DELETE FROM chapters WHERE id = ? AND manga_id = ?");
        $stmt->execute([$chapter_id, $manga_id]);

        $db->commit();

        header("Location: manga.php?id=" . $manga_id . "&success=deleted");
        exit();

    } catch (PDOException $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("Erreur delete_chapter : " . $e->getMessage());
        header("Location: manga.php?id=" . $manga_id . "&error=delete_failed");
        exit();
    }

} else {
    header("Location: index.php?error=invalid_request");
    exit();
}
?>
