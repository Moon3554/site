<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: index.php');
    exit();
}

try {
    $db->exec("ALTER TABLE mangas ADD COLUMN IF NOT EXISTS vertical_only TINYINT DEFAULT 0");
} catch (PDOException $e) {
}

$error_msg   = '';
$success_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title         = trim($_POST['title'] ?? '');
    $summary       = trim($_POST['summary'] ?? '');
    $image_url     = trim($_POST['image_url'] ?? '');
    $is_adult      = isset($_POST['is_adult']) ? 1 : 0;
    $vertical_only = isset($_POST['vertical_only']) ? 1 : 0;

    if (empty($title) || empty($summary)) {
        $error_msg = '⚠️ Merci de remplir tous les champs obligatoires.';
    } elseif (!empty($image_url) && !filter_var($image_url, FILTER_VALIDATE_URL)) {
        $error_msg = '⚠️ L\'URL de l\'image est invalide.';
    } else {
        try {
            $stmt = $db->prepare("INSERT INTO mangas (title, summary, image_url, is_adult, vertical_only, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $summary, $image_url ?: null, $is_adult, $vertical_only]);

            $success_msg = 'Manga ajouté avec succès ! Redirection...';
            header("Refresh: 2; URL=manga_list.php");
            exit();
        } catch (PDOException $e) {
            $error_msg = 'Erreur PDO : ' . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un manga - Yurei Scan</title>
</head>
<?php include 'header.php'; ?>
<body>

<div class="content" style="text-align:center; padding:30px;">
    <h1>Ajouter un nouveau manga</h1>

    <?php if (!empty($error_msg)): ?>
        <div style="color:red; margin-bottom:15px;"><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>
    <?php if (!empty($success_msg)): ?>
        <div style="color:limegreen; margin-bottom:15px;"><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>

    <form method="POST" style="display:flex; flex-direction:column; align-items:center; gap:20px; margin-top:30px;">
        <input type="text" name="title" required placeholder="Titre du manga"
               value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>"
               style="width:500px; height:45px; padding:10px; font-size:16px; border:1px solid #555; background:#222; color:#fff; border-radius:5px;">

        <textarea name="summary" required placeholder="Résumé du manga"
                  style="width:500px; height:120px; padding:10px; font-size:16px; border:1px solid #555; background:#222; color:#fff; border-radius:5px;"><?php echo htmlspecialchars($_POST['summary'] ?? ''); ?></textarea>

        <input type="url" name="image_url" placeholder="URL de l'image du manga (optionnel)"
               value="<?php echo htmlspecialchars($_POST['image_url'] ?? ''); ?>"
               style="width:500px; height:45px; padding:10px; font-size:16px; border:1px solid #555; background:#222; color:#fff; border-radius:5px;">

        <label style="color:#fff; font-size:16px; display:flex; align-items:center; gap:10px;">
            <input type="checkbox" name="is_adult" value="1" style="width:20px; height:20px; cursor:pointer;"
                   <?php echo isset($_POST['is_adult']) ? 'checked' : ''; ?>>
            Contenu réservé à un public plus mature.
        </label>

        <label style="color:#fff; font-size:16px; display:flex; align-items:center; gap:10px;">
            <input type="checkbox" name="vertical_only" value="1" style="width:20px; height:20px; cursor:pointer;"
                   <?php echo isset($_POST['vertical_only']) ? 'checked' : ''; ?>>
            Lecture verticale uniquement (pas de mode page par page)
        </label>

        <button type="submit"
                style="background:#28a745; color:#fff; padding:10px 25px; border:none; border-radius:5px; font-size:16px; cursor:pointer;">
            ➕ Ajouter
        </button>
    </form>

    <p style="margin-top:20px;">
        <a href="manga_list.php" style="color:#00aaff; text-decoration:none;">← Retour à la liste des mangas</a>
    </p>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
