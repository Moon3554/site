<?php
session_start();

if (!empty($_SESSION['captcha_ok'])) {
    header('Location: /');
    exit();
}


$now  = time();
$error = '';

if (empty($_SESSION['captcha_page_token'])) {
    $_SESSION['captcha_page_token'] = bin2hex(random_bytes(24));
    $_SESSION['captcha_page_start'] = $now;
}
$page_token = $_SESSION['captcha_page_token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fail = false;

    if (!empty($_POST['email_confirm'])) {
        $fail = true; 
    }

    if (isset($_POST['robot_check']) && $_POST['robot_check'] === '1') {
        $fail = true;
    }

    $elapsed = $now - ($_SESSION['captcha_page_start'] ?? $now);
    if ($elapsed < 2) {
        $fail = true;
    }

    if (($_POST['page_token'] ?? '') !== $page_token) {
        $fail = true;
    }

    $human_checked = isset($_POST['i_am_human']) && $_POST['i_am_human'] === 'yes';

    $expected_js_val = substr(md5($page_token . 'yurei'), 0, 8);
    $js_val_ok = ($_POST['js_token'] ?? '') === $expected_js_val;

    if (!$fail && $human_checked && $js_val_ok) {
        unset($_SESSION['captcha_page_token'], $_SESSION['captcha_page_start']);
        $_SESSION['captcha_ok']      = true;
        

        $redirect = $_SESSION['captcha_redirect'] ?? '/';
        unset($_SESSION['captcha_redirect']);
        header('Location: ' . $redirect);
        exit();
    } else {
        $_SESSION['captcha_page_token'] = bin2hex(random_bytes(24));
        $_SESSION['captcha_page_start'] = $now;
        $page_token = $_SESSION['captcha_page_token'];

        if (!$fail) {
            $error = 'Veuillez cocher la case pour continuer.';
        }
    }
}

$js_expected = substr(md5($page_token . 'yurei'), 0, 8);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://i.ibb.co/LdCC28Wk/logo-site.png">
    <title>Vérification - Yurei Scan</title>
    <meta name="robots" content="noindex, nofollow">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;700&family=Nunito:wght@400;600;700&display=swap');

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Nunito', sans-serif;
            background: #0d0d14;
            color: #fff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
        }

        .site-logo {
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            margin-bottom: 40px;
        }
        .site-logo img { height: 55px; }
        .site-logo span {
            font-family: 'Rajdhani', sans-serif;
            font-size: 38px;
            font-weight: 700;
            color: #bc6a6a;
        }

        .box {
            background: #13131f;
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 24px;
            padding: 50px 44px;
            max-width: 460px;
            width: 100%;
            box-shadow: 0 24px 70px rgba(0,0,0,0.5);
            animation: fadeUp 0.4s ease;
        }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .box-title {
            font-family: 'Rajdhani', sans-serif;
            font-size: 26px;
            font-weight: 700;
            text-align: center;
            margin-bottom: 8px;
            letter-spacing: 1px;
        }
        .box-sub {
            text-align: center;
            font-size: 14px;
            color: rgba(255,255,255,0.4);
            margin-bottom: 36px;
            line-height: 1.6;
        }

        .checkbox-row {
            display: flex;
            align-items: center;
            gap: 16px;
            background: rgba(255,255,255,0.04);
            border: 1.5px solid rgba(255,255,255,0.1);
            border-radius: 14px;
            padding: 18px 20px;
            cursor: pointer;
            transition: border-color 0.2s, background 0.2s;
            user-select: none;
            margin-bottom: 28px;
        }
        .checkbox-row:hover {
            border-color: rgba(188,106,106,0.5);
            background: rgba(188,106,106,0.05);
        }
        .checkbox-row.checked {
            border-color: #2ecc71;
            background: rgba(46,204,113,0.07);
        }

        .custom-check {
            width: 26px;
            height: 26px;
            border: 2px solid rgba(255,255,255,0.25);
            border-radius: 6px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            background: rgba(255,255,255,0.04);
        }
        .checkbox-row.checked .custom-check {
            background: #2ecc71;
            border-color: #2ecc71;
        }
        .custom-check svg {
            opacity: 0;
            transform: scale(0.5);
            transition: all 0.2s;
        }
        .checkbox-row.checked .custom-check svg {
            opacity: 1;
            transform: scale(1);
        }

        .check-label {
            font-size: 15px;
            font-weight: 600;
            color: rgba(255,255,255,0.85);
        }
        .check-sub {
            font-size: 12px;
            color: rgba(255,255,255,0.35);
            margin-top: 2px;
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background: #bc6a6a;
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            font-family: 'Nunito', sans-serif;
            letter-spacing: 0.5px;
            transition: all 0.2s;
            opacity: 0.45;
            pointer-events: none;
        }
        .btn-submit.active {
            opacity: 1;
            pointer-events: auto;
        }
        .btn-submit.active:hover {
            background: #d47a7a;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(188,106,106,0.4);
        }

        .error-msg {
            background: rgba(231,76,60,0.12);
            border: 1px solid rgba(231,76,60,0.3);
            color: #e74c3c;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 14px;
            text-align: center;
            margin-bottom: 20px;
        }

        .hp-trap {
            position: absolute;
            left: -9999px;
            top: -9999px;
            width: 1px;
            height: 1px;
            overflow: hidden;
            opacity: 0;
            pointer-events: none;
            tab-index: -1;
        }

        .cloudflare-badge {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 6px;
            margin-top: 14px;
            font-size: 11px;
            color: rgba(255,255,255,0.2);
        }

        @media (max-width: 480px) {
            .box { padding: 36px 24px; }
        }
    </style>
</head>
<body>

<a href="/" class="site-logo">
    <img src="https://i.ibb.co/LdCC28Wk/logo-site.png" alt="Yurei Scan">
    <span>Yurei Scan</span>
</a>

<div class="box">
    <div class="box-title">Vérification humaine</div>
    <div class="box-sub">Une vérification rapide avant d'accéder au site.<br>Valable 24h sur toutes les pages.</div>

    <?php if ($error): ?>
        <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="" id="captchaForm" autocomplete="off">

        <input type="hidden" name="page_token" value="<?php echo htmlspecialchars($page_token); ?>">

        <input type="hidden" name="js_token" id="js_token" value="">

        <input type="hidden" name="i_am_human" id="i_am_human_val" value="">

        <div class="hp-trap" aria-hidden="true">
            <label for="email_confirm">Email de confirmation</label>
            <input type="text" name="email_confirm" id="email_confirm" tabindex="-1" autocomplete="new-password" value="">
        </div>

        <input type="hidden" name="robot_check" id="robot_check" value="1">

        <div class="checkbox-row" id="checkRow" onclick="toggleCheck()">
            <div class="custom-check" id="customCheck">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <polyline points="2,7 5.5,10.5 12,3" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <div>
                <div class="check-label">Je ne suis pas un robot</div>
                <div class="check-sub">Confidentialité - Conditions</div>
            </div>
        </div>

        <button type="submit" class="btn-submit" id="btnSubmit">Accéder au site →</button>

        <div class="cloudflare-badge">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Vérification sécurisée
        </div>

    </form>
</div>

<script>
    let isChecked = false;

    document.getElementById('robot_check').value = '0';

    document.getElementById('js_token').value = '<?php echo $js_expected; ?>';

    function toggleCheck() {
        isChecked = !isChecked;
        const row = document.getElementById('checkRow');
        const btn = document.getElementById('btnSubmit');
        const val = document.getElementById('i_am_human_val');

        if (isChecked) {
            row.classList.add('checked');
            btn.classList.add('active');
            val.value = 'yes';
        } else {
            row.classList.remove('checked');
            btn.classList.remove('active');
            val.value = '';
        }
    }

    document.getElementById('captchaForm').addEventListener('submit', function(e) {
        if (!isChecked) {
            e.preventDefault();
        }
    });
</script>

</body>
</html>