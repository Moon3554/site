<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'check_captcha.php';
require_once 'db.php';

try {
    $db->exec("ALTER TABLE mangas ADD COLUMN IF NOT EXISTS display_order INT DEFAULT 0");
    $db->exec("ALTER TABLE mangas ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'En cours'");
} catch (PDOException $e) {  }


try {
    $db->exec("UPDATE mangas SET status = 'En cours'  WHERE status IN ('ongoing','Ongoing')  OR status IS NULL OR status = ''");
    $db->exec("UPDATE mangas SET status = 'Terminé'   WHERE status IN ('completed','Completed')");
    $db->exec("UPDATE mangas SET status = 'Abandonné' WHERE status IN ('abandoned','Abandoned')");
} catch (PDOException $e) {  }

if (isset($_POST['action']) && $_POST['action'] === 'update_order'
    && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {

    $order_data = json_decode($_POST['order_data'], true);
    if (is_array($order_data)) {
        try {
            $db->beginTransaction();
            $stmt = $db->prepare("UPDATE mangas SET display_order = ? WHERE id = ?");
            foreach ($order_data as $item) {
                $stmt->execute([(int)$item['order'], (int)$item['id']]);
            }
            $db->commit();
            echo json_encode(['success' => true]);
            exit;
        } catch (PDOException $e) {
            $db->rollBack();
            error_log("Erreur update_order manga_list : " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Erreur serveur']);
            exit;
        }
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'update_manga'
    && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {

    $manga_id     = (int)($_POST['manga_id'] ?? 0);
    $new_title    = trim($_POST['title'] ?? '');
    $new_image    = trim($_POST['image_url'] ?? '');
    $is_adult     = (isset($_POST['is_adult']) && $_POST['is_adult'] === '1') ? 1 : 0;
    $status       = trim($_POST['status'] ?? 'En cours');

    if (!in_array($status, ['En cours', 'Terminé', 'Abandonné'])) {
        $status = 'En cours';
    }

    if (!empty($new_image) && !filter_var($new_image, FILTER_VALIDATE_URL)) {
        echo json_encode(['success' => false, 'error' => 'URL image invalide']);
        exit;
    }

    if ($manga_id > 0 && !empty($new_title)) {
        try {
            $stmt = $db->prepare("UPDATE mangas SET title = ?, image_url = ?, is_adult = ?, status = ? WHERE id = ?");
            $stmt->execute([$new_title, $new_image ?: null, $is_adult, $status, $manga_id]);
            echo json_encode(['success' => true, 'message' => 'Série mise à jour !']);
            exit;
        } catch (PDOException $e) {
            error_log("Erreur update_manga : " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Erreur serveur']);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Données invalides']);
        exit;
    }
}

try {
    $stmt  = $db->query("
        SELECT m.*,
               COALESCE(SUM(c.views), 0) as total_views
        FROM mangas m
        LEFT JOIN chapters c ON m.id = c.manga_id
        GROUP BY m.id
        ORDER BY
            CASE WHEN m.display_order = 0 THEN 1 ELSE 0 END,
            m.display_order ASC,
            m.created_at ASC
    ");
    $mangas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur SQL : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nos Séries - Yurei Scan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .content { max-width: 1400px; margin: 0 auto; padding: 40px 20px; }
        .page-title { text-align: center; font-size: 42px; margin-bottom: 50px; font-weight: 700; color: #bc6a6a; letter-spacing: 2px; text-transform: uppercase; position: relative; padding-bottom: 20px; }
        .page-title::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 100px; height: 4px; background: #bc6a6a; border-radius: 2px; }
        .manga-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 35px; margin-bottom: 50px; }
        .manga-card-wrapper { position: relative; }
        .manga-card { text-decoration: none; color: inherit; display: block; background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; overflow: hidden; border: 1px solid rgba(255,255,255,0.1); transition: all 0.4s cubic-bezier(0.4,0,0.2,1); position: relative; box-shadow: 0 4px 20px rgba(0,0,0,0.3); animation: fadeInUp 0.6s ease forwards; opacity: 0; }
        .manga-card.draggable { cursor: grab; user-select: none; }
        .manga-card.draggable:active { cursor: grabbing; }
        .manga-card-wrapper.dragging { opacity: 0.4; }
        .manga-card-wrapper.dragging .manga-card { transform: rotate(3deg) scale(0.95); box-shadow: 0 15px 40px rgba(188,106,106,0.5); }
        .manga-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #bc6a6a; transform: scaleX(0); transition: transform 0.3s ease; z-index: 1; }
        .manga-card:hover { transform: translateY(-10px); box-shadow: 0 10px 35px rgba(188,106,106,0.3); border-color: rgba(255,255,255,0.2); }
        .manga-card:hover::before { transform: scaleX(1); }
        .edit-button { position: absolute; top: 10px; left: 10px; background: rgba(188,106,106,0.9); color: white; width: 35px; height: 35px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; z-index: 10; cursor: pointer; box-shadow: 0 2px 12px rgba(0,0,0,0.25); transition: all 0.3s ease; border: none; }
        .edit-button:hover { background: rgba(188,106,106,1); transform: scale(1.1); }
        .status-badge { position: absolute; top: 10px; right: 10px; backdrop-filter: blur(10px); padding: 6px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; z-index: 9; box-shadow: 0 2px 12px rgba(0,0,0,0.25); text-transform: uppercase; letter-spacing: 0.5px; }
        .status-badge.En_cours { background: linear-gradient(135deg,rgba(52,152,219,0.9),rgba(41,128,185,0.9)); border: 1.5px solid rgba(52,152,219,0.8); color: #e3f2fd; }
        .status-badge.Terminé  { background: linear-gradient(135deg,rgba(46,204,113,0.9),rgba(39,174,96,0.9));  border: 1.5px solid rgba(46,204,113,0.8);  color: #e8f5e9; }
        .status-badge.Abandonné { background: linear-gradient(135deg,rgba(231,76,60,0.9),rgba(192,57,43,0.9));   border: 1.5px solid rgba(231,76,60,0.8);    color: #ffebee; }
        .edit-menu { position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%); background: rgba(10,10,10,0.98); backdrop-filter: blur(10px); border: 2px solid rgba(188,106,106,0.7); border-radius: 12px; padding: 20px; min-width: 320px; max-width: 90vw; z-index: 10000; box-shadow: 0 10px 40px rgba(0,0,0,0.8); display: none; }
        .edit-menu.active { display: block; animation: slideDown 0.3s ease; }
        @keyframes slideDown { from { opacity:0; transform:translate(-50%,calc(-50% - 10px)); } to { opacity:1; transform:translate(-50%,-50%); } }
        .edit-menu h3 { color: #bc6a6a; font-size: 18px; margin-bottom: 15px; font-weight: 600; text-align: center; }
        .edit-menu label { display: block; font-size: 13px; color: #aaa; margin-bottom: 6px; margin-top: 12px; }
        .edit-menu input[type="text"] { width: 100%; padding: 10px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #fff; font-size: 14px; font-family: inherit; transition: all 0.3s ease; }
        .edit-menu input[type="text"]:focus { outline: none; border-color: #bc6a6a; }
        .edit-menu input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; }
        .edit-menu select { width: 100%; padding: 10px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: #fff; font-size: 14px; cursor: pointer; }
        .edit-menu select option { background: #1a1a1a; color: #fff; }
        .checkbox-label { display: flex; align-items: center; gap: 10px; margin-top: 15px; cursor: pointer; color: #fff; font-size: 14px; }
        .edit-menu-buttons { display: flex; gap: 10px; margin-top: 20px; }
        .btn-save, .btn-cancel { flex: 1; padding: 10px; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; }
        .btn-save { background: #bc6a6a; color: white; }
        .btn-save:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(188,106,106,0.4); }
        .btn-cancel { background: rgba(255,255,255,0.1); color: #fff; border: 2px solid rgba(255,255,255,0.3); }
        .btn-cancel:hover { background: rgba(255,255,255,0.2); }
        .menu-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 9999; display: none; }
        .menu-overlay.active { display: block; }
        .manga-image-container { position: relative; width: 100%; aspect-ratio: 2/3; overflow: hidden; background: #000; }
        .manga-image-container img { width: 100%; height: 100%; object-fit: cover; object-position: top center; transition: transform 0.5s ease; }
        .manga-card:hover .manga-image-container img { transform: scale(1.1); }
        .manga-title { padding: 20px; text-align: center; background: rgba(0,0,0,0.3); }
        .manga-title h2 { font-size: 18px; font-weight: 600; color: #fff; margin: 0; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis; }
        .admin-section { text-align: center; margin-top: 40px; padding: 30px; }
        .add-button { display: inline-flex; align-items: center; gap: 10px; background: #bc6a6a; color: #fff; padding: 15px 35px; border-radius: 30px; font-size: 18px; font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: all 0.3s ease; box-shadow: 0 4px 20px rgba(188,106,106,0.4); }
        .add-button:hover { transform: translateY(-3px); box-shadow: 0 8px 30px rgba(188,106,106,0.6); }
        .empty-message { text-align: center; padding: 80px 20px; color: #999; font-size: 18px; }
        .notification { position: fixed; top: 20px; right: 20px; background: rgba(188,106,106,0.95); color: white; padding: 15px 25px; border-radius: 12px; box-shadow: 0 8px 25px rgba(0,0,0,0.3); z-index: 9999; animation: slideIn 0.3s ease; }
        @keyframes slideIn { from { opacity:0; transform:translateX(100px); } to { opacity:1; transform:translateX(0); } }
        @keyframes fadeInUp { from { opacity:0; transform:translateY(30px); } to { opacity:1; transform:translateY(0); } }
        .manga-card:nth-child(1){animation-delay:.1s} .manga-card:nth-child(2){animation-delay:.2s} .manga-card:nth-child(3){animation-delay:.3s}
        .manga-card:nth-child(4){animation-delay:.4s} .manga-card:nth-child(5){animation-delay:.5s} .manga-card:nth-child(6){animation-delay:.6s}
        .manga-card:nth-child(n+7){animation-delay:.7s}
        @media (max-width: 968px) { .manga-grid { grid-template-columns: repeat(auto-fill, minmax(240px,1fr)); gap: 25px; } .page-title { font-size: 36px; } }
        @media (max-width: 768px) { .content { padding: 30px 15px; } .manga-grid { grid-template-columns: repeat(2,1fr); gap: 10px; } .manga-title { padding: 8px 6px; } .manga-title h2 { font-size: 11px; -webkit-line-clamp: 2; } .status-badge { font-size: 8px; padding: 3px 6px; } }
        @media (max-width: 480px) { .manga-grid { gap: 8px; } .manga-title h2 { font-size: 10px; } }

    </style>
</head>
<body>

<?php include 'header.php'; ?>

    <div class="content">
        <h1 class="page-title">Nos Séries</h1>

        <?php if (!empty($mangas)):
            $statusLabels = ['En cours' => 'En cours', 'Terminé' => 'Terminé', 'Abandonné' => 'Abandonné'];
        ?>
            <div class="manga-grid" id="mangaGrid">
                <?php foreach ($mangas as $manga):
                    $status = (!empty($manga['status']) && isset($statusLabels[$manga['status']])) ? $manga['status'] : 'En cours';
                    $statusClass = str_replace(' ', '_', $status);
                ?>
                    <div class="manga-card-wrapper" data-id="<?php echo (int)$manga['id']; ?>" <?php if (!empty($manga['is_adult']) && $manga['is_adult'] == 1): ?>data-adult="true"<?php endif; ?>>
                        <a href="manga.php?id=<?php echo (int)$manga['id']; ?>"
                           class="manga-card <?php echo (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) ? 'draggable' : ''; ?>"
                           <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>draggable="true"<?php endif; ?>>

                            <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                                <button class="edit-button" onclick="event.preventDefault(); event.stopPropagation(); toggleEditMenu(<?php echo (int)$manga['id']; ?>)">☰</button>
                            <?php endif; ?>

                            <span class="status-badge <?php echo htmlspecialchars($statusClass); ?>" id="statusBadge<?php echo (int)$manga['id']; ?>">
                                <?php echo htmlspecialchars($statusLabels[$status]); ?>
                            </span>

                            <?php if (!empty($manga['image_url'])): ?>
                                <div class="manga-image-container">
                                    <img src="<?php echo htmlspecialchars($manga['image_url']); ?>"
                                         alt="<?php echo htmlspecialchars($manga['title']); ?>"
                                         id="mangaImg<?php echo (int)$manga['id']; ?>">
                                </div>
                            <?php endif; ?>

                            <div class="manga-title">
                                <h2 id="mangaTitle<?php echo (int)$manga['id']; ?>"><?php echo htmlspecialchars($manga['title']); ?></h2>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="menu-overlay" id="menuOverlay" onclick="closeAllMenus()"></div>

            <?php foreach ($mangas as $manga):
                $status = (!empty($manga['status']) && isset($statusLabels[$manga['status']])) ? $manga['status'] : 'En cours';
            ?>
                <div class="edit-menu" id="editMenu<?php echo (int)$manga['id']; ?>">
                    <h3>Modifier la série</h3>
                    <label>Titre</label>
                    <input type="text" id="title<?php echo (int)$manga['id']; ?>" value="<?php echo htmlspecialchars($manga['title']); ?>">
                    <label>URL de l'image</label>
                    <input type="text" id="image<?php echo (int)$manga['id']; ?>" value="<?php echo htmlspecialchars($manga['image_url'] ?? ''); ?>" placeholder="https://exemple.com/image.jpg">
                    <label>Statut</label>
                    <select id="status<?php echo (int)$manga['id']; ?>">
                        <option value="En cours"  <?php echo ($status === 'En cours')  ? 'selected' : ''; ?>>En cours</option>
                        <option value="Terminé"   <?php echo ($status === 'Terminé')   ? 'selected' : ''; ?>>Terminé</option>
                        <option value="Abandonné" <?php echo ($status === 'Abandonné') ? 'selected' : ''; ?>>Abandonné</option>
                    </select>
                    <label class="checkbox-label">
                        <input type="checkbox" id="isAdult<?php echo (int)$manga['id']; ?>" <?php echo (!empty($manga['is_adult']) && $manga['is_adult'] == 1) ? 'checked' : ''; ?>>
                        <span>Contenu réservé à un public averti.</span>
                    </label>
                    <div class="edit-menu-buttons">
                        <button class="btn-save"   onclick="saveMangaEdit(<?php echo (int)$manga['id']; ?>)">Sauvegarder</button>
                        <button class="btn-cancel" onclick="closeEditMenu(<?php echo (int)$manga['id']; ?>)">Annuler</button>
                    </div>
                </div>
            <?php endforeach; ?>

        <?php else: ?>
            <div class="empty-message"><p>Aucune série disponible pour le moment.</p></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
            <div class="admin-section">
                <a href="add_manga.php" class="add-button"><span>Ajouter un scan</span></a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function toggleEditMenu(mangaId) {
            closeAllMenus();
            document.getElementById('editMenu' + mangaId).classList.add('active');
            document.getElementById('menuOverlay').classList.add('active');
        }
        function closeEditMenu(mangaId) {
            document.getElementById('editMenu' + mangaId).classList.remove('active');
            document.getElementById('menuOverlay').classList.remove('active');
        }
        function closeAllMenus() {
            document.querySelectorAll('.edit-menu').forEach(m => m.classList.remove('active'));
            document.getElementById('menuOverlay').classList.remove('active');
        }

        function saveMangaEdit(mangaId) {
            const newTitle    = document.getElementById('title'   + mangaId).value.trim();
            const newImageUrl = document.getElementById('image'   + mangaId).value.trim();
            const isAdult     = document.getElementById('isAdult' + mangaId).checked ? '1' : '0';
            const status      = document.getElementById('status'  + mangaId).value;
            if (!newTitle) { alert('Le titre ne peut pas être vide !'); return; }

            const formData = new FormData();
            formData.append('action',    'update_manga');
            formData.append('manga_id',  mangaId);
            formData.append('title',     newTitle);
            formData.append('image_url', newImageUrl);
            formData.append('is_adult',  isAdult);
            formData.append('status',    status);

            fetch(window.location.href, { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('mangaTitle' + mangaId).textContent = newTitle;
                        const img = document.getElementById('mangaImg' + mangaId);
                        if (img && newImageUrl) img.src = newImageUrl;
                        const badge = document.getElementById('statusBadge' + mangaId);
                        if (badge) {
                            badge.className = 'status-badge ' + status.replace(/ /g, '_');
                            badge.textContent = status;
                        }
                        closeEditMenu(mangaId);
                        showNotification('Série mise à jour !');
                    } else { alert('Erreur : ' + (data.error || 'Une erreur est survenue')); }
                })
                .catch(() => alert('Erreur lors de la sauvegarde'));
        }

        function showNotification(msg) {
            const n = document.createElement('div');
            n.className = 'notification';
            n.textContent = msg;
            document.body.appendChild(n);
            setTimeout(() => n.remove(), 3000);
        }

        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
        const mangaGrid = document.getElementById('mangaGrid');
        if (mangaGrid) {
            let draggedWrapper = null;
            mangaGrid.addEventListener('dragstart', e => {
                const card = e.target.closest('.manga-card');
                if (!card || !card.classList.contains('draggable')) return;
                draggedWrapper = card.closest('.manga-card-wrapper');
                draggedWrapper.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
            });
            mangaGrid.addEventListener('dragover', e => {
                e.preventDefault();
                if (!draggedWrapper) return;
                const target = e.target.closest('.manga-card-wrapper');
                if (!target || target === draggedWrapper) return;
                const rect = target.getBoundingClientRect();
                if (e.clientY < rect.top + rect.height / 2) {
                    mangaGrid.insertBefore(draggedWrapper, target);
                } else {
                    mangaGrid.insertBefore(draggedWrapper, target.nextSibling);
                }
            });
            mangaGrid.addEventListener('dragend', () => {
                if (draggedWrapper) draggedWrapper.classList.remove('dragging');
                draggedWrapper = null;
                saveOrder();
            });
            mangaGrid.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); });

            function saveOrder() {
                const orderData = [];
                mangaGrid.querySelectorAll('.manga-card-wrapper').forEach((w, i) => {
                    if (w.dataset.id) orderData.push({ id: w.dataset.id, order: i + 1 });
                });
                if (!orderData.length) return;
                const fd = new FormData();
                fd.append('action', 'update_order');
                fd.append('order_data', JSON.stringify(orderData));
                fetch(window.location.href, { method: 'POST', body: fd })
                    .then(r => r.json())
                    .then(d => { if (d.success) showNotification('Ordre mis à jour'); })
                    .catch(console.error);
            }
        }
        <?php endif; ?>
    </script>

    <?php include 'footer.php'; ?>
</body>
</html>
    <script>
        (function() {
            var cards = document.querySelectorAll('[data-adult="true"]');

            function setAdult(enabled) {
                cards.forEach(function(el) {
                    el.style.display = enabled ? '' : 'none';
                });
                var t1 = document.getElementById('adultToggle');
                var t2 = document.getElementById('adultToggleMobile');
                var w1 = document.getElementById('adultFilterWrap');
                var w2 = document.getElementById('mobileAdultRow');
                if (t1) t1.checked = enabled;
                if (t2) t2.checked = enabled;
                if (w1) w1.classList.toggle('active', enabled);
                if (w2) w2.classList.toggle('active', enabled);
                try { localStorage.setItem('yurei_adult_enabled', enabled ? '1' : '0'); } catch(e) {}
            }

            setAdult(false);

            var t1 = document.getElementById('adultToggle');
            var t2 = document.getElementById('adultToggleMobile');
            var w1 = document.getElementById('adultFilterWrap');
            var w2 = document.getElementById('mobileAdultRow');

            if (t1) t1.addEventListener('change', function() { setAdult(this.checked); });
            if (t2) t2.addEventListener('change', function() { setAdult(this.checked); });
            if (w1) w1.addEventListener('click', function() { setAdult(!(t1 && t1.checked)); });
            if (w2) w2.addEventListener('click', function() { setAdult(!(t2 && t2.checked)); });
        })();
    </script>