<?php
require_once 'check_captcha.php';
session_start();
include 'header.php';

$staff_file = 'staff_data.json';
if (file_exists($staff_file)) {
    $staff_members = json_decode(file_get_contents($staff_file), true);
} else {
    $staff_members = [
        ['name' => 'The Quagmire', 'roles' => 'Responsable de la team, Editeur, Checkeur', 'image' => 'https://i.ibb.co/JR4Xr4jZ/The-Quagmire.jpg', 'date' => '22/06/25'],
        ['name' => 'Moon3554', 'roles' => 'Créateur du site, Editeur', 'image' => 'https://i.ibb.co/nqJsSp6P/Moon3554.jpg', 'date' => '22/06/25'],
        ['name' => 'Laaxiz', 'roles' => 'Cleaneur', 'image' => 'https://i.ibb.co/4ZWbZ2n6/Laaxiz.jpg', 'date' => '22/06/25'],
        ['name' => 'Lounis', 'roles' => 'Editeur', 'image' => 'https://i.ibb.co/nqCNKBfB/Lounis.jpg', 'date' => '22/06/25'],
        ['name' => 'Yalaguerre', 'roles' => 'Editeur', 'image' => 'https://i.ibb.co/N2jr2yx0/Yalaguerre.png', 'date' => '07/07/25'],
        ['name' => 'Destrucarmand', 'roles' => 'Traducteur', 'image' => 'https://i.ibb.co/whVvvfNq/Destrucarmand.png', 'date' => '16/08/25'],
        ['name' => 'Attellage', 'roles' => 'Cleaneur', 'image' => 'https://i.ibb.co/whZs90Ld/Attellage.jpg', 'date' => '08/09/25'],
        ['name' => 'Fireless', 'roles' => 'Traducteur', 'image' => 'https://i.ibb.co/3mbPcbKc/Fireless.jpg', 'date' => '24/09/25'],
        ['name' => 'Chomosuke', 'roles' => 'Traducteur', 'image' => 'https://i.ibb.co/mF1NVWjq/Chomosuke.png', 'date' => '29/09/25'],
        ['name' => 'Nasa', 'roles' => 'Editeur, Traducteur', 'image' => 'https://i.ibb.co/QvnDvMQd/Nasa.jpg', 'date' => '23/10/25']
    ];
    file_put_contents($staff_file, json_encode($staff_members, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

$message = '';
$error = '';

if ($is_admin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $new_member = [
                    'name' => trim($_POST['name']),
                    'roles' => trim($_POST['roles']),
                    'image' => trim($_POST['image']),
                    'date' => trim($_POST['date'])
                ];
                
                if (!empty($new_member['name']) && !empty($new_member['roles']) && !empty($new_member['image'])) {
                    $staff_members[] = $new_member;
                    file_put_contents($staff_file, json_encode($staff_members, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $message = 'Membre ajouté avec succès !';
                } else {
                    $error = 'Veuillez remplir tous les champs obligatoires.';
                }
                break;
                
            case 'delete':
                $index = intval($_POST['index']);
                if (isset($staff_members[$index])) {
                    array_splice($staff_members, $index, 1);
                    file_put_contents($staff_file, json_encode($staff_members, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $message = 'Membre supprimé avec succès !';
                }
                break;
                
            case 'edit':
                $index = intval($_POST['index']);
                if (isset($staff_members[$index])) {
                    $staff_members[$index] = [
                        'name' => trim($_POST['name']),
                        'roles' => trim($_POST['roles']),
                        'image' => trim($_POST['image']),
                        'date' => trim($_POST['date'])
                    ];
                    file_put_contents($staff_file, json_encode($staff_members, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $message = 'Membre modifié avec succès !';
                }
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Équipe Yurei</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #000; color: #fff; line-height: 1.6; min-height: 100vh; }
        .content { max-width: 1400px; margin: 0 auto; padding: 50px 20px; }
        .message { padding: 15px 20px; border-radius: 10px; margin-bottom: 20px; font-weight: 500; animation: slideDown 0.3s ease; }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message.success { background: rgba(76, 175, 80, 0.2); border: 1px solid rgba(76, 175, 80, 0.5); color: #4caf50; }
        .message.error { background: rgba(244, 67, 54, 0.2); border: 1px solid rgba(244, 67, 54, 0.5); color: #f44336; }
        .legal-link { text-align: center; margin-bottom: 15px; }
        .legal-link a { color: #666; text-decoration: none; font-size: 13px; transition: color 0.3s ease; }
        .legal-link a:hover { color: #999; }
        .page-title { text-align: center; font-size: 48px; margin-bottom: 40px; font-weight: 700; color: #bc6a6a; letter-spacing: 2px; text-transform: uppercase; position: relative; padding-bottom: 20px; }
        .page-title::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 120px; height: 4px; background: #bc6a6a; border-radius: 2px; }
        .intro-section { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 35px; margin-bottom: 50px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 32px rgba(255,255,255,0.1); border-left: 4px solid #bc6a6a; transition: all 0.3s ease; }
        .intro-section:hover { transform: translateY(-3px); box-shadow: 0 12px 40px rgba(255,255,255,0.15); }
        .intro-section p { font-size: 16px; line-height: 1.9; color: #e0e0e0; text-align: justify; }
        .admin-add-btn { position: fixed; bottom: 30px; right: 30px; width: 60px; height: 60px; background: #bc6a6a; border: none; border-radius: 50%; color: white; font-size: 30px; cursor: pointer; box-shadow: 0 5px 25px rgba(188,106,106,0.5); transition: all 0.3s ease; z-index: 100; }
        .admin-add-btn:hover { transform: scale(1.1) rotate(90deg); box-shadow: 0 8px 35px rgba(188,106,106,0.7); }
        .members-title { text-align: center; font-size: 36px; margin: 60px 0 40px; color: #fff; font-weight: 600; position: relative; padding-bottom: 15px; }
        .members-title::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 100px; height: 3px; background: #bc6a6a; border-radius: 2px; }
        .staff-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 30px; margin-bottom: 50px; }
        .staff-card { background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 30px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 8px 32px rgba(255,255,255,0.1); transition: all 0.4s ease; text-align: center; position: relative; overflow: hidden; }
        .staff-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: #bc6a6a; transform: scaleX(0); transition: transform 0.3s ease; }
        .staff-card:hover { transform: translateY(-10px); box-shadow: 0 15px 50px rgba(255,255,255,0.2); border-color: rgba(255,255,255,0.2); }
        .staff-card:hover::before { transform: scaleX(1); }
        .staff-card-admin { position: absolute; top: 10px; right: 10px; display: flex; gap: 5px; opacity: 0; transition: opacity 0.3s ease; }
        .staff-card:hover .staff-card-admin { opacity: 1; }
        .btn-mini { width: 30px; height: 30px; border-radius: 50%; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 14px; transition: all 0.3s ease; }
        .btn-edit { background: linear-gradient(135deg, #ff9800 0%, #ff5722 100%); color: white; }
        .btn-edit:hover { transform: scale(1.1); box-shadow: 0 3px 15px rgba(255, 152, 0, 0.5); }
        .btn-delete { background: linear-gradient(135deg, #f44336 0%, #e91e63 100%); color: white; }
        .btn-delete:hover { transform: scale(1.1); box-shadow: 0 3px 15px rgba(244, 67, 54, 0.5); }
        .staff-image-wrapper { position: relative; width: 160px; height: 160px; margin: 0 auto 25px; border-radius: 50%; background: rgba(188,106,106,0.2); padding: 5px; transition: all 0.3s ease; }
        .staff-card:hover .staff-image-wrapper { background: #bc6a6a; box-shadow: 0 10px 30px rgba(188,106,106,0.5); }
        .staff-image { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; border: 3px solid rgba(188,106,106,0.3); transition: all 0.3s ease; }
        .staff-card:hover .staff-image { border-color: #bc6a6a; transform: scale(1.05); }
        .staff-name { font-size: 22px; color: #bc6a6a; margin-bottom: 12px; font-weight: 600; }
        .staff-role { font-size: 14px; color: #bbb; line-height: 1.6; }
        .legal-section-container { margin-top: 80px; padding: 40px; background: rgba(0, 0, 0, 0.3); border-radius: 20px; border: 1px solid rgba(255, 255, 255, 0.05); text-align: center; }
        .legal-section-container h3 { color: #fff; font-size: 18px; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 1px; }
        .legal-section-container p { color: #888; font-size: 14px; max-width: 800px; margin: 0 auto 20px; }
        .legal-link-btn { display: inline-block; padding: 10px 25px; background: transparent; border: 1px solid #bc6a6a; color: #bc6a6a; text-decoration: none; border-radius: 30px; font-size: 14px; font-weight: 600; transition: all 0.3s ease; }
        .legal-link-btn:hover { background: #bc6a6a; color: white; box-shadow: 0 5px 15px rgba(188,106,106,0.3); }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 1000; align-items: center; justify-content: center; backdrop-filter: blur(5px); }
        .modal.active { display: flex; }
        .modal-content { background: linear-gradient(135deg, #1a1a2e 0%, #0f0f0f 100%); border-radius: 20px; padding: 30px; max-width: 500px; width: 90%; border: 1px solid rgba(255,255,255,0.1); animation: modalSlide 0.3s ease; }
        @keyframes modalSlide {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .modal-header h2 { color: #bc6a6a; font-size: 24px; }
        .close-modal { background: none; border: none; color: #fff; font-size: 30px; cursor: pointer; line-height: 1; transition: all 0.3s ease; }
        .close-modal:hover { color: #bc6a6a; transform: rotate(90deg); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #bbb; font-size: 14px; font-weight: 500; }
        .form-group input, .form-group textarea { width: 100%; padding: 12px 15px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; color: #fff; font-size: 14px; transition: all 0.3s ease; font-family: inherit; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #bc6a6a; background: rgba(255,255,255,0.08); }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .form-group small { display: block; margin-top: 5px; color: #888; font-size: 12px; }
        .btn { padding: 12px 30px; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; }
        .btn-primary { background: #bc6a6a; color: white; width: 100%; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 20px rgba(188,106,106,0.4); }
        @media (max-width: 1024px) {
            .staff-grid { grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 25px; }
        }
        @media (max-width: 768px) {
            .content { padding: 40px 15px; }
            .page-title { font-size: 38px; }
            .intro-section { padding: 25px; }
            .intro-section p { font-size: 15px; text-align: left; }
            .members-title { font-size: 30px; margin: 50px 0 35px; }
            .staff-grid { grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px; }
            .staff-card { padding: 25px; }
            .staff-image-wrapper { width: 140px; height: 140px; }
            .admin-add-btn { width: 55px; height: 55px; font-size: 26px; bottom: 20px; right: 20px; }
        }
        @media (max-width: 480px) {
            .content { padding: 30px 10px; }
            .page-title { font-size: 32px; letter-spacing: 1px; }
            .intro-section { padding: 20px; border-radius: 15px; }
            .intro-section p { font-size: 14px; }
            .members-title { font-size: 26px; margin: 40px 0 30px; }
            .staff-grid { grid-template-columns: 1fr; gap: 20px; }
            .staff-card { padding: 25px 20px; }
            .staff-image-wrapper { width: 130px; height: 130px; }
            .admin-add-btn { width: 50px; height: 50px; font-size: 24px; }
        }
    </style>
</head>
<body>

    <div class="content">
        <?php if ($message): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="legal-link">
            <a href="legal.php">Mentions Légales & DMCA</a>
        </div>

        <h1 class="page-title">Notre Histoire</h1>

        <div class="intro-section">
            <p>La Yurei Scan est une jeune équipe de scantrad fondée le 22 juin 2025, dirigée par The Quagmire et soutenue par Moon3554. L'aventure a débuté avec comme premier projet Tonikaku Kawaii, une série qui passionnait tous les membres de l'équipe. À ses débuts, la Yurei Scan comptait sept membres, mais l'équipe s'est vite agrandie pour accueillir de nouveaux passionnés. Nous espérons continuer à accueillir de nouvelles personnes pour enrichir cette belle aventure et, pourquoi pas, explorer encore plus de séries à l'avenir. La sortie de notre premier chapitre, le 11 août 2025, a marqué le début d'une histoire prometteuse, portée par une équipe soudée, motivée et animée par une passion commune pour le manga et l'anime. Tu as envie d'en savoir plus sur ceux qui font vivre cette magnifique équipe ? Découvre dès maintenant chaque membre à part entière de la Yurei Scan !</p>
        </div>

        <h2 class="members-title">Les membres de l'équipe :</h2>

        <div class="staff-grid">
            <?php foreach ($staff_members as $index => $member): ?>
                <div class="staff-card">
                    <?php if ($is_admin): ?>
                        <div class="staff-card-admin">
                            <button class="btn-mini btn-edit" onclick="editMember(<?php echo $index; ?>)" title="Modifier"></button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce membre ?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="index" value="<?php echo $index; ?>">
                                <button type="submit" class="btn-mini btn-delete" title="Supprimer"></button>
                            </form>
                        </div>
                    <?php endif; ?>

                    <div class="staff-image-wrapper">
                        <img src="<?php echo htmlspecialchars($member['image']); ?>" 
                             alt="<?php echo htmlspecialchars($member['name']); ?>" 
                             class="staff-image"
                             onerror="this.src='https://via.placeholder.com/160'">
                    </div>
                    <h3 class="staff-name"><?php echo htmlspecialchars($member['name']); ?></h3>
                    <div class="staff-role">
                            <?php 
                            $roles = explode(', ', $member['roles']);
                            $grouped_roles = array_chunk($roles, 2);
                            foreach ($grouped_roles as $g_index => $group) {
                                echo htmlspecialchars(implode(', ', $group));
                                if ($g_index < count($grouped_roles) - 1) {
                                     echo "<br>";
                                }
                            }
                            ?>
                            <?php if (!empty($member['date'])): ?>
                                <br><span style="font-size:0.9em; opacity:0.8;">Depuis le <?php echo htmlspecialchars($member['date']); ?></span>
                            <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="legal-section-container">
            <h3>Mentions Légales & DMCA</h3>
            <a href="legal.php" class="legal-link-btn">En savoir plus / Contact</a>
        </div>

    </div>

    <?php if ($is_admin): ?>
        <button class="admin-add-btn" onclick="openAddModal()" title="Ajouter un membre">+</button>

        <div id="addModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Ajouter un membre</h2>
                    <button class="close-modal" onclick="closeAddModal()">&times;</button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="form-group">
                        <label>Nom du membre *</label>
                        <input type="text" name="name" required placeholder="Ex: The Quagmire">
                    </div>

                    <div class="form-group">
                        <label>Rôle(s) *</label>
                        <textarea name="roles" required placeholder="Ex: Editeur, Traducteur"></textarea>
                        <small>Séparez les rôles par des virgules</small>
                    </div>

                    <div class="form-group">
                        <label>URL de l'image *</label>
                        <input type="url" name="image" required placeholder="https://i.ibb.co/xxxxxx/image.jpg">
                        <small>Utilisez un lien d'hébergement d'image</small>
                    </div>

                    <div class="form-group">
                        <label>Date d'arrivée</label>
                        <input type="text" name="date" placeholder="Ex: 22/06/25">
                        <small>Format: JJ/MM/AA</small>
                    </div>

                    <button type="submit" class="btn btn-primary">Ajouter le membre</button>
                </form>
            </div>
        </div>

        <div id="editModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Modifier le membre</h2>
                    <button class="close-modal" onclick="closeEditModal()">&times;</button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="index" id="editIndex">
                    
                    <div class="form-group">
                        <label>Nom du membre *</label>
                        <input type="text" name="name" id="editName" required>
                    </div>

                    <div class="form-group">
                        <label>Rôle(s) *</label>
                        <textarea name="roles" id="editRoles" required></textarea>
                    </div>

                    <div class="form-group">
                        <label>URL de l'image *</label>
                        <input type="url" name="image" id="editImage" required>
                    </div>

                    <div class="form-group">
                        <label>Date d'arrivée</label>
                        <input type="text" name="date" id="editDate">
                    </div>

                    <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                </form>
            </div>
        </div>

        <script>
            const members = <?php echo json_encode($staff_members); ?>;

            function openAddModal() {
                document.getElementById('addModal').classList.add('active');
            }

            function closeAddModal() {
                document.getElementById('addModal').classList.remove('active');
            }

            function editMember(index) {
                const member = members[index];
                document.getElementById('editIndex').value = index;
                document.getElementById('editName').value = member.name;
                document.getElementById('editRoles').value = member.roles;
                document.getElementById('editImage').value = member.image;
                document.getElementById('editDate').value = member.date || '';
                document.getElementById('editModal').classList.add('active');
            }

            function closeEditModal() {
                document.getElementById('editModal').classList.remove('active');
            }

            document.getElementById('addModal').addEventListener('click', function(e) {
                if (e.target === this) closeAddModal();
            });

            document.getElementById('editModal').addEventListener('click', function(e) {
                if (e.target === this) closeEditModal();
            });

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeAddModal();
                    closeEditModal();
                }
            });
        </script>
    <?php endif; ?>

    <?php include 'footer.php'; ?>

</body>
</html>