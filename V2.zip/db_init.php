<?php
function initializeDatabase(PDO $db): void
{
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            is_admin TINYINT(1) NOT NULL DEFAULT 0,
            is_staff TINYINT(1) NOT NULL DEFAULT 0,
            avatar VARCHAR(500) DEFAULT NULL,
            banner VARCHAR(500) DEFAULT NULL,
            fav_manga_id INT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS mangas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            summary LONGTEXT DEFAULT NULL,
            image_url VARCHAR(500) DEFAULT NULL,
            is_adult TINYINT(1) NOT NULL DEFAULT 0,
            vertical_only TINYINT(1) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'En cours',
            type VARCHAR(100) DEFAULT NULL,
            author VARCHAR(100) DEFAULT NULL,
            artist VARCHAR(100) DEFAULT NULL,
            genres VARCHAR(255) DEFAULT NULL,
            has_illustration_bonus TINYINT(1) NOT NULL DEFAULT 0,
            is_abandoned TINYINT(1) NOT NULL DEFAULT 0,
            display_order INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS chapters (
            id INT AUTO_INCREMENT PRIMARY KEY,
            manga_id INT NOT NULL,
            chapter_number VARCHAR(50) NOT NULL,
            title VARCHAR(255) DEFAULT NULL,
            views INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_chapter (manga_id, chapter_number),
            INDEX idx_manga_id (manga_id)
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS chapter_pages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            chapter_id INT NOT NULL,
            page_url VARCHAR(500) NOT NULL,
            page_order INT NOT NULL DEFAULT 0,
            INDEX idx_chapter_id (chapter_id)
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS illustrations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            manga_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            link_url VARCHAR(500) DEFAULT NULL,
            caption TEXT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_manga_id (manga_id)
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS manga_ratings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            manga_id INT NOT NULL,
            user_id INT NOT NULL,
            rating INT NOT NULL DEFAULT 5,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_rating (manga_id, user_id),
            INDEX idx_manga_id (manga_id),
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS reading_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            manga_id INT NOT NULL,
            chapter_id INT NOT NULL,
            read_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id),
            INDEX idx_manga_id (manga_id)
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS planning_sorties (
            id INT AUTO_INCREMENT PRIMARY KEY,
            manga_id INT NOT NULL,
            chapter_number VARCHAR(50) DEFAULT NULL,
            jour_semaine VARCHAR(16) DEFAULT NULL,
            heure_sortie VARCHAR(5) DEFAULT NULL,
            date_prevue DATE DEFAULT NULL,
            notes TEXT DEFAULT NULL,
            ordre_affichage INT NOT NULL DEFAULT 0,
            statut VARCHAR(20) NOT NULL DEFAULT 'prevu',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_manga_id (manga_id),
            INDEX idx_date_prevue (date_prevue),
            INDEX idx_statut (statut)
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS profile_avatars (
            id INT AUTO_INCREMENT PRIMARY KEY,
            image_url VARCHAR(500) NOT NULL,
            label VARCHAR(100) DEFAULT '',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS profile_banners (
            id INT AUTO_INCREMENT PRIMARY KEY,
            image_url VARCHAR(500) NOT NULL,
            label VARCHAR(100) DEFAULT '',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $db->exec("CREATE TABLE IF NOT EXISTS carousel_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            image_url VARCHAR(500) NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT DEFAULT NULL,
            link_url VARCHAR(500) DEFAULT NULL,
            display_order INT NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            mob_ox FLOAT NOT NULL DEFAULT 50,
            mob_oy FLOAT NOT NULL DEFAULT 50,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_display_order (display_order),
            INDEX idx_is_active (is_active)
        ) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        addForeignKey($db, 'chapters', 'fk_chapters_manga', 'manga_id', 'mangas', 'id');
        addForeignKey($db, 'chapter_pages', 'fk_chapter_pages_chapter', 'chapter_id', 'chapters', 'id');
        addForeignKey($db, 'illustrations', 'fk_illustrations_manga', 'manga_id', 'mangas', 'id');
        addForeignKey($db, 'manga_ratings', 'fk_ratings_manga', 'manga_id', 'mangas', 'id');
        addForeignKey($db, 'manga_ratings', 'fk_ratings_user', 'user_id', 'users', 'id');
        addForeignKey($db, 'reading_history', 'fk_reading_history_user', 'user_id', 'users', 'id');
        addForeignKey($db, 'reading_history', 'fk_reading_history_manga', 'manga_id', 'mangas', 'id');
        addForeignKey($db, 'reading_history', 'fk_reading_history_chapter', 'chapter_id', 'chapters', 'id');
        addForeignKey($db, 'planning_sorties', 'fk_planning_sorties_manga', 'manga_id', 'mangas', 'id');
        addForeignKey($db, 'users', 'fk_users_fav_manga', 'fav_manga_id', 'mangas', 'id');
    } catch (PDOException $e) {
        error_log('DB init error: ' . $e->getMessage());
    }
}

function addForeignKey(PDO $db, string $table, string $constraintName, string $column, string $refTable, string $refColumn): void
{
    try {
        $db->exec(
            "ALTER TABLE `$table` ADD CONSTRAINT `$constraintName` FOREIGN KEY (`$column`) REFERENCES `$refTable`(`$refColumn`) ON DELETE CASCADE ON UPDATE CASCADE"
        );
    } catch (PDOException $e) {
    }
}