<?php
require_once 'check_captcha.php';
require_once 'db.php';

function esc($value, $default = '') {
    return htmlspecialchars($value ?? $default, ENT_QUOTES, 'UTF-8');
}

function formatChapterNumber($chapter_number) {
    if (!is_numeric($chapter_number)) {
        return esc($chapter_number);
    }
    $cnf = (float)$chapter_number;
    if (floor($cnf) == $cnf) {
        return (int)$cnf;
    }
    return (string)$chapter_number;
}

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$manga_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$chapter_id = isset($_GET['chapter_id']) ? (int)$_GET['chapter_id'] : 0;

try {
    if (
        $_SERVER['REQUEST_METHOD'] === 'POST' &&
        isset($_POST['action'], $_POST['csrf_token']) &&
        $_POST['action'] === 'update_page_order'
    ) {
        if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            echo json_encode(['success' => false, 'error' => 'Jeton CSRF invalide']);
            exit;
        }

        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            echo json_encode(['success' => false, 'error' => 'Accès interdit']);
            exit;
        }

        $order_data = json_decode($_POST['order_data'], true);
        
        if (is_array($order_data)) {
            $db->beginTransaction();
            
            $stmt = $db->prepare("UPDATE chapter_pages SET page_order = ? WHERE id = ? AND chapter_id = ?");
            foreach ($order_data as $item) {
                $stmt->execute([$item['order'], $item['id'], $chapter_id]);
            }
            
            $db->commit();
            echo json_encode(['success' => true]);
            exit;
        }
    }

    if (
        $_SERVER['REQUEST_METHOD'] === 'POST' &&
        isset($_POST['action'], $_POST['page_id'], $_POST['csrf_token']) &&
        $_POST['action'] === 'delete_page'
    ) {
        if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            die("Jeton CSRF invalide.");
        }

        if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
            die("Accès interdit.");
        }

        $page_id = (int)$_POST['page_id'];
        $stmt = $db->prepare("DELETE FROM chapter_pages WHERE id = ? AND chapter_id = ?");
        $stmt->execute([$page_id, $chapter_id]);

        header("Location: chapter.php?id=$manga_id&chapter_id=$chapter_id");
        exit();
    }

    try {
        $db->exec("ALTER TABLE chapter_pages ADD COLUMN IF NOT EXISTS page_order INT DEFAULT 0");
    } catch (PDOException $e) {
    }

    $stmt = $db->prepare("
        SELECT c.*, m.title AS manga_title, m.vertical_only, COALESCE(c.views, 0) as views
        FROM chapters c
        JOIN mangas m ON c.manga_id = m.id
        WHERE c.id = ? AND c.manga_id = ?
    ");
    $stmt->execute([$chapter_id, $manga_id]);
    $chapter = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$chapter) {
        die("Chapitre non trouvé.");
    }

    $stmt = $db->prepare("SELECT image_url, summary FROM mangas WHERE id = ?");
    $stmt->execute([$manga_id]);
    $manga = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("SELECT id, page_url FROM chapter_pages WHERE chapter_id = ? ORDER BY page_order ASC, id ASC");
    $stmt->execute([$chapter_id]);
    $pages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("
        SELECT id
        FROM chapters
        WHERE manga_id = ? AND chapter_number > ? 
        ORDER BY chapter_number ASC
        LIMIT 1
    ");
    $stmt->execute([$manga_id, $chapter['chapter_number']]);
    $next_chapter = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("
        SELECT id
        FROM chapters
        WHERE manga_id = ? AND chapter_number < ? 
        ORDER BY chapter_number DESC
        LIMIT 1
    ");
    $stmt->execute([$manga_id, $chapter['chapter_number']]);
    $previous_chapter = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("
        SELECT id, chapter_number, title
        FROM chapters
        WHERE manga_id = ?
        ORDER BY chapter_number ASC
    ");
    $stmt->execute([$manga_id]);
    $all_chapters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($_SESSION['user_id'])) {
        try {
            $stmt = $db->prepare("
                INSERT INTO reading_history (user_id, manga_id, chapter_id, read_at)
                VALUES (?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE chapter_id = VALUES(chapter_id), read_at = NOW()
            ");
            $stmt->execute([$_SESSION['user_id'], $manga_id, $chapter_id]);
        } catch (PDOException $e) {
        }
    }

} catch (PDOException $e) {
    die("Erreur : " . esc($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://i.ibb.co/LdCC28Wk/logo-site.png">
    <title>Chapitre <?php echo formatChapterNumber($chapter['chapter_number']); ?> - <?php echo esc($chapter['manga_title']); ?> - Yurei Scan</title>

    <meta name="description" content="Lisez le chapitre <?php echo esc($chapter['chapter_number']); ?> de <?php echo esc($chapter['manga_title']); ?> sur Yurei Scan.">
    <meta property="og:type" content="article">
    <meta property="og:url" content="<?php echo 'https://yurei-scan.fr/chapter.php?id=' . $manga_id . '&chapter_id=' . $chapter_id; ?>">
    <meta property="og:title" content="Chapitre <?php echo formatChapterNumber($chapter['chapter_number']); ?><?php echo !empty($chapter['title']) ? ' - ' . esc($chapter['title']) : ''; ?> | <?php echo esc($chapter['manga_title']); ?>">
    <meta property="og:description" content="<?php
        $og_desc = 'Lisez le chapitre ' . esc($chapter['chapter_number']) . ' de ' . esc($chapter['manga_title']) . ' sur Yurei Scan.';
        if (!empty($manga['summary'])) {
            $og_desc = mb_substr(strip_tags($manga['summary']), 0, 160) . '...';
        }
        echo $og_desc;
    ?>">
    <meta property="og:site_name" content="Yurei Scan">
    <meta property="og:locale" content="fr_FR">
    <?php
        $og_image_chapter = !empty($pages[0]['page_url'])
            ? esc($pages[0]['page_url'])
            : esc($manga['image_url'] ?? 'https://i.ibb.co/4Rkrk8bg/81-K7kn-G8-OCL-SY466.jpg');
    ?>
    <meta property="og:image" content="<?php echo $og_image_chapter; ?>">
    <meta property="og:image:alt" content="Chapitre <?php echo esc($chapter['chapter_number']); ?> de <?php echo esc($chapter['manga_title']); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@YureiScan">
    <meta name="twitter:title" content="Chapitre <?php echo formatChapterNumber($chapter['chapter_number']); ?> | <?php echo esc($chapter['manga_title']); ?>">
    <meta name="twitter:description" content="<?php echo $og_desc; ?>">
    <meta name="twitter:image" content="<?php echo $og_image_chapter; ?>">
    <meta name="twitter:image:alt" content="Chapitre <?php echo esc($chapter['chapter_number']); ?> de <?php echo esc($chapter['manga_title']); ?>">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        ::selection {
            background-color: #667eea;
            color: #fff;
        }

        ::-moz-selection {
            background-color: #667eea;
            color: #fff;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #000;
            color: #fff;
            line-height: 1.6;
            min-height: 100vh;
        }

        .reader-header, .reader-footer {
            background: #000;
            padding: 16px 24px;
            position: relative;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 900;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        /* announce popup must always be above the reader */
        .announce-popup { z-index: 9999 !important; }
        .announce-diamond-wrap, .announce-diamond-wrap-mobile { z-index: 9998 !important; position: relative; }

        .reader-header {
            border-bottom: 2px solid #bc6a6a;
            margin-bottom: 20px;
        }

        .reader-footer {
            border-top: 2px solid #bc6a6a;
            margin-top: 0;
            padding-bottom: 0;
        }

        .footer-copyright {
            text-align: center;
            padding: 15px 20px;
            margin-top: 15px;
            color: rgb(255, 255, 255);
            font-size: 13px;
        }

        /* Cacher le footer PHP sur cette page */
        body > footer,
        body > .footer {
            color: white !important;
            display: none !important;
        }

        .reader-header:hover, .reader-footer:hover {
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.6), 0 0 50px rgba(188, 106, 106, 0.15);
        }

        .reader-header-content, .reader-footer-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
            max-width: 1400px;
            margin: 0 auto;
        }

        .header-left, .header-center, .header-right {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .header-right {
            margin-left: auto;
        }

        .header-center {
            flex-grow: 1;
            justify-content: center;
        }

        .back-arrow {
            background: transparent;
            color: white;
            border: 2px solid #bc6a6a;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 20px;
            font-weight: bold;
            padding: 0;
            padding-bottom: 4px;
        }

        .back-arrow:hover {
            background: rgba(188, 106, 106, 0.1);
            border-color: #bc6a6a;
            transform: translateY(-1px);
        }

        .header-dropdown {
            background: transparent;
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
            padding: 8px 14px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 140px; /* Desktop seulement, écrasé en mobile */
        }

        .header-dropdown:hover, .header-dropdown:focus {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.5);
            transform: translateY(-1px);
        }

        .header-dropdown:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .header-dropdown:disabled:hover {
            transform: none;
            background: rgba(255, 255, 255, 0.05);
        }

        .header-dropdown option {
            background: #000;
            color: white;
            padding: 8px;
        }

        .header-dropdown option:checked {
            background: #bc6a6a;
            color: white;
            font-weight: 700;
        }

        .chapter-title-header {
            font-size: 15px;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            cursor: default;
            transition: all 0.3s ease;
            line-height: 1.4;
            max-width: 350px;
            text-align: center;
            filter: drop-shadow(0 0 10px rgba(102, 126, 234, 0.4));
            padding: 4px 8px;
            position: relative;
        }

        .page-counter {
            color: #bc6a6a;
            font-weight: 800;
            min-width: 60px;
            text-align: center;
            font-size: 13px;
            padding: 4px 10px;
            border-radius: 8px;
        }

        .nav-buttons-header {
            display: flex;
            gap: 10px;
        }

        .nav-btn {
            background: transparent;
            color: #bc6a6a;
            border: 2px solid #bc6a6a;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 700;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .nav-btn:hover {
            background: rgba(188, 106, 106, 0.1);
            border-color: #bc6a6a;
            transform: translateY(-3px);
        }

        .nav-btn:active {
            transform: translateY(0px);
        }

        .nav-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
            transform: none;
        }

        .content {
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        /* En-tête du chapitre */
        .chapter-header {
            text-align: center;
            margin-bottom: 40px;
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 8px 32px rgba(0,0,0,0.4);
            display: none;
        }

        .chapter-title {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 15px;
            line-height: 1.3;
        }

        .chapter-info {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 15px;
            font-size: 14px;
            color: #999;
        }

        .drag-instruction {
            background: rgba(102, 126, 234, 0.1);
            border: 1px solid rgba(102, 126, 234, 0.3);
            color: #667eea;
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 14px;
            margin: 20px 0;
            text-align: center;
        }

        .pages-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0;
            margin-bottom: 40px;
        }

        .pages-container.page-mode .page-wrapper { display: none; }
        .pages-container.page-mode .page-wrapper.active { display: block; }

        .page-wrapper {
            width: 100%;
            max-width: 800px;
            min-height: 60px;
            position: relative;
            margin-bottom: 0;
            transition: opacity 0.3s ease;
        }

        .page-wrapper.draggable { cursor: move; }
        .page-wrapper.dragging  { opacity: 0.5; }

        .page-image {
            width: 100%;
            min-height: 60px;
            height: auto;
            display: block;
            background: #000;
            user-select: none;
        }

        .page-image[data-error="true"] {
            opacity: 0.5;
            filter: grayscale(1);
            min-height: 200px;
        }

        .drag-handle {
            position: absolute;
            top: 10px; left: 10px;
            background: rgba(102, 126, 234, 0.9);
            color: white;
            width: 40px; height: 40px;
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px; z-index: 10; cursor: grab;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .drag-handle:active { cursor: grabbing; }
        .drag-handle:hover  { background: rgba(102, 126, 234, 1); transform: scale(1.1); }

        .delete-page-btn {
            position: absolute;
            top: 10px; right: 10px;
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white; border: none;
            padding: 8px 16px; border-radius: 10px;
            font-size: 12px; font-weight: 600;
            cursor: pointer; z-index: 10;
            box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);
            transition: all 0.3s ease;
        }

        .delete-page-btn:hover { transform: translateY(-2px); }

        .page-number {
            position: absolute;
            bottom: 10px; left: 10px;
            background: rgba(0, 0, 0, 0.8);
            color: white; padding: 6px 12px;
            border-radius: 8px; font-size: 12px; font-weight: 600; z-index: 10;
        }

        .empty-message {
            text-align: center; padding: 60px 20px;
            background: rgba(231, 76, 60, 0.1);
            border-radius: 15px;
            border: 1px solid rgba(231, 76, 60, 0.3);
            color: #ff6b6b; font-size: 16px;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 15px; flex-wrap: wrap;
            margin-top: 30px;
        }

        .btn {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 12px 24px; border-radius: 12px;
            font-size: 15px; font-weight: 600;
            text-decoration: none; border: none;
            cursor: pointer; transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6); }

        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white; box-shadow: 0 4px 15px rgba(40, 167, 69, 0.4);
        }
        .btn-success:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(40, 167, 69, 0.6); }

        .scroll-to-top, .scroll-to-bottom {
            position: fixed; bottom: 30px;
            width: 50px; height: 50px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; opacity: 0; visibility: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3); z-index: 1000;
        }

        .scroll-to-top { right: 30px; background: #bc6a6a; }
        .scroll-to-top.show, .scroll-to-bottom.show { opacity: 1; visibility: visible; }
        .scroll-to-top:hover  { background: #a85c5c; transform: translateY(-2px); }
        .scroll-to-top::before  { content: '\2191'; font-size: 24px; color: #fff; font-weight: bold; }

        .scroll-to-bottom { right: 90px; background: rgba(40, 167, 69, 0.5); }
        .scroll-to-bottom:hover  { background: rgba(40, 167, 69, 0.7); transform: translateY(2px); }
        .scroll-to-bottom::before { content: '\2193'; font-size: 24px; color: #fff; font-weight: bold; }

        .notification {
            position: fixed; top: 20px; right: 20px;
            background: rgba(40, 167, 69, 0.95); color: white;
            padding: 15px 25px; border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            z-index: 9999; animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateX(100px); }
            to   { opacity: 1; transform: translateX(0); }
        }

        .thumbs-container {
            position: fixed; right: 20px; top: 140px;
            width: 120px; max-height: calc(100vh - 180px);
            overflow-y: auto; display: flex; flex-direction: column;
            gap: 10px; z-index: 900; padding: 8px;
        }

        .thumb-item {
            background: rgba(255,255,255,0.03); padding: 6px;
            border-radius: 8px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
            border: 1px solid rgba(255,255,255,0.04);
        }

        .thumb-item img { width: 100%; height: auto; display: block; object-fit: cover; border-radius: 4px; }
        .thumb-item.drag-over { box-shadow: 0 0 0 3px rgba(102,126,234,0.25); transform: translateY(-3px); }
        .page-wrapper.selected { outline: 3px solid rgba(32,201,151,0.9); outline-offset: 4px; }

        .click-zones {
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            pointer-events: none; z-index: 50;
        }

        .click-zone {
            position: absolute; top: 0;
            width: 25%; height: 100%;
            cursor: pointer; pointer-events: auto;
        }

        .click-zone.left  { left: 0; }
        .click-zone.right { right: 0; }


        html, body { overflow-x: hidden; }


        /* ── DESKTOP : row-top/row-bottom invisibles, anciens éléments visibles ── */
        @media (min-width: 769px) {
            .row-top, .row-bottom { display: none; }
            .reader-header, .reader-footer { padding: 16px 24px; }
            .reader-header-content, .reader-footer-content {
                display: flex;
                flex-direction: row;
                flex-wrap: wrap;
                align-items: center;
                justify-content: space-between;
                gap: 15px;
            }
            .header-left  { display: flex; }
            .header-right { display: flex; margin-left: auto; }
            .nav-buttons-header { display: flex; gap: 10px; }
            .header-center { display: flex; flex-grow: 1; justify-content: center; }
            .footer-copyright { font-size: 13px; padding: 15px 20px; margin-top: 15px; }
        }

        @media (max-width: 968px) and (min-width: 769px) {
            .reader-header, .reader-footer { padding: 12px 16px; }
            .header-dropdown { min-width: 100px; font-size: 12px; padding: 6px 10px; }
            .nav-btn { padding: 6px 12px; font-size: 12px; }
        }

        /* ── MOBILE : 2 lignes compactes, anciens éléments cachés ── */
        @media (max-width: 768px) {
            .scroll-to-top { display: none !important; }

            .header-left, .header-right,
            .nav-buttons-header, .header-center { display: none !important; }

            .row-top, .row-bottom {
                display: flex;
                align-items: center;
                width: 100%;
                box-sizing: border-box;
                overflow: hidden;
            }

            .reader-header, .reader-footer { padding: 0; overflow: hidden; }
            .reader-header-content, .reader-footer-content {
                display: flex;
                flex-direction: column;
                width: 100%;
            }

            .row-top {
                gap: 6px;
                padding: 1px 10px 2px;
                border-bottom: 1px solid rgba(255,255,255,0.07);
            }

            .row-bottom {
                gap: 0;
                padding: 1px 8px 4px;
            }

            .row-top .back-arrow {
                width: 30px; height: 30px;
                font-size: 14px;
                flex-shrink: 0; min-width: 30px;
            }

            .row-top .header-dropdown,
            .row-bottom .header-dropdown { min-width: 0; }

            .sel-chapter {
                flex: 1; min-width: 0;
                font-size: 11px; padding: 5px 5px;
            }

            .sel-mode {
                flex-shrink: 0; width: 92px;
                font-size: 11px; padding: 5px 5px;
            }

            .nav-prev, .nav-next {
                flex-shrink: 0;
                font-size: 11px; padding: 5px 8px;
                white-space: nowrap; border-radius: 8px;
            }

            .page-info {
                flex: 1; min-width: 0;
                display: flex; align-items: center;
                justify-content: center; gap: 0;
                overflow: hidden;
            }

            /* Affichage "X / N" : le select est invisible, le span par-dessus */
            .page-display {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .page-display-label {
                font-size: 12px;
                font-weight: 700;
                color: #fff;
                border: 2px solid #bc6a6a;
                border-radius: 8px;
                padding: 4px 10px;
                pointer-events: none;
                white-space: nowrap;
                background: transparent;
            }

            .page-display-label span {
                color: #bc6a6a;
            }

            .sel-page {
                position: absolute;
                top: 0; left: 0;
                width: 100%; height: 100%;
                opacity: 0;
                cursor: pointer;
                font-size: 11px;
                min-width: 0;
            }

            .page-info .page-counter { display: none; }

            .footer-copyright {
                font-size: 12px;
                padding: 6px 10px 10px;
                margin-top: 2px;
            }
        }

        @media (max-width: 400px) {
            .nav-prev, .nav-next { font-size: 10px; padding: 4px 6px; }
            .sel-mode { width: 82px; }
            .page-display-label { font-size: 11px; padding: 3px 8px; }
        }

        @media (max-width: 360px) {
            .nav-prev, .nav-next { font-size: 9px; padding: 4px 4px; }
            .page-display-label { font-size: 10px; padding: 3px 6px; }
        }

        @media (max-width: 1000px) { .thumbs-container { display: none; } }

        /* Progress Bar */
        #readingProgressBar {
            position: fixed;
            top: 0;
            left: 0;
            height: 3px;
            background-color: #bc6a6a;
            z-index: 10000;
            width: 0%;
            transition: width 0.1s ease;
        }
    </style>
</head>
<?php include 'header.php'; ?>
<div id="readingProgressBar"></div>
<body>
    <!-- Header de lecture -->
    <div class="reader-header" id="readerHeader">
        <div class="reader-header-content">

            <!-- MOBILE : 2 lignes compactes -->
            <div class="row-top">
                <a href="manga.php?id=<?php echo $manga_id; ?>" class="back-arrow" title="Retour au manga">←</a>
                <select class="header-dropdown sel-chapter" id="chapterSelectM" onchange="changeChapter(this.value)">
                    <?php foreach ($all_chapters as $ch): ?>
                        <option value="<?php echo $ch['id']; ?>" <?php echo ($ch['id'] == $chapter_id) ? 'selected' : ''; ?>>
                            Chap <?php echo formatChapterNumber($ch['chapter_number']); ?> : <?php echo esc(substr($ch['title'], 0, 30)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select class="header-dropdown sel-mode" id="modeSelectM" onchange="changeReadMode(this.value)" <?php echo !empty($chapter['vertical_only']) ? 'disabled' : ''; ?>>
                    <option value="vertical">Vertical</option>
                    <option value="page">Page par Page</option>
                </select>
            </div>
            <div class="row-bottom">
                <?php if ($previous_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $previous_chapter['id']; ?>" class="nav-btn nav-prev">← Chapitre précédent</a>
                <?php else: ?>
                    <button class="nav-btn nav-prev" disabled>← Chapitre précédent</button>
                <?php endif; ?>
                <div class="page-info">
                    <div class="page-display">
                        <div class="page-display-label" id="pageDisplayM">
                            <span id="pageNumM">1</span> / <?php echo count($pages); ?>
                        </div>
                        <select class="sel-page" id="pageSelectM" onchange="goToPage(parseInt(this.value))">
                            <?php foreach ($pages as $idx => $p): ?>
                                <option value="<?php echo $idx; ?>"><?php echo $idx + 1; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php if ($next_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $next_chapter['id']; ?>" class="nav-btn nav-next">Chapitre suivant →</a>
                <?php else: ?>
                    <button class="nav-btn nav-next" disabled>Chapitre suivant →</button>
                <?php endif; ?>
            </div>

            <!-- DESKTOP : layout original -->
            <div class="header-left">
                <a href="manga.php?id=<?php echo $manga_id; ?>" class="back-arrow" title="Retour au manga">←</a>
                <select class="header-dropdown" id="chapterSelect" onchange="changeChapter(this.value)">
                    <?php foreach ($all_chapters as $ch): ?>
                        <option value="<?php echo $ch['id']; ?>" <?php echo ($ch['id'] == $chapter_id) ? 'selected' : ''; ?>>
                            Chap <?php echo formatChapterNumber($ch['chapter_number']); ?> : <?php echo esc(substr($ch['title'], 0, 30)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select class="header-dropdown" id="modeSelect" onchange="changeReadMode(this.value)" <?php echo !empty($chapter['vertical_only']) ? 'disabled' : ''; ?>>
                    <option value="vertical">Vertical</option>
                    <option value="page">Page par Page</option>
                </select>
            </div>
            <div class="header-right">
                <span class="page-counter" id="pageCounter">1/<?php echo count($pages); ?></span>
                <select class="header-dropdown" id="pageSelect" onchange="goToPage(parseInt(this.value))">
                    <?php foreach ($pages as $idx => $p): ?>
                        <option value="<?php echo $idx; ?>">Page <?php echo $idx + 1; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="nav-buttons-header">
                <?php if ($previous_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $previous_chapter['id']; ?>" class="nav-btn">← Chapitre précédent</a>
                <?php else: ?>
                    <button class="nav-btn" disabled>← Chapitre précédent</button>
                <?php endif; ?>
                <?php if ($next_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $next_chapter['id']; ?>" class="nav-btn">Chapitre suivant →</a>
                <?php else: ?>
                    <button class="nav-btn" disabled>Chapitre suivant →</button>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <div class="content">
        <div class="chapter-header">
            <h1 class="chapter-title">
                <?php echo esc($chapter['manga_title']); ?> - 
                Chapitre <?php echo formatChapterNumber($chapter['chapter_number']); ?> :
                <?php echo esc($chapter['title']); ?>
            </h1>

            <div class="action-buttons">
                <?php if (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                    <a href="add_page.php?manga_id=<?php echo $manga_id; ?>&chapter_id=<?php echo $chapter_id; ?>"
                       class="btn btn-success">Ajouter une page</a>
                <?php endif; ?>

                <a href="manga.php?id=<?php echo $manga_id; ?>" class="btn btn-primary">Retour au manga</a>

                <?php if ($previous_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $previous_chapter['id']; ?>"
                       class="btn btn-success">Chapitre précédent</a>
                <?php endif; ?>

                <?php if ($next_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $next_chapter['id']; ?>"
                       class="btn btn-success">Chapitre suivant</a>
                <?php endif; ?>
            </div>

            <div class="chapter-info">
                <span>Publié le <?php echo date('d/m/Y', strtotime($chapter['created_at'])); ?></span>
            </div>
        </div>

        <?php if ($pages): ?>
            <div class="pages-container" id="pagesContainer">
                <?php foreach ($pages as $index => $page): ?>
                    <div class="page-wrapper <?php echo (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) ? 'draggable' : ''; ?>" 
                         data-id="<?php echo $page['id']; ?>"
                         <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                         draggable="true"
                         <?php endif; ?>>
                        
                        <?php if (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                            <div class="drag-handle">☰</div>
                            <div class="page-number">Page <?php echo $index + 1; ?></div>
                        <?php endif; ?>
                        
                        <img data-src="<?php echo esc($page['page_url']); ?>"
                             alt="Page <?php echo $index + 1; ?>"
                             class="page-image"
                             decoding="async"
                             onerror="this.setAttribute('data-error', 'true'); this.title='Erreur de chargement';">
                        
                        <?php if (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="page_id" value="<?php echo $page['id']; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <button type="submit" name="action" value="delete_page" class="delete-page-btn"
                                        onclick="return confirm('Voulez-vous vraiment supprimer cette page ?');">
                                    Supprimer
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-message">
                Aucune page disponible pour ce chapitre.
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1 && !empty($pages)): ?>
            <div class="thumbs-container" id="thumbsContainer" aria-hidden="false">
                <?php foreach ($pages as $idx => $page): ?>
                    <div class="thumb-item" data-id="<?php echo $page['id']; ?>" data-index="<?php echo $idx; ?>"
                         title="Insérer avant la page <?php echo $idx + 1; ?>">
                        <img src="<?php echo esc($page['page_url']); ?>" alt="Miniature page <?php echo $idx + 1; ?>" loading="lazy">
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="reader-footer" id="readerFooter">
        <div class="reader-footer-content">

            <div class="row-top">
                <a href="manga.php?id=<?php echo $manga_id; ?>" class="back-arrow" title="Retour au manga">←</a>
                <select class="header-dropdown sel-chapter" id="chapterSelect2M" onchange="changeChapter(this.value)">
                    <?php foreach ($all_chapters as $ch): ?>
                        <option value="<?php echo $ch['id']; ?>" <?php echo ($ch['id'] == $chapter_id) ? 'selected' : ''; ?>>
                            Chap <?php echo formatChapterNumber($ch['chapter_number']); ?> : <?php echo esc(substr($ch['title'], 0, 30)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select class="header-dropdown sel-mode" id="modeSelect2M" onchange="changeReadMode(this.value)" <?php echo !empty($chapter['vertical_only']) ? 'disabled' : ''; ?>>
                    <option value="vertical">Vertical</option>
                    <option value="page">Page par Page</option>
                </select>
            </div>
            <div class="row-bottom">
                <?php if ($previous_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $previous_chapter['id']; ?>" class="nav-btn nav-prev">← Chapitre précédent</a>
                <?php else: ?>
                    <button class="nav-btn nav-prev" disabled>← Chapitre précédent</button>
                <?php endif; ?>
                <div class="page-info">
                    <div class="page-display">
                        <div class="page-display-label" id="pageDisplayM2">
                            <span id="pageNumM2">1</span> / <?php echo count($pages); ?>
                        </div>
                        <select class="sel-page" id="pageSelectM2" onchange="goToPage(parseInt(this.value))">
                            <?php foreach ($pages as $idx => $p): ?>
                                <option value="<?php echo $idx; ?>"><?php echo $idx + 1; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php if ($next_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $next_chapter['id']; ?>" class="nav-btn nav-next">Chapitre suivant →</a>
                <?php else: ?>
                    <button class="nav-btn nav-next" disabled>Chapitre suivant →</button>
                <?php endif; ?>
            </div>

            <div class="header-left">
                <a href="manga.php?id=<?php echo $manga_id; ?>" class="back-arrow" title="Retour au manga">←</a>
                <select class="header-dropdown" id="chapterSelect2" onchange="changeChapter(this.value)">
                    <?php foreach ($all_chapters as $ch): ?>
                        <option value="<?php echo $ch['id']; ?>" <?php echo ($ch['id'] == $chapter_id) ? 'selected' : ''; ?>>
                            Chap <?php echo formatChapterNumber($ch['chapter_number']); ?> : <?php echo esc(substr($ch['title'], 0, 30)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select class="header-dropdown" id="modeSelect2" onchange="changeReadMode(this.value)" <?php echo !empty($chapter['vertical_only']) ? 'disabled' : ''; ?>>
                    <option value="vertical">Vertical</option>
                    <option value="page">Page par Page</option>
                </select>
            </div>
            <div class="header-right">
                <span class="page-counter" id="pageCounter2">1/<?php echo count($pages); ?></span>
                <select class="header-dropdown" id="pageSelect2" onchange="goToPage(parseInt(this.value))">
                    <?php foreach ($pages as $idx => $p): ?>
                        <option value="<?php echo $idx; ?>">Page <?php echo $idx + 1; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="nav-buttons-header">
                <?php if ($previous_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $previous_chapter['id']; ?>" class="nav-btn">← Chapitre précédent</a>
                <?php else: ?>
                    <button class="nav-btn" disabled>← Chapitre précédent</button>
                <?php endif; ?>
                <?php if ($next_chapter): ?>
                    <a href="chapter.php?id=<?php echo $manga_id; ?>&chapter_id=<?php echo $next_chapter['id']; ?>" class="nav-btn">Chapitre suivant →</a>
                <?php else: ?>
                    <button class="nav-btn" disabled>Chapitre suivant →</button>
                <?php endif; ?>
            </div>

        </div>
        
        <div class="footer-copyright">
            © 2026 Yurei Scan. Tous droits réservés.
        </div>
    </div>

    <div class="scroll-to-top" id="scrollToTop"></div>

    <?php if (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
        <div class="scroll-to-bottom" id="scrollToBottom"></div>
    <?php endif; ?>

    <div class="click-zones" id="clickZones">
        <div class="click-zone left"  onclick="previousPage()"></div>
        <div class="click-zone right" onclick="nextPage()"></div>
    </div>

    <script>
        let viewTracked = false;
        let currentPageIndex = 0;
        let readMode = 'vertical';
        const chapterId  = <?php echo $chapter_id; ?>;
        const mangaId    = <?php echo $manga_id; ?>;
        const totalPages = <?php echo count($pages); ?>;
        const verticalOnly = <?php echo !empty($chapter['vertical_only']) ? 'true' : 'false'; ?>;

        (function loadPagesInOrder() {
            const images = Array.from(document.querySelectorAll('.page-image[data-src]'));
            let i = 0;
            function loadNext() {
                if (i >= images.length) return;
                const img = images[i];
                i++;
                img.addEventListener('load', loadNext, { once: true });
                img.addEventListener('error', loadNext, { once: true });
                img.src = img.dataset.src;
            }
            loadNext();
        })();

        function initializeReadMode() {
            const saved = localStorage.getItem('readMode');
            if (verticalOnly) {
                readMode = 'vertical';
            } else if (saved) {
                readMode = saved;
            }
            ['modeSelect','modeSelect2','modeSelectM','modeSelect2M'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = readMode;
            });
            applyReadMode();
        }

        function changeReadMode(mode) {
            if (verticalOnly) {
                readMode = 'vertical';
                return;
            }
            readMode = mode;
            localStorage.setItem('readMode', mode);
            ['modeSelect','modeSelect2','modeSelectM','modeSelect2M'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = mode;
            });
            applyReadMode();
        }

        function applyReadMode() {
            const container = document.getElementById('pagesContainer');
            if (!container) return;
            if (readMode === 'page') {
                container.classList.add('page-mode');
                currentPageIndex = 0;
                showCurrentPage();
                document.getElementById('clickZones').style.display = 'block';
                window.scrollTo({ top: 0 });
            } else {
                container.classList.remove('page-mode');
                document.getElementById('clickZones').style.display = 'none';
            }
        }

        function showCurrentPage() {
            document.querySelectorAll('.page-wrapper').forEach((w, i) => {
                w.classList.toggle('active', i === currentPageIndex);
            });
            updatePageCounter();
            ['pageSelect','pageSelect2','pageSelectM','pageSelectM2'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = currentPageIndex;
            });
            updatePageCounter();
            window.scrollTo({ top: 0 });
        }

        function updatePageCounter() {
            const current = currentPageIndex + 1;
            const pc = document.getElementById('pageCounter');
            if (pc) pc.textContent = current + '/' + totalPages;
            const pc2 = document.getElementById('pageCounter2');
            if (pc2) pc2.textContent = current + '/' + totalPages;
            ['pageNumM','pageNumM2'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.textContent = current;
            });
            ['pageSelect','pageSelect2'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = currentPageIndex;
            });
        }

        function goToPage(pageIndex) {
            if (pageIndex < 0 || pageIndex >= totalPages) return;
            currentPageIndex = pageIndex;
            if (readMode === 'page') {
                showCurrentPage();
            } else {
                const wrappers = document.querySelectorAll('.page-wrapper');
                if (wrappers[pageIndex]) {
                    wrappers[pageIndex].scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        }

        function nextPage() {
            if (readMode === 'page' && currentPageIndex < totalPages - 1) {
                currentPageIndex++;
                showCurrentPage();
                window.scrollTo({ top: 0 });
            }
        }

        function previousPage() {
            if (readMode === 'page' && currentPageIndex > 0) {
                currentPageIndex--;
                showCurrentPage();
                window.scrollTo({ top: 0 });
            }
        }

        function changeChapter(chapterId) {
            if (chapterId) window.location.href = 'chapter.php?id=' + mangaId + '&chapter_id=' + chapterId;
        }

        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowRight') nextPage();
            if (e.key === 'ArrowLeft')  previousPage();
        });

        function isScrolledToBottom() {
            return (window.innerHeight + window.scrollY) >= document.documentElement.scrollHeight * 0.95;
        }

        function trackView() {
            if (viewTracked || chapterId === 0) return;
            fetch('setters/track_view.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chapter_id: chapterId })
            })
            .then(r => r.json())
            .then(d => { if (d.success) { viewTracked = true; } })
            .catch(err => console.error('Erreur:', err));
        }

        window.addEventListener('scroll', () => { if (isScrolledToBottom() && !viewTracked) trackView(); });
        window.addEventListener('load', () => {
            if (isScrolledToBottom() && !viewTracked) trackView();
            initializeReadMode();
        });

        const scrollToTopBtn = document.getElementById('scrollToTop');
        function toggleScrollToTopButton() {
            if (window.innerWidth <= 768) { scrollToTopBtn.classList.remove('show'); return; }
            scrollToTopBtn.classList.toggle('show', window.scrollY > 300);
        }
        scrollToTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
        window.addEventListener('scroll', toggleScrollToTopButton);
        document.addEventListener('DOMContentLoaded', toggleScrollToTopButton);

        const scrollToBottomBtn = document.getElementById('scrollToBottom');
        if (scrollToBottomBtn) {
            function toggleScrollToBottomButton() {
                const atBottom = window.scrollY >= document.documentElement.scrollHeight - window.innerHeight - 300;
                scrollToBottomBtn.classList.toggle('show', !atBottom);
            }
            scrollToBottomBtn.addEventListener('click', () => {
                window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
            });
            window.addEventListener('scroll', toggleScrollToBottomButton);
            document.addEventListener('DOMContentLoaded', toggleScrollToBottomButton);
        }

        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
        const pagesContainer = document.getElementById('pagesContainer');
        if (pagesContainer) {
            let draggedElement = null;

            pagesContainer.addEventListener('dragstart', (e) => {
                const wrapper = e.target.closest('.page-wrapper');
                if (wrapper && wrapper.classList.contains('draggable')) {
                    draggedElement = wrapper;
                    wrapper.classList.add('dragging');
                }
            });

            pagesContainer.addEventListener('dragend', (e) => {
                const wrapper = e.target.closest('.page-wrapper');
                if (wrapper) {
                    wrapper.classList.remove('dragging');
                    draggedElement = null;
                    savePageOrder();
                }
            });

            pagesContainer.addEventListener('dragover', (e) => {
                e.preventDefault();
                const afterElement = getDragAfterElement(pagesContainer, e.clientY);
                const draggable = document.querySelector('.dragging');
                if (draggable && afterElement == null) {
                    pagesContainer.appendChild(draggable);
                } else if (draggable && afterElement) {
                    pagesContainer.insertBefore(draggable, afterElement);
                }
            });

            function getDragAfterElement(container, y) {
                const els = [...container.querySelectorAll('.page-wrapper:not(.dragging)')];
                return els.reduce((closest, child) => {
                    const box = child.getBoundingClientRect();
                    const offset = y - box.top - box.height / 2;
                    return (offset < 0 && offset > closest.offset) ? { offset, element: child } : closest;
                }, { offset: Number.NEGATIVE_INFINITY }).element;
            }

            function savePageOrder() {
                const wrappers = pagesContainer.querySelectorAll('.page-wrapper');
                const orderData = [];
                wrappers.forEach((wrapper, index) => {
                    orderData.push({ id: wrapper.dataset.id, order: index });
                    const pn = wrapper.querySelector('.page-number');
                    if (pn) pn.textContent = 'Page ' + (index + 1);
                });
                const formData = new FormData();
                formData.append('action', 'update_page_order');
                formData.append('order_data', JSON.stringify(orderData));
                formData.append('csrf_token', '<?php echo $csrf_token; ?>');
                fetch(window.location.href, { method: 'POST', body: formData })
                    .then(r => r.json())
                    .then(d => { if (d.success) showNotification('Ordre des pages mis à jour !'); })
                    .catch(() => {});
            }

            function showNotification(message) {
                const n = document.createElement('div');
                n.className = 'notification';
                n.textContent = message;
                document.body.appendChild(n);
                setTimeout(() => n.remove(), 2000);
            }

            const thumbsContainer = document.getElementById('thumbsContainer');
            if (thumbsContainer) {
                thumbsContainer.querySelectorAll('.thumb-item').forEach(thumb => {
                    thumb.addEventListener('dragover', e => { e.preventDefault(); thumb.classList.add('drag-over'); });
                    thumb.addEventListener('dragleave', () => thumb.classList.remove('drag-over'));
                    thumb.addEventListener('drop', e => {
                        e.preventDefault(); thumb.classList.remove('drag-over');
                        const dragging = document.querySelector('.dragging');
                        if (!dragging) return;
                        const target = pagesContainer.querySelector(`.page-wrapper[data-id="${thumb.dataset.id}"]`);
                        if (target) { pagesContainer.insertBefore(dragging, target); dragging.classList.remove('dragging'); savePageOrder(); }
                    });
                    thumb.addEventListener('click', () => {
                        const selected = pagesContainer.querySelector('.page-wrapper.selected');
                        if (!selected) return;
                        const target = pagesContainer.querySelector(`.page-wrapper[data-id="${thumb.dataset.id}"]`);
                        if (target && selected !== target) { pagesContainer.insertBefore(selected, target); selected.classList.remove('selected'); savePageOrder(); }
                    });
                });

                pagesContainer.querySelectorAll('.page-wrapper').forEach(wrapper => {
                    wrapper.addEventListener('click', (e) => {
                        if (e.target.closest('button') || e.target.classList.contains('drag-handle')) return;
                        if (!wrapper.classList.contains('draggable')) return;
                        const currently = pagesContainer.querySelector('.page-wrapper.selected');
                        if (currently && currently !== wrapper) currently.classList.remove('selected');
                        wrapper.classList.toggle('selected');
                    });
                });
            }
        }
        <?php endif; ?>
    </script>

    <script>
        const progressBar = document.getElementById('readingProgressBar');
        
        window.addEventListener('scroll', () => {
            const scrollTop = window.scrollY;
            const docHeight = document.documentElement.scrollHeight - window.innerHeight;
            const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
            progressBar.style.width = scrollPercent + '%';
        });
    </script>

</body>
</html>