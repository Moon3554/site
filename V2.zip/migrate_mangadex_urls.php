<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    http_response_code(403);
    exit('Accès refusé.');
}

require_once 'db.php';

$proto    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$site_dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$proxy_base = $proto . '://' . $_SERVER['HTTP_HOST'] . $site_dir . '/mangadex_image_proxy.php';

$rows = $db->query("SELECT id, page_url FROM chapter_pages")->fetchAll();

$updated = 0;
$skipped = 0;

$stmt = $db->prepare("UPDATE chapter_pages SET page_url = ? WHERE id = ?");

foreach ($rows as $row) {
    $url = $row['page_url'];
    $real_url = null;

    if (preg_match('#mangadex_image_proxy\.php\?u=([A-Za-z0-9_-]+)$#', $url, $m)) {
        if (strpos($url, '://') !== false) {
            $skipped++;
            continue;
        }
        $new_url = $proxy_base . '?u=' . $m[1];
        $stmt->execute([$new_url, $row['id']]);
        $updated++;
        continue;
    }

    if (preg_match('#mangadex_image_proxy\.php\?url=(.+)$#', $url, $m)) {
        $real_url = urldecode($m[1]);
    } else {
        $host = parse_url($url, PHP_URL_HOST);
        if ($host && preg_match('/(^|\.)mangadex\.(org|network)$/i', $host)) {
            $real_url = $url;
        }
    }

    if ($real_url === null) {
        $skipped++;
        continue;
    }

    $encoded = rtrim(strtr(base64_encode($real_url), '+/', '-_'), '=');
    $new_url = $proxy_base . '?u=' . $encoded;

    $stmt->execute([$new_url, $row['id']]);
    $updated++;
}

echo "Terminé. $updated page(s) mise(s) à jour, $skipped ignorée(s).";