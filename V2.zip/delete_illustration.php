<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: index.php');
    exit();
}


$ill_id   = isset($_POST['illustration_id']) ? (int)$_POST['illustration_id'] : 0;
$manga_id = isset($_POST['manga_id'])        ? (int)$_POST['manga_id']        : 0;

if ($ill_id > 0 && $manga_id > 0) {
    try {
        $stmt = $db->prepare("DELETE FROM illustrations WHERE id = ? AND manga_id = ?");
        $stmt->execute([$ill_id, $manga_id]);
    } catch (PDOException $e) {
        error_log("Erreur delete_illustration : " . $e->getMessage());
    }
}

header('Location: manga.php?id=' . $manga_id);
exit();
?>
