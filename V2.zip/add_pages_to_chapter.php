<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Accès refusé.']));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['success' => false, 'error' => 'Méthode non autorisée.']));
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Token CSRF invalide.']));
}

$chapter_id = isset($_POST['chapter_id']) ? (int)$_POST['chapter_id'] : 0;
$manga_id   = isset($_POST['manga_id'])   ? (int)$_POST['manga_id']   : 0;
$page_urls  = isset($_POST['page_urls'])  ? (array)$_POST['page_urls'] : [];
$imgur_album = isset($_POST['imgur_album_url']) ? trim($_POST['imgur_album_url']) : '';

if ($imgur_album !== '') {
    $opts = [
        'http' => [
            'method' => 'GET',
            'header' => "User-Agent: Mozilla/5.0 (compatible; YureiScan/1.0)\r\n"
        ]
    ];
    $context = stream_context_create($opts);
    $html = @file_get_contents($imgur_album, false, $context);
    if ($html) {
        $matches = [];
        preg_match_all('#https?://i\.imgur\.com/[A-Za-z0-9]+\.(?:jpg|jpeg|png|gif)#i', $html, $matches);
        if (!empty($matches[0])) {
            $seen = [];
            $urls = [];
            foreach ($matches[0] as $u) {
                if (isset($seen[$u])) continue;
                $seen[$u] = true;
                $urls[] = $u;
            }
            if (!empty($urls)) {
                $page_urls = $urls;
            }
        }

        if (empty($page_urls)) {
            $hashes = [];
            preg_match_all('/"hash"\s*:\s*"([A-Za-z0-9]{5,10})"/', $html, $m3);
            if (!empty($m3[1])) $hashes = array_merge($hashes, $m3[1]);
            preg_match_all('/data-id=\"([A-Za-z0-9]{5,10})\"/i', $html, $m4);
            if (!empty($m4[1])) $hashes = array_merge($hashes, $m4[1]);
            if (!empty($hashes)) {
                $seen = [];
                $urls2 = [];
                foreach ($hashes as $h) {
                    $u = 'https://i.imgur.com/' . $h . '.jpg';
                    if (isset($seen[$u])) continue;
                    $seen[$u] = true;
                    $urls2[] = $u;
                }
                if (!empty($urls2)) {
                    $page_urls = $urls2;
                }
            }
        }
        if (empty($page_urls)) {
            error_log('add_pages_to_chapter.php: Imgur album fourni mais aucune image trouvée dans ' . $imgur_album);
        }
    }
}
$replace    = isset($_POST['replace']) && $_POST['replace'] === '1'; 

if ($chapter_id <= 0) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'ID chapitre invalide.']));
}

$page_urls = array_values(array_filter(array_map('trim', $page_urls)));

if (empty($page_urls)) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Aucune URL de page fournie.']));
}

try {
    if ($manga_id > 0) {
        $stmt = $db->prepare("SELECT id, chapter_number FROM chapters WHERE id = ? AND manga_id = ?");
        $stmt->execute([$chapter_id, $manga_id]);
    } else {
        $stmt = $db->prepare("SELECT id, chapter_number FROM chapters WHERE id = ?");
        $stmt->execute([$chapter_id]);
    }
    $chapter = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$chapter) {
        http_response_code(404);
        die(json_encode(['success' => false, 'error' => 'Chapitre introuvable.']));
    }
} catch (PDOException $e) {
    error_log("add_pages_to_chapter.php - vérif chapitre : " . $e->getMessage());
    http_response_code(500);
    die(json_encode(['success' => false, 'error' => 'Erreur serveur.']));
}

try {
    $db->beginTransaction();

    if ($replace) {
        $stmt = $db->prepare("DELETE FROM chapter_pages WHERE chapter_id = ?");
        $stmt->execute([$chapter_id]);
        $start_order = 1;
    } else {

        $stmt = $db->prepare("SELECT COALESCE(MAX(page_order), 0) FROM chapter_pages WHERE chapter_id = ?");
        $stmt->execute([$chapter_id]);
        $start_order = (int)$stmt->fetchColumn() + 1;
    }

    $pages_inserted = 0;
    foreach ($page_urls as $i => $url) {
        $stmt = $db->prepare("INSERT INTO chapter_pages (chapter_id, page_url, page_order) VALUES (?, ?, ?)");
        $stmt->execute([$chapter_id, $url, $start_order + $i]);
        $pages_inserted++;
    }

    $db->commit();

    $stmt = $db->prepare("SELECT COUNT(*) FROM chapter_pages WHERE chapter_id = ?");
    $stmt->execute([$chapter_id]);
    $total_pages = (int)$stmt->fetchColumn();

    echo json_encode([
        'success'        => true,
        'chapter_id'     => $chapter_id,
        'chapter_number' => $chapter['chapter_number'],
        'pages_inserted' => $pages_inserted,
        'total_pages'    => $total_pages,
        'message'        => $pages_inserted . ' page(s) ajoutée(s) au chapitre ' . htmlspecialchars($chapter['chapter_number']) . '. Total : ' . $total_pages . ' pages.',
    ]);

} catch (PDOException $e) {
    if ($db->inTransaction()) $db->rollBack();
    error_log("add_pages_to_chapter.php - insertion : " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erreur lors de l\'insertion : ' . $e->getMessage()]);
}